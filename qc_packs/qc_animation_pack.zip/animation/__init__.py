bl_info = {
    "name": "Scriptronaut QC Test Pack",
    "author": "Scriptronaut",
    "version": (0, 1, 0),
    "blender": (4, 3, 0),
    "location": "Scriptronaut QC Checker",
    "description": "Local test pack for the Scriptronaut registered-check API",
    "category": "Scriptronaut",
}

from pathlib import Path


PACK_ID = "scriptronaut_test_pack"


def register():
    try:
        import scriptronaut_qc_api
    except ImportError as error:
        raise RuntimeError(
            "Scriptronaut QC Core must be enabled before the Test Pack."
        ) from error

    checks_path = str(
        Path(__file__).resolve().parent
        / "checks"
    )

    scriptronaut_qc_api.register_check_pack(
        pack_id=PACK_ID,
        name="Scriptronaut QC Test Pack",
        checks_path=checks_path,
        version="0.1.0",
        priority=100,
        metadata={
            "kind": "test",
        },
    )


def unregister():
    try:
        import scriptronaut_qc_api
    except ImportError:
        return

    scriptronaut_qc_api.unregister_check_pack(
        PACK_ID
    )
