"""Rigging Pack checks."""
