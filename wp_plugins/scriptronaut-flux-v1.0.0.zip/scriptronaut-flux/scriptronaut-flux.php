<?php
/**
 * Plugin Name: Scriptronaut Flux
 * Description: Download analytics for Scriptronaut free add-ons and items.
 * Version: 1.0.0
 * Author: Scriptronaut
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

final class Scriptronaut_Flux {
    const VERSION = '1.0.0';
    const DB_VERSION = '0.1.0';
    const OPT = 'scriptronaut_flux_settings';
    const MENU = 'scriptronaut-flux';

    private static $instance = null;
    private $table;

    public static function instance() {
        return self::$instance ?: (self::$instance = new self());
    }

    private function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'scriptronaut_flux_downloads';

        add_action('init', array($this, 'maybe_upgrade'), 1);
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_head', array($this, 'admin_menu_icon_css'));

        add_action('admin_post_nopriv_scriptronaut_flux_download', array($this, 'download'));
        add_action('admin_post_scriptronaut_flux_download', array($this, 'download'));
        add_action('admin_post_scriptronaut_flux_export', array($this, 'export_csv'));
        add_action('admin_post_scriptronaut_flux_delete', array($this, 'delete_download'));
        add_action('admin_post_scriptronaut_flux_bulk_delete', array($this, 'bulk_delete_downloads'));
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = $wpdb->prefix . 'scriptronaut_flux_downloads';
        $charset = $wpdb->get_charset_collate();

        dbDelta("CREATE TABLE {$table} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            item_key varchar(120) NOT NULL,
            item_name varchar(180) NOT NULL DEFAULT '',
            item_group varchar(80) NOT NULL DEFAULT '',
            downloaded_at datetime NOT NULL,
            visitor_hash char(64) NOT NULL DEFAULT '',
            referrer varchar(500) NOT NULL DEFAULT '',
            PRIMARY KEY (id),
            KEY item_key (item_key),
            KEY downloaded_at (downloaded_at),
            KEY item_date (item_key, downloaded_at)
        ) {$charset};");

        if (!get_option(self::OPT)) {
            $root = preg_replace('#/wp/?$#i', '', site_url());
            add_option(self::OPT, array(
                'free_items_url' => trailingslashit($root) . 'free_items/',
            ));
        }

        update_option('scriptronaut_flux_db_version', self::DB_VERSION);
    }

    public function maybe_upgrade() {
        if ((string) get_option('scriptronaut_flux_db_version') !== self::DB_VERSION) {
            self::activate();
        }
    }

    public function register_settings() {
        register_setting('scriptronaut_flux', self::OPT, array($this, 'sanitize_settings'));
    }

    public function sanitize_settings($value) {
        $url = esc_url_raw($value['free_items_url'] ?? '');
        return array('free_items_url' => trailingslashit($url));
    }

    private function settings() {
        $root = preg_replace('#/wp/?$#i', '', site_url());
        return wp_parse_args(
            (array) get_option(self::OPT, array()),
            array('free_items_url' => trailingslashit($root) . 'free_items/')
        );
    }

    public function menu() {
        $icon = 'data:image/svg+xml;base64,Cgo8IS0tIENyZWF0b3I6IENvcmVsRFJBVyAyMDIxICg2NC1CaXQpIC0tPgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjI4cHgiIGhlaWdodD0iMzJweCIgdmVyc2lvbj0iMS4xIiBzaGFwZS1yZW5kZXJpbmc9Imdlb21ldHJpY1ByZWNpc2lvbiIgdGV4dC1yZW5kZXJpbmc9Imdlb21ldHJpY1ByZWNpc2lvbiIgaW1hZ2UtcmVuZGVyaW5nPSJvcHRpbWl6ZVF1YWxpdHkiIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIgp2aWV3Qm94PSIwIDAgMjcuNDEgMzEuNyIKIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIgogeG1sbnM6eG9kbT0iaHR0cDovL3d3dy5jb3JlbC5jb20vY29yZWxkcmF3L29kbS8yMDAzIj4KIDxnIGlkPSJMYXllcl94MDAyMF8xIj4KICA8bWV0YWRhdGEgaWQ9IkNvcmVsQ29ycElEXzBDb3JlbC1MYXllciIvPgogIDxwYXRoIGZpbGw9IiNFNkU2RTYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEwLjYxIDkuNDJjMCwtMC41MiAwLjQzLC0wLjk1IDAuOTUsLTAuOTUgMC41MywwIDAuOTYsMC40MyAwLjk2LDAuOTVsMCAzLjIyYzAsMC41MiAtMC40MywwLjk1IC0wLjk2LDAuOTUgLTAuNTIsMCAtMC45NSwtMC40MyAtMC45NSwtMC45NWwwIC0zLjIyem0tNy42MSAtMi4xNGwyMS40MSAwIDAgLTEuMjhjMS42NSwwIDMsLTEuMzYgMywtM2wwIC0yLjE0YzAsLTAuNDggLTAuMzgsLTAuODYgLTAuODUsLTAuODZsLTI1LjcgMGMtMC40OCwwIC0wLjg2LDAuMzggLTAuODYsMC44NmwwIDIuMTRjMCwxLjY1IDEuMzUsMyAzLDNsMCAxLjI4em04LjU2IC0zLjIxbDAgLTIuMzYgNC4yOSAwIDAgMi4zNiAtNC4yOSAwem0xMi44NSAyMC4zNGwtMjEuNDEgMCAwIDEuMjljLTEuNjUsMCAtMywxLjM1IC0zLDNsMCAyLjE0YzAsMC40NyAwLjM4LDAuODYgMC44NiwwLjg2bDI1LjcgMGMwLjQ3LDAgMC44NSwtMC4zOSAwLjg1LC0wLjg2bDAgLTIuMTRjMCwtMS42NSAtMS4zNSwtMyAtMywtM2wwIC0xLjI5em0tOC41NiA1LjU3bDAgLTIuMzUgMi4xNCAwIDAgMi4zNSAtMi4xNCAwem00LjI4IDBsMCAtMi4zNSAyLjE0IDAgMCAyLjM1IC0yLjE0IDB6bS00LjI4IC02LjgxYzAuNDksMCAwLjg5LC0wLjQgMC44OSwtMC45IDAsLTAuNDkgLTAuNCwtMC44OSAtMC44OSwtMC44OSAtMC41LDAgLTAuOSwwLjQgLTAuOSwwLjg5IDAsMC41IDAuNCwwLjkgMC45LDAuOXptLTUuMjQgLTguMzljMCwtMC41MyAwLjQzLC0wLjk2IDAuOTUsLTAuOTYgMC41MywwIDAuOTYsMC40MyAwLjk2LDAuOTZsMCA3LjQ5YzAsMC41MyAtMC40MywwLjk1IC0wLjk2LDAuOTUgLTAuNTIsMCAtMC45NSwtMC40MiAtMC45NSwtMC45NWwwIC03LjQ5em0tNC4yOCA1LjM1YzAsLTAuNTMgMC40MywtMC45NSAwLjk1LC0wLjk1IDAuNTMsMCAwLjk1LDAuNDIgMC45NSwwLjk1bDAgMi4xNGMwLDAuNTMgLTAuNDIsMC45NSAtMC45NSwwLjk1IC0wLjUyLDAgLTAuOTUsLTAuNDIgLTAuOTUsLTAuOTVsMCAtMi4xNHptMCAtMTAuNzFjMCwtMC41MiAwLjQzLC0wLjk1IDAuOTUsLTAuOTUgMC41MywwIDAuOTUsMC40MyAwLjk1LDAuOTVsMCA4LjU3YzAsMC41MiAtMC40MiwwLjk1IC0wLjk1LDAuOTUgLTAuNTIsMCAtMC45NSwtMC40MyAtMC45NSwtMC45NWwwIC04LjU3em05LjUyIDUuMzdsMC43OCAyLjM1IDIuNDEgMC44NSAtMi4zNSAwLjc4IC0wLjg0IDIuNDIgLTAuNzggLTIuMzUgLTIuNDIgLTAuODUgMi4zNSAtMC43OCAwLjg1IC0yLjQyem00LjI4IC02LjQybDAuNzggMi4zNSAyLjQyIDAuODQgLTIuMzUgMC43OSAtMC44NSAyLjQxIC0wLjc4IC0yLjM1IC0yLjQyIC0wLjg1IDIuMzUgLTAuNzggMC44NSAtMi40MXptLTAuOTUgNy40OGMwLC0wLjUzIDAuNDIsLTAuOTUgMC45NSwtMC45NSAwLjUzLDAgMC45NSwwLjQyIDAuOTUsMC45NWwwIDYuNDJjMCwwLjUzIC0wLjQyLDAuOTUgLTAuOTUsMC45NSAtMC41MywwIC0wLjk1LC0wLjQyIC0wLjk1LC0wLjk1bDAgLTYuNDJ6bS00LjI4IC02LjQzYzAsLTAuNTIgMC40MiwtMC45NSAwLjk1LC0wLjk1IDAuNTIsMCAwLjk1LDAuNDMgMC45NSwwLjk1bDAgNC4yOWMwLDAuNTIgLTAuNDMsMC45NSAtMC45NSwwLjk1IC0wLjUzLDAgLTAuOTUsLTAuNDMgLTAuOTUsLTAuOTVsMCAtNC4yOXoiLz4KIDwvZz4KPC9zdmc+Cg==';
        add_menu_page(
            'Scriptronaut Flux',
            'Flux',
            'manage_options',
            self::MENU,
            array($this, 'dashboard'),
            $icon,
            58.5
        );
        add_submenu_page(self::MENU, 'Flux Dashboard', 'Dashboard', 'manage_options', self::MENU, array($this, 'dashboard'));
        add_submenu_page(self::MENU, 'Flux Downloads', 'Downloads', 'manage_options', self::MENU . '-downloads', array($this, 'downloads_page'));
        add_submenu_page(self::MENU, 'Flux Settings', 'Settings', 'manage_options', self::MENU . '-settings', array($this, 'settings_page'));
    }

    public function admin_menu_icon_css() {
        echo '<style>
            #adminmenu .toplevel_page_scriptronaut-flux .wp-menu-image img {
                opacity: 1 !important;
                width: 20px;
                height: 20px;
                padding-top: 7px;
            }
        </style>';
    }

    private function visitor_hash() {
        $ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? ''));
        $ua = sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? ''));
        return hash_hmac('sha256', $ip . '|' . $ua, wp_salt('auth'));
    }

    private function clean_item_key($value) {
        $value = strtolower(sanitize_text_field(wp_unslash($value)));
        return preg_match('/^[a-z0-9_-]+$/', $value) ? $value : '';
    }

    public function download() {
        global $wpdb;

        $item = $this->clean_item_key($_GET['item'] ?? '');
        if (!$item) {
            wp_die('Invalid Flux download item.', 'Flux', array('response' => 400));
        }

        $name = sanitize_text_field(wp_unslash($_GET['name'] ?? ''));
        $group = sanitize_key(wp_unslash($_GET['group'] ?? ''));
        if ($name === '') {
            $name = ucwords(str_replace(array('_', '-'), ' ', $item));
        }

        $settings = $this->settings();
        $target = trailingslashit($settings['free_items_url']) . rawurlencode($item) . '.zip';

        $wpdb->insert(
            $this->table,
            array(
                'item_key' => $item,
                'item_name' => $name,
                'item_group' => $group,
                'downloaded_at' => current_time('mysql', true),
                'visitor_hash' => $this->visitor_hash(),
                'referrer' => esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'] ?? '')),
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );

        nocache_headers();
        wp_redirect($target, 302, 'Scriptronaut Flux');
        exit;
    }

    private function utc_now() {
        return current_time('timestamp', true);
    }

    private function since_mysql($seconds) {
        return gmdate('Y-m-d H:i:s', $this->utc_now() - $seconds);
    }

    private function local_boundary_utc_mysql($boundary = 'today') {
        try {
            $timezone = new DateTimeZone('America/Toronto');
            $now = new DateTimeImmutable('now', $timezone);
            $local = ($boundary === 'month')
                ? $now->modify('first day of this month')->setTime(0, 0, 0)
                : $now->setTime(0, 0, 0);
            return $local->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        } catch (Exception $e) {
            // Safe fallback if timezone data is unexpectedly unavailable.
            return ($boundary === 'month')
                ? gmdate('Y-m-01 00:00:00', $this->utc_now())
                : gmdate('Y-m-d 00:00:00', $this->utc_now());
        }
    }

    private function count_where($where = '1=1') {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table} WHERE {$where}");
    }

    private function format_local_datetime($utc_mysql) {
        if (!$utc_mysql) return '—';

        try {
            $dt = new DateTime($utc_mysql, new DateTimeZone('UTC'));
            $montreal = new DateTimeZone('America/Toronto');
            $dt->setTimezone($montreal);
            return $dt->format('Y-m-d H:i:s');
        } catch (Exception $e) {
            return $utc_mysql;
        }
    }

    private function header($title, $show_icon = false, $description = '') {
        $icon = plugins_url('assets/flux.svg', __FILE__);

        if ($show_icon) {
            $flux_svg_path = plugin_dir_path(__FILE__) . 'assets/flux.svg';
            $flux_svg = @file_get_contents($flux_svg_path);
            if ($flux_svg !== false) {
                $flux_svg = str_ireplace('#E6E6E6', '#08ACA0', $flux_svg);
                $icon = 'data:image/svg+xml;base64,' . base64_encode($flux_svg);
            }
        }
        echo '<div class="wrap flux-wrap">';
        echo '<style>
            .flux-wrap{--flux:#08ACA0;max-width:1280px}
            .flux-title{display:flex;align-items:center;gap:16px;margin:12px 0 8px}
            .flux-title img{width:64px;height:64px}
            .flux-title h1{margin:0 0 5px;font-size:26px}
            .flux-stats{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:14px;margin:0 0 24px}
            .flux-stat{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:18px}
            .flux-stat strong{display:block;color:var(--flux);font-size:30px;line-height:1.1;margin-bottom:5px}
            .flux-stat span{color:#50575e;font-weight:600}
            .flux-card{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:20px;margin:0 0 22px}
            .flux-card h2{margin-top:0}
            .flux-accent{color:var(--flux)}
            .flux-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:0 0 18px}
            .flux-bar{height:8px;background:#e8eeee;border-radius:999px;overflow:hidden;min-width:100px}
            .flux-bar span{display:block;height:100%;background:var(--flux)}
            .flux-empty{padding:28px;text-align:center;color:#646970}
            .flux-mini-chart{display:flex;align-items:flex-end;gap:5px;height:150px;padding:12px 4px 4px;border-bottom:1px solid #dcdcde}
            .flux-mini-bar{flex:1;min-width:8px;background:var(--flux);border-radius:4px 4px 0 0;position:relative}
            .flux-mini-bar:hover:after{content:attr(data-tip);position:absolute;bottom:100%;left:50%;transform:translateX(-50%);background:#1d2327;color:#fff;padding:4px 7px;border-radius:4px;white-space:nowrap;font-size:11px;z-index:3}
            .flux-sort-link{color:#2271b1 !important;text-decoration:none;font-weight:600}.flux-sort-link:hover{color:#135e96 !important}.flux-item-link{text-decoration:none;font-weight:600}.flux-danger{color:#b32d2e}.flux-checkbox{width:16px;height:16px}
            @media(max-width:1100px){.flux-stats{grid-template-columns:repeat(4,minmax(0,1fr))}}
            @media(max-width:782px){.flux-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}
            @media(max-width:600px){.flux-stats{grid-template-columns:1fr}}
        </style>';
        echo '<div class="flux-title">';
        if ($show_icon) {
            echo '<img src="' . esc_attr($icon) . '" alt="">';
        }
        echo '<div><h1>' . esc_html($title) . '</h1>';
        if ($description !== '') {
            echo '<p style="margin:0;color:#50575e;">' . esc_html($description) . '</p>';
        }
        echo '</div></div>';
    }

    private function footer() {
        echo '</div>';
    }

    public function dashboard() {
        if (!current_user_can('manage_options')) return;
        global $wpdb;

        $today = $this->local_boundary_utc_mysql('today');
        $month = $this->local_boundary_utc_mysql('month');
        $week = $this->since_mysql(7 * DAY_IN_SECONDS);

        $selected_item = $this->clean_item_key($_GET['flux_item'] ?? '');
        $selected_group = sanitize_key(wp_unslash($_GET['flux_group'] ?? ''));

        $sort = sanitize_key(wp_unslash($_GET['flux_sort'] ?? 'total'));
        $direction = strtolower(sanitize_text_field(wp_unslash($_GET['flux_dir'] ?? 'desc')));
        $direction = $direction === 'asc' ? 'ASC' : 'DESC';
        $sortable_columns = array(
            'total' => 'total',
            'today' => 'today_count',
            'week' => 'week_count',
            'month' => 'month_count',
            'last' => 'last_download',
        );
        if (!isset($sortable_columns[$sort])) $sort = 'total';
        $order_by = $sortable_columns[$sort] . ' ' . $direction . ', item_key ASC';

        $items = $wpdb->get_results(
            "SELECT item_key, MAX(item_name) item_name
             FROM {$this->table}
             GROUP BY item_key
             ORDER BY item_name ASC, item_key ASC",
            ARRAY_A
        );

        $groups = $wpdb->get_col(
            "SELECT DISTINCT item_group
             FROM {$this->table}
             WHERE item_group <> ''
             ORDER BY item_group ASC"
        );

        $where = array();
        $params = array();

        if ($selected_item !== '') {
            $where[] = 'item_key = %s';
            $params[] = $selected_item;
        }

        if ($selected_group !== '') {
            $where[] = 'item_group = %s';
            $params[] = $selected_group;
        }

        $where_sql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

        $query =
            "SELECT item_key,
                    MAX(item_name) item_name,
                    MAX(item_group) item_group,
                    COUNT(*) total,
                    SUM(downloaded_at >= %s) today_count,
                    SUM(downloaded_at >= %s) week_count,
                    SUM(downloaded_at >= %s) month_count,
                    MAX(downloaded_at) last_download
             FROM {$this->table}" . $where_sql . "
             GROUP BY item_key
             ORDER BY {$order_by}";

        $query_params = array_merge(array($today, $week, $month), $params);
        $rows = $wpdb->get_results($wpdb->prepare($query, $query_params), ARRAY_A);

        $group_counts = $wpdb->get_results(
            "SELECT item_group, COUNT(*) downloads
             FROM {$this->table}
             GROUP BY item_group",
            OBJECT_K
        );

        $total = $this->count_where();
        $max = 1;
        foreach ($rows as $r) $max = max($max, (int) $r['total']);

        $this->header(
            'Scriptronaut Flux',
            true,
            'Track and review download activity for Scriptronaut free items.'
        );

        echo '<div class="flux-stats">';
        echo '<div class="flux-stat"><strong>' . number_format_i18n($total) . '</strong><span>All</span></div>';
        foreach ($group_counts as $group_key => $group_data) {
            if ($group_key === '') continue;
            $group_label = ucwords(str_replace(array('_', '-'), ' ', $group_key));
            echo '<div class="flux-stat"><strong>' . number_format_i18n((int) $group_data->downloads) . '</strong><span>' . esc_html($group_label) . '</span></div>';
        }
        echo '</div>';

        echo '<div class="flux-card" style="padding:10px 14px 8px;">';
        echo '<form method="get" action="' . esc_url(admin_url('admin.php')) . '">';
        echo '<input type="hidden" name="page" value="' . esc_attr(self::MENU) . '">';

        echo '<input type="hidden" name="flux_sort" value="' . esc_attr($sort) . '">';
        echo '<input type="hidden" name="flux_dir" value="' . esc_attr(strtolower($direction)) . '">';
        echo '<div style="display:flex;gap:16px;align-items:flex-end;flex-wrap:wrap;">';

        echo '<div><label for="flux-item"><strong>Item name</strong></label><br>';
        echo '<select id="flux-item" name="flux_item" style="min-width:190px;margin-top:6px;">';
        echo '<option value="">All</option>';
        foreach ($items as $item) {
            $label = $item['item_name'] ?: $item['item_key'];
            echo '<option value="' . esc_attr($item['item_key']) . '"' . selected($selected_item, $item['item_key'], false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></div>';

        echo '<div><label for="flux-group"><strong>Group</strong></label><br>';
        echo '<select id="flux-group" name="flux_group" style="min-width:190px;margin-top:6px;">';
        echo '<option value="">All</option>';
        foreach ($groups as $group) {
            echo '<option value="' . esc_attr($group) . '"' . selected($selected_group, $group, false) . '>' . esc_html(ucwords(str_replace('_', ' ', $group))) . '</option>';
        }
        echo '</select></div>';

        echo '<div style="padding-bottom:1px;"><button class="button button-primary" type="submit">Filter</button> ';
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=' . self::MENU)) . '">Reset</a></div>';
        echo '</div></form></div>';

        echo '<div class="flux-card"><h2>Free Item Downloads</h2>';
        if (!$rows) {
            echo '<div class="flux-empty">No downloads match the current filters.</div>';
        } else {
            $sort_link = function($key, $label) use ($sort, $direction, $selected_item, $selected_group) {
                $next_dir = ($sort === $key && $direction === 'ASC') ? 'desc' : 'asc';
                $arrow = ($sort === $key) ? ($direction === 'ASC' ? ' ↑' : ' ↓') : ' ↕';
                $args = array('page' => self::MENU, 'flux_sort' => $key, 'flux_dir' => $next_dir);
                if ($selected_item !== '') $args['flux_item'] = $selected_item;
                if ($selected_group !== '') $args['flux_group'] = $selected_group;
                return '<a class="flux-sort-link" href="' . esc_url(add_query_arg($args, admin_url('admin.php'))) . '">' . esc_html($label . $arrow) . '</a>';
            };
            echo '<table class="widefat striped"><thead><tr><th>Item</th><th>Group</th><th>' . $sort_link('total', 'Total') . '</th><th>' . $sort_link('today', 'Today') . '</th><th>' . $sort_link('week', '7 Days') . '</th><th>' . $sort_link('month', 'This Month') . '</th><th>Activity</th><th>' . $sort_link('last', 'Last Download') . '</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                $pct = max(3, round(((int) $r['total'] / $max) * 100));
                echo '<tr>';
                echo '<td><strong>' . esc_html($r['item_name'] ?: $r['item_key']) . '</strong><br><code>' . esc_html($r['item_key']) . '</code></td>';
                echo '<td>' . esc_html($r['item_group'] ?: '—') . '</td>';
                echo '<td><strong class="flux-accent">' . number_format_i18n((int) $r['total']) . '</strong></td>';
                echo '<td>' . number_format_i18n((int) $r['today_count']) . '</td>';
                echo '<td>' . number_format_i18n((int) $r['week_count']) . '</td>';
                echo '<td>' . number_format_i18n((int) $r['month_count']) . '</td>';
                echo '<td><div class="flux-bar"><span style="width:' . esc_attr($pct) . '%"></span></div></td>';
                echo '<td>' . esc_html($this->format_local_datetime($r['last_download'])) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';

        $this->footer();
    }

    private function date_filter_sql($range, &$params) {
        $now = $this->utc_now();
        if ($range === 'today') { $params[] = $this->local_boundary_utc_mysql('today'); return 'downloaded_at >= %s'; }
        if ($range === '7days') { $params[] = gmdate('Y-m-d H:i:s',$now-7*DAY_IN_SECONDS); return 'downloaded_at >= %s'; }
        if ($range === '30days') { $params[] = gmdate('Y-m-d H:i:s',$now-30*DAY_IN_SECONDS); return 'downloaded_at >= %s'; }
        if ($range === 'month') { $params[] = $this->local_boundary_utc_mysql('month'); return 'downloaded_at >= %s'; }
        return '';
    }

    private function downloads_filters($item,$group,$range) {
        global $wpdb;
        $items=$wpdb->get_results("SELECT item_key,MAX(item_name) item_name FROM {$this->table} GROUP BY item_key ORDER BY item_name",ARRAY_A);
        $groups=$wpdb->get_col("SELECT DISTINCT item_group FROM {$this->table} WHERE item_group<>'' ORDER BY item_group");
        echo '<div class="flux-card" style="padding:10px 14px 8px;"><form method="get"><input type="hidden" name="page" value="'.esc_attr(self::MENU.'-downloads').'"><div style="display:flex;gap:16px;align-items:flex-end;flex-wrap:wrap;">';
        echo '<div><strong>Item name</strong><br><select name="flux_item" style="min-width:190px;margin-top:6px"><option value="">All</option>';
        foreach($items as $x) echo '<option value="'.esc_attr($x['item_key']).'"'.selected($item,$x['item_key'],false).'>'.esc_html($x['item_name']?:$x['item_key']).'</option>';
        echo '</select></div><div><strong>Group</strong><br><select name="flux_group" style="min-width:190px;margin-top:6px"><option value="">All</option>';
        foreach($groups as $x) echo '<option value="'.esc_attr($x).'"'.selected($group,$x,false).'>'.esc_html(ucwords(str_replace('_',' ',$x))).'</option>';
        echo '</select></div><div><strong>Date range</strong><br><select name="flux_range" style="min-width:160px;margin-top:6px">';
        foreach(array(''=>'All time','today'=>'Today','7days'=>'7 days','30days'=>'30 days','month'=>'This month') as $v=>$l) echo '<option value="'.esc_attr($v).'"'.selected($range,$v,false).'>'.esc_html($l).'</option>';
        echo '</select></div><div><button class="button button-primary">Filter</button> <a class="button" href="'.esc_url(admin_url('admin.php?page='.self::MENU.'-downloads')).'">Reset</a></div></div></form></div>';
    }

    public function downloads_page() {
        if(!current_user_can('manage_options'))return; global $wpdb;
        $item=$this->clean_item_key($_GET['flux_item']??''); $group=sanitize_key(wp_unslash($_GET['flux_group']??'')); $range=sanitize_key(wp_unslash($_GET['flux_range']??''));
        if($item && isset($_GET['item_history'])){$this->item_history_page($item);return;}
        $w=array();$args=array();
        if($item){$w[]='item_key=%s';$args[]=$item;} if($group){$w[]='item_group=%s';$args[]=$group;}
        $d=$this->date_filter_sql($range,$args);if($d)$w[]=$d;
        $sql="SELECT id,item_key,item_name,item_group,downloaded_at FROM {$this->table}".($w?' WHERE '.implode(' AND ',$w):'')." ORDER BY id DESC LIMIT 1000";
        if($args)$sql=$wpdb->prepare($sql,$args); $rows=$wpdb->get_results($sql,ARRAY_A);
        $this->header('Flux Downloads');
        echo '<p>Showing up to the latest 1,000 recorded download events. Flux does not store visitors\' raw IP addresses.</p>';
        if(isset($_GET['deleted'])) echo '<div class="notice notice-success is-dismissible"><p>'.intval($_GET['deleted']).' download entries deleted.</p></div>';
        $this->downloads_filters($item,$group,$range);
        echo '<div class="flux-actions"><a class="button" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_flux_export'),'flux_export')).'">Export CSV</a></div><div class="flux-card">';
        if(!$rows) echo '<div class="flux-empty">No downloads match the current filters.</div>';
        else {
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(\'Delete selected entries?\');"><input type="hidden" name="action" value="scriptronaut_flux_bulk_delete">';wp_nonce_field('flux_bulk_delete');
            echo '<p><button class="button flux-danger">Delete Selected</button></p><table class="widefat striped"><thead><tr><td class="check-column"><input type="checkbox" onclick="document.querySelectorAll(\'.flux-row-check\').forEach(c=>c.checked=this.checked)"></td><th>Item</th><th>Group</th><th>Date</th><th>Action</th></tr></thead><tbody>';
            foreach($rows as $r){
                $hist=add_query_arg(array('page'=>self::MENU.'-downloads','flux_item'=>$r['item_key'],'item_history'=>1),admin_url('admin.php'));
                $del=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_flux_delete&id='.intval($r['id'])),'flux_delete_'.intval($r['id']));
                echo '<tr><th class="check-column"><input class="flux-row-check" type="checkbox" name="ids[]" value="'.intval($r['id']).'"></th><td><a class="flux-item-link" href="'.esc_url($hist).'">'.esc_html($r['item_name']?:$r['item_key']).'</a><br><code>'.esc_html($r['item_key']).'</code></td><td>'.esc_html($r['item_group']?:'—').'</td><td>'.esc_html($this->format_local_datetime($r['downloaded_at'])).'</td><td><a class="flux-danger" href="'.esc_url($del).'" onclick="return confirm(\'Delete this entry?\')">Delete</a></td></tr>';
            } echo '</tbody></table></form>';
        } echo '</div>'; $this->footer();
    }

    private function item_history_page($key) {
        global $wpdb;
        $sum=$wpdb->get_row($wpdb->prepare("SELECT item_key,MAX(item_name) item_name,MAX(item_group) item_group,COUNT(*) total,COUNT(DISTINCT NULLIF(visitor_hash,'')) unique_count,SUM(downloaded_at >= %s) today_count,SUM(downloaded_at >= %s) week_count,SUM(downloaded_at >= %s) month_count,MIN(downloaded_at) first_download,MAX(downloaded_at) last_download FROM {$this->table} WHERE item_key=%s GROUP BY item_key",$this->local_boundary_utc_mysql('today'),$this->since_mysql(7*DAY_IN_SECONDS),$this->since_mysql(30*DAY_IN_SECONDS),$key),ARRAY_A);
        $this->header('Flux Item History'); if(!$sum){echo '<div class="flux-card">No history.</div>';$this->footer();return;}
        echo '<p><a href="'.esc_url(admin_url('admin.php?page='.self::MENU.'-downloads')).'">&larr; Back to Downloads</a></p><div class="flux-card"><h2>'.esc_html($sum['item_name']?:$key).'</h2><p>'.esc_html(ucwords(str_replace('_',' ',$sum['item_group']))).' · <code>'.esc_html($key).'</code></p><div class="flux-stats" style="grid-template-columns:repeat(5,1fr)">';
        foreach(array('Total'=>$sum['total'],'Approx. Unique'=>$sum['unique_count'],'Today'=>$sum['today_count'],'7 Days'=>$sum['week_count'],'30 Days'=>$sum['month_count']) as $l=>$v)echo '<div class="flux-stat"><strong>'.number_format_i18n((int)$v).'</strong><span>'.esc_html($l).'</span></div>';
        echo '</div><p><strong>First:</strong> '.esc_html($this->format_local_datetime($sum['first_download'])).' &nbsp; <strong>Last:</strong> '.esc_html($this->format_local_datetime($sum['last_download'])).'</p></div>';
        $trend=$wpdb->get_results($wpdb->prepare("SELECT DATE(downloaded_at) day,COUNT(*) downloads FROM {$this->table} WHERE item_key=%s AND downloaded_at >= %s GROUP BY DATE(downloaded_at) ORDER BY day",$key,$this->since_mysql(30*DAY_IN_SECONDS)),ARRAY_A);
        echo '<div class="flux-card"><h2>Downloads — Last 30 Days</h2>';
        if($trend){$m=max(array_map(fn($x)=>(int)$x['downloads'],$trend));echo '<div class="flux-mini-chart">';foreach($trend as $x)echo '<div class="flux-mini-bar" style="height:'.max(4,round($x['downloads']/$m*100)).'%" data-tip="'.esc_attr($x['day'].': '.$x['downloads']).'"></div>';echo '</div>';}else echo '<div class="flux-empty">No downloads.</div>';
        echo '</div>'; $events=$wpdb->get_results($wpdb->prepare("SELECT id,downloaded_at FROM {$this->table} WHERE item_key=%s ORDER BY id DESC LIMIT 1000",$key),ARRAY_A);
        echo '<div class="flux-card"><h2>Download History</h2><table class="widefat striped"><thead><tr><th>Date</th><th>Action</th></tr></thead><tbody>';
        foreach($events as $e){$del=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_flux_delete&id='.intval($e['id']).'&return_item='.rawurlencode($key)),'flux_delete_'.intval($e['id']));echo '<tr><td>'.esc_html($this->format_local_datetime($e['downloaded_at'])).'</td><td><a class="flux-danger" href="'.esc_url($del).'" onclick="return confirm(\'Delete this entry?\')">Delete</a></td></tr>';}
        echo '</tbody></table></div>'; $this->footer();
    }

    public function delete_download() {
        if(!current_user_can('manage_options'))wp_die('Unauthorized');$id=absint($_GET['id']??0);check_admin_referer('flux_delete_'.$id);global $wpdb;$n=$wpdb->delete($this->table,array('id'=>$id),array('%d'));
        $key=$this->clean_item_key($_GET['return_item']??'');$q=array('page'=>self::MENU.'-downloads','deleted'=>$n?1:0);if($key){$q['flux_item']=$key;$q['item_history']=1;}wp_safe_redirect(add_query_arg($q,admin_url('admin.php')));exit;
    }

    public function bulk_delete_downloads() {
        if(!current_user_can('manage_options'))wp_die('Unauthorized');check_admin_referer('flux_bulk_delete');$ids=array_values(array_filter(array_map('absint',(array)($_POST['ids']??array()))));$n=0;
        if($ids){global $wpdb;$ph=implode(',',array_fill(0,count($ids),'%d'));$n=(int)$wpdb->query($wpdb->prepare("DELETE FROM {$this->table} WHERE id IN ($ph)",$ids));}
        wp_safe_redirect(add_query_arg(array('page'=>self::MENU.'-downloads','deleted'=>$n),admin_url('admin.php')));exit;
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) return;
        $s = $this->settings();

        $this->header('Flux Settings');
        echo '<div class="flux-card">';
        echo '<form method="post" action="options.php">';
        settings_fields('scriptronaut_flux');
        echo '<table class="form-table">';
        echo '<tr><th scope="row"><label for="flux-free-items-url">Free items URL</label></th><td>';
        echo '<input id="flux-free-items-url" class="regular-text code" type="url" name="' . esc_attr(self::OPT) . '[free_items_url]" value="' . esc_attr($s['free_items_url']) . '">';
        echo '<p class="description">Public URL of the folder containing the downloadable ZIP files. Example: <code>https://scriptronaut.com/free_items/</code></p>';
        echo '</td></tr>';
        echo '</table>';
        submit_button();
        echo '</form>';
        echo '</div>';

        $endpoint = admin_url('admin-post.php?action=scriptronaut_flux_download&item=example_item&name=Example%20Item&group=tools');
        echo '<div class="flux-card"><h2>Tracking Endpoint</h2><p>Your free page sends downloads through Flux, which records the event and redirects to the ZIP.</p><code>' . esc_html($endpoint) . '</code></div>';
        $this->footer();
    }

    public function export_csv() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('flux_export');
        global $wpdb;

        $rows = $wpdb->get_results(
            "SELECT downloaded_at,item_key,item_name,item_group,referrer
             FROM {$this->table}
             ORDER BY id DESC",
            ARRAY_N
        );

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="scriptronaut-flux-downloads.csv"');

        $out = fopen('php://output', 'w');
        fputcsv($out, array('Downloaded At UTC', 'Item Key', 'Item Name', 'Group', 'Referrer'));
        foreach ($rows as $row) fputcsv($out, $row);
        fclose($out);
        exit;
    }
}

register_activation_hook(__FILE__, array('Scriptronaut_Flux', 'activate'));
Scriptronaut_Flux::instance();
