<?php
/**
 * Plugin Name: Scriptronaut Beta Manager
 * Description: Manages Scriptronaut beta signups, testers, feedback, attachments, and newsletter opt-ins from static pages hosted on the same domain.
 * Version: 1.4.2
 * Author: Scriptronaut
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) { exit; }

final class Scriptronaut_Beta_Manager {
    const VERSION = '1.4.2';
    const OPT = 'scriptronaut_beta_manager_settings';
    const MENU = 'scriptronaut-beta-manager';

    private static $instance = null;
    private $tables = [];

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->tables = [
            'candidates' => $wpdb->prefix . 'scriptronaut_beta_candidates',
            'testers' => $wpdb->prefix . 'scriptronaut_beta_testers',
            'programs' => $wpdb->prefix . 'scriptronaut_beta_tester_programs',
            'feedback' => $wpdb->prefix . 'scriptronaut_beta_feedback',
            'newsletter' => $wpdb->prefix . 'scriptronaut_beta_newsletter',
        ];

        add_action('init', [$this, 'maybe_upgrade'], 1);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_post_nopriv_scriptronaut_beta_signup', [$this, 'handle_signup']);
        add_action('admin_post_scriptronaut_beta_signup', [$this, 'handle_signup']);
        add_action('admin_post_nopriv_scriptronaut_beta_newsletter', [$this, 'handle_newsletter']);
        add_action('admin_post_scriptronaut_beta_newsletter', [$this, 'handle_newsletter']);
        add_action('admin_post_nopriv_scriptronaut_beta_feedback', [$this, 'handle_feedback']);
        add_action('admin_post_scriptronaut_beta_feedback', [$this, 'handle_feedback']);
        add_action('admin_post_scriptronaut_beta_approve', [$this, 'approve_candidate']);
        add_action('admin_post_scriptronaut_beta_disable_tester', [$this, 'disable_tester']);
        add_action('admin_post_scriptronaut_beta_enable_tester', [$this, 'enable_tester']);
        add_action('admin_post_scriptronaut_beta_regenerate_code', [$this, 'regenerate_code']);
        add_action('admin_post_scriptronaut_beta_export_newsletter', [$this, 'export_newsletter']);
        add_action('admin_post_scriptronaut_beta_export_candidates', [$this, 'export_candidates']);
        add_action('admin_post_scriptronaut_beta_feedback_status', [$this, 'update_feedback_status']);
        add_action('admin_post_scriptronaut_beta_delete_feedback', [$this, 'delete_feedback']);
        add_action('admin_post_scriptronaut_beta_create_zoho_task', [$this, 'create_zoho_task_from_feedback']);
        add_action('admin_post_scriptronaut_beta_sync_zoho_task', [$this, 'sync_zoho_task_status']);
        add_action('admin_post_scriptronaut_beta_sync_all_zoho_tasks', [$this, 'sync_all_zoho_task_statuses']);
        add_action('admin_post_scriptronaut_beta_retry_zoho_attachments', [$this, 'retry_zoho_attachments']);
        add_action('admin_post_scriptronaut_beta_open_zoho_task', [$this, 'open_zoho_task']);
        add_action('admin_post_scriptronaut_beta_delete_candidate', [$this, 'delete_candidate']);
        add_action('admin_post_scriptronaut_beta_delete_tester', [$this, 'delete_tester']);
        add_action('admin_post_scriptronaut_beta_unsubscribe_newsletter', [$this, 'unsubscribe_newsletter']);
        add_action('admin_post_scriptronaut_beta_delete_newsletter', [$this, 'delete_newsletter']);
        add_filter('upload_mimes', [$this, 'beta_upload_mimes']);
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix;

        // v1.1+: the same email may apply to more than one beta program.
        $candidate_table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", "{$p}scriptronaut_beta_candidates"));
        $candidate_indexes = $candidate_table_exists ? $wpdb->get_results("SHOW INDEX FROM {$p}scriptronaut_beta_candidates", ARRAY_A) : [];
        if (is_array($candidate_indexes)) {
            foreach ($candidate_indexes as $index) {
                if (($index['Key_name'] ?? '') === 'email' && intval($index['Non_unique'] ?? 1) === 0) {
                    $wpdb->query("ALTER TABLE {$p}scriptronaut_beta_candidates DROP INDEX email");
                    break;
                }
            }
        }

        dbDelta("CREATE TABLE {$p}scriptronaut_beta_candidates (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(120) NOT NULL,
            email varchar(254) NOT NULL,
            addon_id varchar(80) NOT NULL DEFAULT 'qc_checker',
            blender_use varchar(80) NOT NULL,
            blender_version varchar(20) NOT NULL,
            newsletter_optin tinyint(1) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'pending',
            ip_address varchar(64) NOT NULL DEFAULT '',
            submitted_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY email_addon (email, addon_id),
            KEY email (email),
            KEY addon_id (addon_id),
            KEY status (status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}scriptronaut_beta_testers (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            candidate_id bigint(20) unsigned NULL,
            tester_id varchar(80) NOT NULL,
            name varchar(120) NOT NULL,
            email varchar(254) NOT NULL,
            access_hash varchar(255) NOT NULL,
            active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY tester_id (tester_id),
            UNIQUE KEY email (email),
            KEY active (active)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}scriptronaut_beta_tester_programs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tester_id bigint(20) unsigned NOT NULL,
            addon_id varchar(80) NOT NULL,
            candidate_id bigint(20) unsigned NULL,
            active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY tester_addon (tester_id, addon_id),
            KEY addon_id (addon_id),
            KEY active (active)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}scriptronaut_beta_feedback (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tester_id varchar(80) NOT NULL,
            tester_email varchar(254) NOT NULL DEFAULT '',
            addon_id varchar(80) NOT NULL DEFAULT 'qc_checker',
            report_type varchar(40) NOT NULL,
            tier varchar(40) NOT NULL,
            category varchar(80) NOT NULL DEFAULT '',
            check_name varchar(180) NOT NULL DEFAULT '',
            check_id varchar(180) NOT NULL DEFAULT '',
            summary varchar(180) NOT NULL,
            details longtext NOT NULL,
            steps longtext NULL,
            expected_result text NULL,
            actual_result text NULL,
            qc_version varchar(40) NOT NULL DEFAULT '',
            blender_version varchar(80) NOT NULL DEFAULT '',
            operating_system varchar(240) NOT NULL DEFAULT '',
            blend_filename varchar(255) NOT NULL DEFAULT '',
            traceback longtext NULL,
            traceback_time varchar(80) NOT NULL DEFAULT '',
            source varchar(80) NOT NULL DEFAULT '',
            attachments longtext NULL,
            ip_address varchar(64) NOT NULL DEFAULT '',
            status varchar(20) NOT NULL DEFAULT 'new',
            status_updated_at datetime NULL,
            zoho_task_id varchar(80) NOT NULL DEFAULT '',
            zoho_task_prefix varchar(80) NOT NULL DEFAULT '',
            zoho_task_created_at datetime NULL,
            submitted_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY tester_id (tester_id),
            KEY addon_id (addon_id),
            KEY report_type (report_type),
            KEY status (status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}scriptronaut_beta_newsletter (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(120) NOT NULL,
            email varchar(254) NOT NULL,
            source varchar(80) NOT NULL DEFAULT 'beta_signup',
            subscribed tinyint(1) NOT NULL DEFAULT 1,
            consent_at datetime NOT NULL,
            ip_address varchar(64) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            KEY subscribed (subscribed)
        ) $charset;");

        // Backfill beta-program enrollment for records created before addon_id support.
        $approved = $wpdb->get_results("SELECT id,email,addon_id FROM {$p}scriptronaut_beta_candidates WHERE status='approved'", ARRAY_A);
        foreach ((array)$approved as $candidate) {
            $tester_db_id = intval($wpdb->get_var($wpdb->prepare("SELECT id FROM {$p}scriptronaut_beta_testers WHERE email=%s", $candidate['email'])));
            if (!$tester_db_id) continue;
            $addon_id = sanitize_key($candidate['addon_id'] ?: 'qc_checker');
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$p}scriptronaut_beta_tester_programs WHERE tester_id=%d AND addon_id=%s", $tester_db_id, $addon_id));
            if (!$exists) {
                $now = current_time('mysql', true);
                $wpdb->insert("{$p}scriptronaut_beta_tester_programs", [
                    'tester_id'=>$tester_db_id, 'addon_id'=>$addon_id, 'candidate_id'=>intval($candidate['id']),
                    'active'=>1, 'created_at'=>$now, 'updated_at'=>$now
                ]);
            }
        }

        $defaults = [
            'recipient' => get_option('admin_email'),
            'from_email' => get_option('admin_email'),
            'from_name' => 'Scriptronaut',
            'subject_prefix' => '[Scriptronaut Beta]',
            'email_feedback_notifications' => 1,
            'max_file_mb' => 8,
            'max_total_mb' => 20,
            'rate_limit_count' => 12,
            'rate_limit_window' => 3600,
            'static_beta_url' => preg_replace('#/wp/?$#', '', site_url()) . '/scriptronaut/betas.html',
            'static_feedback_url' => preg_replace('#/wp/?$#', '', site_url()) . '/scriptronaut/beta-feedback.html',
            'zoho_enabled' => 0,
            'zoho_client_id' => '', 'zoho_client_secret' => '', 'zoho_refresh_token' => '',
            'zoho_portal_id' => '', 'zoho_portal_name' => 'scriptronaut', 'zoho_project_id' => '',
            'zoho_project_mappings' => [],
            'zoho_general_tasklist_id' => '',
        ];
        if (!get_option(self::OPT)) {
            add_option(self::OPT, $defaults);
        } else {
            $existing_settings=(array)get_option(self::OPT,[]);
            if (($existing_settings['subject_prefix'] ?? '') === '[QC Checker Beta]') {
                $existing_settings['subject_prefix']='[Scriptronaut Beta]';
                update_option(self::OPT,$existing_settings);
            }
        }
        update_option('scriptronaut_beta_manager_db_version', self::VERSION);
    }

    public function maybe_upgrade() {
        $installed = (string)get_option('scriptronaut_beta_manager_db_version', '');
        if ($installed !== self::VERSION) {
            self::activate();
        }
    }


    public function beta_upload_mimes($mimes) {
        // Feedback attachments supported by Scriptronaut Beta Manager.
        $mimes['txt']   = 'text/plain';
        $mimes['log']   = 'text/plain';
        $mimes['png']   = 'image/png';
        $mimes['jpg']   = 'image/jpeg';
        $mimes['jpeg']  = 'image/jpeg';
        $mimes['zip']   = 'application/zip';
        return $mimes;
    }


    private function local_datetime($mysql_datetime) {
        if (empty($mysql_datetime)) return '';
        try {
            $dt = \DateTimeImmutable::createFromFormat(
                'Y-m-d H:i:s',
                $mysql_datetime,
                new \DateTimeZone('UTC')
            );
            if (!$dt) return $mysql_datetime;
            return $dt->setTimezone(new \DateTimeZone('America/Toronto'))->format('Y-m-d H:i:s');
        } catch (\Exception $e) {
            return $mysql_datetime;
        }
    }

    private function settings() {
        return wp_parse_args((array)get_option(self::OPT, []), [
            'recipient' => get_option('admin_email'), 'from_email' => get_option('admin_email'),
            'from_name' => 'Scriptronaut', 'subject_prefix' => '[Scriptronaut Beta]',
            'email_feedback_notifications' => 1,
            'max_file_mb' => 8, 'max_total_mb' => 20, 'rate_limit_count' => 12,
            'rate_limit_window' => 3600, 'static_beta_url' => preg_replace('#/wp/?$#', '', site_url()) . '/scriptronaut/betas.html',
            'static_feedback_url' => preg_replace('#/wp/?$#', '', site_url()) . '/scriptronaut/beta-feedback.html',
            'zoho_enabled' => 0,
            'zoho_client_id' => '', 'zoho_client_secret' => '', 'zoho_refresh_token' => '',
            'zoho_portal_id' => '', 'zoho_portal_name' => 'scriptronaut', 'zoho_project_id' => '',
            'zoho_project_mappings' => [],
            'zoho_general_tasklist_id' => '',
        ]);
    }

    public function register_settings() {
        register_setting('scriptronaut_beta_manager', self::OPT, [$this, 'sanitize_settings']);
    }

    public function sanitize_settings($v) {
        // Settings may contain a newly-authorized Zoho refresh token or changed
        // portal/project credentials. Never keep access/data caches generated
        // from the previous Zoho configuration after Settings is saved.
        delete_transient('snbm_zoho_access_token');
        delete_transient('snbm_zoho_users');
        delete_transient('snbm_zoho_statuses');
        delete_transient('snbm_zoho_bug_phase_id');
        delete_transient('snbm_zoho_beta_feedback_tag_id');
        delete_transient('snbm_zoho_projects');

        $project_mappings=[];
        foreach ((array)($v['zoho_project_mappings'] ?? []) as $product=>$project_id) {
            $product=sanitize_text_field((string)$product);
            $project_id=preg_replace('/\D+/', '', (string)$project_id);
            if ($product !== '' && $project_id !== '') $project_mappings[$product]=$project_id;
        }

        return [
            'recipient' => sanitize_email($v['recipient'] ?? ''),
            'from_email' => sanitize_email($v['from_email'] ?? ''),
            'from_name' => sanitize_text_field($v['from_name'] ?? 'Scriptronaut'),
            'subject_prefix' => sanitize_text_field($v['subject_prefix'] ?? '[Scriptronaut Beta]'),
            'email_feedback_notifications' => !empty($v['email_feedback_notifications']) ? 1 : 0,
            'max_file_mb' => max(1, min(50, intval($v['max_file_mb'] ?? 8))),
            'max_total_mb' => max(1, min(100, intval($v['max_total_mb'] ?? 20))),
            'rate_limit_count' => max(1, min(100, intval($v['rate_limit_count'] ?? 12))),
            'rate_limit_window' => max(60, min(DAY_IN_SECONDS, intval($v['rate_limit_window'] ?? 3600))),
            'static_beta_url' => esc_url_raw($v['static_beta_url'] ?? ''),
            'static_feedback_url' => esc_url_raw($v['static_feedback_url'] ?? ''),
            'zoho_enabled' => !empty($v['zoho_enabled']) ? 1 : 0,
            'zoho_client_id' => sanitize_text_field($v['zoho_client_id'] ?? ''),
            'zoho_client_secret' => sanitize_text_field($v['zoho_client_secret'] ?? ''),
            'zoho_refresh_token' => sanitize_text_field($v['zoho_refresh_token'] ?? ''),
            'zoho_portal_id' => preg_replace('/\D+/', '', (string)($v['zoho_portal_id'] ?? '')),
            'zoho_portal_name' => sanitize_title($v['zoho_portal_name'] ?? 'scriptronaut'),
            'zoho_project_id' => preg_replace('/\D+/', '', (string)($v['zoho_project_id'] ?? '')),
            'zoho_project_mappings' => $project_mappings,
            'zoho_general_tasklist_id' => preg_replace('/\D+/', '', (string)($v['zoho_general_tasklist_id'] ?? '')),
        ];
    }

    private function client_ip() { return sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? 'unknown'); }

    private function rate_limit($kind) {
        $s = $this->settings();
        $key = 'snbm_rl_' . md5($kind . '|' . $this->client_ip());
        $data = get_transient($key);
        if (!is_array($data)) $data = ['count' => 0];
        if ($data['count'] >= $s['rate_limit_count']) $this->response(false, 'Too many attempts', 'Please wait before submitting again.', $kind === 'signup' ? 'beta' : 'feedback');
        $data['count']++;
        set_transient($key, $data, $s['rate_limit_window']);
    }

    private function post($key, $limit = 1000) {
        $value = isset($_POST[$key]) && is_string($_POST[$key]) ? trim(wp_unslash($_POST[$key])) : '';
        if (strlen($value) > $limit) $this->response(false, 'Could not submit', 'One of the submitted fields is too long.', 'beta');
        return $value;
    }

    private function response($ok, $title, $message, $return = 'beta') {
        $s = $this->settings();
        $url = $return === 'feedback' ? $s['static_feedback_url'] : $s['static_beta_url'];
        $posted_addon = isset($_POST['addon_id']) && is_string($_POST['addon_id']) ? $this->normalize_addon_id(wp_unslash($_POST['addon_id'])) : '';
        if ($posted_addon && $url) $url = add_query_arg('addon_id', $posted_addon, $url);
        status_header($ok ? 200 : 400);
        nocache_headers();
        ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?php echo esc_html($title); ?> — Scriptronaut</title>
        <style>body{margin:0;background:#100f28;color:#eee;font-family:Inter,Arial,sans-serif;min-height:100vh;display:grid;place-items:center}.card{max-width:680px;margin:30px;padding:36px;border-radius:18px;background:#242044;border:1px solid #514a78;box-shadow:0 18px 50px #0006}.ok{border-color:#64d889}.bad{border-color:#ff6f6f}h1{margin-top:0;color:#fc842c}.button{display:inline-block;margin-top:18px;padding:12px 18px;border-radius:9px;background:#9478ec;color:#fff;text-decoration:none;font-weight:700}</style></head><body><main class="card <?php echo $ok ? 'ok' : 'bad'; ?>"><h1><?php echo esc_html($title); ?></h1><p><?php echo esc_html($message); ?></p><a class="button" href="<?php echo esc_url($url); ?>">Return to Scriptronaut</a></main></body></html><?php
        exit;
    }

    private function send_mail($subject, $plain, $reply_to = '', $attachments = []) {
        $s = $this->settings();
        $headers = ['From: ' . $s['from_name'] . ' <' . $s['from_email'] . '>', 'Content-Type: text/plain; charset=UTF-8'];
        if ($reply_to && is_email($reply_to)) $headers[] = 'Reply-To: ' . $reply_to;
        return wp_mail($s['recipient'], $subject, $plain, $headers, $attachments);
    }

    private function normalize_addon_id($value) {
        $id = sanitize_key((string)$value);
        return $id ?: 'qc_checker';
    }

    private function addon_label($addon_id) {
        $labels = [
            'qc_checker' => 'QC Checker',
            'publisher' => 'Publisher',
            'rigging_pack' => 'Rigging Pack',
        ];
        $addon_id = $this->normalize_addon_id($addon_id);
        return $labels[$addon_id] ?? ucwords(str_replace(['-', '_'], ' ', $addon_id));
    }

    private function tagged_subject($addon_id, $suffix) {
        $s = $this->settings();
        return trim($s['subject_prefix']) . ' [' . $this->addon_label($addon_id) . '] ' . ltrim($suffix);
    }

    private function feedback_url_for_addon($addon_id) {
        $s = $this->settings();
        if (empty($s['static_feedback_url'])) return '';
        return add_query_arg('addon_id', $this->normalize_addon_id($addon_id), $s['static_feedback_url']);
    }

    private function send_tester_credentials($to, $name, $tester_id, $access_code, $addon_id = 'qc_checker', $replacement = false) {
        if (!is_email($to)) return false;
        $s = $this->settings();
        $headers = ['From: ' . $s['from_name'] . ' <' . $s['from_email'] . '>', 'Content-Type: text/plain; charset=UTF-8'];
        if (is_email($s['recipient'])) $headers[] = 'Reply-To: ' . $s['recipient'];

        if ($replacement) {
            $subject = $this->tagged_subject($addon_id, 'Your new beta credentials');
            $plain = "Hi " . $name . ",

"
                . "Here are your new credentials for the Scriptronaut " . $this->addon_label($addon_id) . " beta.

"
                . "Tester ID: " . $tester_id . "
"
                . "New access code: " . $access_code . "

"
                . "Your previous access code is no longer valid. Please use these credentials the next time you access the " . $this->addon_label($addon_id) . " beta.

"
                . "Keep this access code somewhere safe. It is stored by Scriptronaut only as a secure hash and cannot be recovered later.
";
        } else {
            $subject = $this->tagged_subject($addon_id, 'Your beta tester access');
            $plain = "Hi " . $name . ",

"
                . "You have been approved as a Scriptronaut " . $this->addon_label($addon_id) . " beta tester.

"
                . "Tester ID: " . $tester_id . "
"
                . "Access code: " . $access_code . "

"
                . "Keep this access code somewhere safe. It is stored by Scriptronaut only as a secure hash and cannot be recovered later.
";
        }

        $feedback_url = $this->feedback_url_for_addon($addon_id);
        if ($feedback_url) {
            $plain .= "
Beta feedback form:
" . $feedback_url . "
";
        }

        $plain .= "
Thanks for helping test " . $this->addon_label($addon_id) . ".

Scriptronaut
";
        return wp_mail($to, $subject, $plain, $headers);
    }

    public function handle_signup() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') $this->response(false, 'Invalid request', 'Please use the signup form on the beta page.', 'beta');
        $this->rate_limit('signup');
        if ($this->post('website', 200) !== '') $this->response(true, 'Signup received', 'Thank you for your interest in testing QC Checker.', 'beta');

        $addon_id = $this->normalize_addon_id($this->post('addon_id', 80));
        $name = sanitize_text_field($this->post('name', 120));
        $email = sanitize_email($this->post('email', 254));
        $use = sanitize_text_field($this->post('blender_use', 80));
        $version = sanitize_text_field($this->post('blender_version', 20));
        $newsletter = isset($_POST['newsletter_optin']) && wp_unslash($_POST['newsletter_optin']) === 'yes' ? 1 : 0;
        $allowed = ['VFX/Animation','ArchViz','Games','Freelance 3D','Technical Artist','Other'];
        if (!$name || !is_email($email) || !in_array($use, $allowed, true) || !preg_match('/^[0-9]+(?:\.[0-9]+){1,2}$/', $version)) {
            $this->response(false, 'Invalid information', 'Check the required fields and try again.', 'beta');
        }

        global $wpdb; $now = current_time('mysql', true);
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tables['candidates']} WHERE email=%s AND addon_id=%s", strtolower($email), $addon_id));
        $data = ['name'=>$name,'email'=>strtolower($email),'addon_id'=>$addon_id,'blender_use'=>$use,'blender_version'=>$version,'newsletter_optin'=>$newsletter,'ip_address'=>$this->client_ip(),'updated_at'=>$now];
        if ($existing) $wpdb->update($this->tables['candidates'], $data, ['id'=>$existing]);
        else { $data['status']='pending'; $data['submitted_at']=$now; $wpdb->insert($this->tables['candidates'], $data); }

        if ($newsletter) {
            // Relay owns newsletter subscriptions when it is installed and active.
            if (function_exists('scriptronaut_relay_subscribe')) {
                scriptronaut_relay_subscribe($name, strtolower($email), 'beta_signup', $this->client_ip());
            } else {
                // Safety fallback: preserve consent if Relay is temporarily inactive.
                // Relay's Import / Update from Beta Manager tool can migrate this record later.
                $nid = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tables['newsletter']} WHERE email=%s", strtolower($email)));
                $nd = ['name'=>$name,'email'=>strtolower($email),'source'=>'beta_signup_relay_fallback','subscribed'=>1,'consent_at'=>$now,'ip_address'=>$this->client_ip()];
                if ($nid) $wpdb->update($this->tables['newsletter'], $nd, ['id'=>$nid]); else $wpdb->insert($this->tables['newsletter'], $nd);
            }
        }

        $s = $this->settings();
        $subject = $this->tagged_subject($addon_id, 'Signup: ' . $name);
        $plain = $this->addon_label($addon_id) . " beta signup\n\nAdd-on: " . $this->addon_label($addon_id) . " ($addon_id)\nName: $name\nEmail: $email\nMain Blender use: $use\nBlender version: $version\nNewsletter: " . ($newsletter ? 'Yes' : 'No') . "\nIP: " . $this->client_ip();
        $this->send_mail($subject, $plain, $email);
        $this->response(true, 'Signup received', 'Thank you. We will contact you at the email address you provided.', 'beta');
    }


    public function handle_newsletter() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') $this->response(false, 'Invalid request', 'Please use the newsletter signup form.', 'beta');
        $this->rate_limit('newsletter');
        if ($this->post('website', 200) !== '') $this->response(true, 'Subscription received', 'Thank you for subscribing.', 'beta');
        $name = sanitize_text_field($this->post('name', 120));
        $email = sanitize_email($this->post('email', 254));
        if (!$name || !is_email($email)) $this->response(false, 'Invalid information', 'Enter your name and a valid email address.', 'beta');
        global $wpdb; $now=current_time('mysql', true); $email=strtolower($email);
        if (function_exists('scriptronaut_relay_subscribe')) {
            scriptronaut_relay_subscribe($name, $email, 'newsletter_form', $this->client_ip());
        } else {
            // Compatibility fallback while an old static form still points at Beta Manager.
            $id=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tables['newsletter']} WHERE email=%s",$email));
            $data=['name'=>$name,'email'=>$email,'source'=>'newsletter_form_relay_fallback','subscribed'=>1,'consent_at'=>$now,'ip_address'=>$this->client_ip()];
            if($id)$wpdb->update($this->tables['newsletter'],$data,['id'=>$id]); else $wpdb->insert($this->tables['newsletter'],$data);
        }
        $s=$this->settings();
        $this->send_mail($s['subject_prefix'].' Newsletter signup: '.$name,"Scriptronaut newsletter signup\n\nName: $name\nEmail: $email\nIP: ".$this->client_ip(),$email);
        $this->response(true,'Subscription received','Thank you. You are subscribed to Scriptronaut news and beta updates.','beta');
    }

    private function tester_by_credentials($tester_id, $access_code) {
        global $wpdb;
        $tester = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['testers']} WHERE tester_id=%s AND active=1", strtolower($tester_id)), ARRAY_A);
        if (!$tester || !wp_check_password($access_code, $tester['access_hash'])) return false;
        return $tester;
    }

    public function handle_feedback() {
        global $wpdb;
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') $this->response(false, 'Invalid request', 'Please use the beta feedback form.', 'feedback');
        $this->rate_limit('feedback');
        if ($this->post('website', 200) !== '') $this->response(true, 'Feedback received', 'Thank you for helping test QC Checker.', 'feedback');

        $addon_id = $this->normalize_addon_id($this->post('addon_id', 80));
        $tester_id = strtolower(sanitize_key($this->post('tester_id', 80)));
        $access_code = isset($_POST['access_code']) && is_string($_POST['access_code']) ? wp_unslash($_POST['access_code']) : '';
        $tester = $this->tester_by_credentials($tester_id, $access_code);
        if (!$tester) $this->response(false, 'Access not recognized', 'Check your tester ID and access code, then try again.', 'feedback');
        $program = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->tables['programs']} WHERE tester_id=%d AND addon_id=%s AND active=1",
            intval($tester['id']), $addon_id
        ));
        if (!$program) $this->response(false, 'Beta access not recognized', 'This tester account is not enrolled in the selected beta program.', 'feedback');

        $fields = [
            'report_type'=>[40,'text'], 'tier'=>[40,'text'], 'category'=>[80,'text'], 'check_name'=>[180,'text'], 'check_id'=>[180,'text'],
            'summary'=>[180,'text'], 'details'=>[12000,'area'], 'steps'=>[8000,'area'], 'expected_result'=>[4000,'area'], 'actual_result'=>[4000,'area'],
            'qc_version'=>[40,'text'], 'blender_version'=>[80,'text'], 'operating_system'=>[240,'text'], 'blend_filename'=>[255,'text'],
            'traceback'=>[30000,'area'], 'traceback_time'=>[80,'text'], 'source'=>[80,'text']
        ];
        $v=[]; foreach ($fields as $k=>$spec) { $raw=$this->post($k,$spec[0]); $v[$k]=$spec[1]==='area'?sanitize_textarea_field($raw):sanitize_text_field($raw); }
        if (!$v['report_type'] || !$v['tier'] || !$v['summary'] || !$v['details']) $this->response(false, 'Missing information', 'Complete the required feedback fields.', 'feedback');
        if ($v['report_type']==='check_issue' && (!$v['category'] || !$v['check_name'])) $this->response(false, 'Missing check', 'Choose the category and check that had the issue.', 'feedback');

        $attachments = $this->handle_uploads();
        global $wpdb;
        $wpdb->insert($this->tables['feedback'], [
            'tester_id'=>$tester_id,'tester_email'=>$tester['email'],'addon_id'=>$addon_id,'report_type'=>$v['report_type'],'tier'=>$v['tier'],'category'=>$v['category'],
            'check_name'=>$v['check_name'],'check_id'=>$v['check_id'],'summary'=>$v['summary'],'details'=>$v['details'],'steps'=>$v['steps'],
            'expected_result'=>$v['expected_result'],'actual_result'=>$v['actual_result'],'qc_version'=>$v['qc_version'],'blender_version'=>$v['blender_version'],
            'operating_system'=>$v['operating_system'],'blend_filename'=>$v['blend_filename'],'traceback'=>$v['traceback'],'traceback_time'=>$v['traceback_time'],
            'source'=>$v['source'],'attachments'=>wp_json_encode(array_map(function($a){return ['name'=>$a['name'],'url'=>$a['url']];},$attachments)),
            'ip_address'=>$this->client_ip(),'status'=>'new','status_updated_at'=>current_time('mysql', true),'submitted_at'=>current_time('mysql', true)
        ]);

        $feedback_id = intval($wpdb->insert_id);
        $s=$this->settings();
        if (!empty($s['email_feedback_notifications'])) {
            $subject=$this->tagged_subject($addon_id, 'Feedback: '.$v['summary']);
            $detail_url=admin_url('admin.php?page='.self::MENU.'-feedback&feedback_id='.$feedback_id);
            $plain=$this->addon_label($addon_id)." beta feedback\n\nAdd-on: ".$this->addon_label($addon_id)." ($addon_id)\nTester: {$tester['name']} ({$tester_id})\nEmail: {$tester['email']}\nType: {$v['report_type']}\nProduct: {$v['tier']}\nCategory: {$v['category']}\nCheck: {$v['check_name']}\nSummary: {$v['summary']}\n\nDetails:\n{$v['details']}\n\nBlender: {$v['blender_version']}\nQC Checker: {$v['qc_version']}\nOS: {$v['operating_system']}\n\nOpen in Beta Manager:\n{$detail_url}";
            $this->send_mail($subject,$plain,$tester['email'],array_column($attachments,'path'));
        }
        $this->response(true, 'Feedback received', 'Thank you. Your report has been saved successfully.', 'feedback');
    }

    private function handle_uploads() {
        if (empty($_FILES['attachments']) || !is_array($_FILES['attachments']['name'])) return [];
        if (empty($_POST['upload_confirmation'])) return [];
        $s=$this->settings(); $max=intval($s['max_file_mb'])*MB_IN_BYTES; $maxTotal=intval($s['max_total_mb'])*MB_IN_BYTES; $total=0; $out=[];
        require_once ABSPATH.'wp-admin/includes/file.php';
        $names=$_FILES['attachments']['name'];
        foreach ($names as $i=>$name) {
            if (!$name || ($_FILES['attachments']['error'][$i] ?? UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) continue;
            $size=intval($_FILES['attachments']['size'][$i] ?? 0); $total += $size;
            if ($size>$max || $total>$maxTotal) $this->response(false,'Attachment too large','One or more attachments exceed the configured upload limit.','feedback');
            $file=['name'=>sanitize_file_name($name),'type'=>$_FILES['attachments']['type'][$i] ?? '','tmp_name'=>$_FILES['attachments']['tmp_name'][$i] ?? '','error'=>$_FILES['attachments']['error'][$i] ?? UPLOAD_ERR_NO_FILE,'size'=>$size];
            $allowed=[
            'txt'=>'text/plain',
            'log'=>'text/plain',
            'png'=>'image/png',
            'jpg'=>'image/jpeg',
            'jpeg'=>'image/jpeg',
            'zip'=>'application/zip',
        ];
            $upload=wp_handle_upload($file,['test_form'=>false,'mimes'=>$allowed]);
            if (!empty($upload['error'])) $this->response(false,'Upload failed',$upload['error'],'feedback');
            $out[]=['name'=>basename($upload['file']),'path'=>$upload['file'],'url'=>$upload['url']];
        }
        return $out;
    }

    public function admin_menu() {
        add_menu_page('Scriptronaut Beta Manager','Beta Manager','manage_options',self::MENU,[$this,'page_dashboard'],'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4NCjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+DQo8IS0tIENyZWF0b3I6IENvcmVsRFJBVyAyMDIxICg2NC1CaXQpIC0tPg0KPHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSIzMnB4IiBoZWlnaHQ9IjMycHgiIHZlcnNpb249IjEuMSIgc2hhcGUtcmVuZGVyaW5nPSJnZW9tZXRyaWNQcmVjaXNpb24iIHRleHQtcmVuZGVyaW5nPSJnZW9tZXRyaWNQcmVjaXNpb24iIGltYWdlLXJlbmRlcmluZz0ib3B0aW1pemVRdWFsaXR5IiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCINCnZpZXdCb3g9IjAgMCA3LjkgNy45Ig0KIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIg0KIHhtbG5zOnhvZG09Imh0dHA6Ly93d3cuY29yZWwuY29tL2NvcmVsZHJhdy9vZG0vMjAwMyI+DQogPGcgaWQ9IkxheWVyX3gwMDIwXzEiPg0KICA8bWV0YWRhdGEgaWQ9IkNvcmVsQ29ycElEXzBDb3JlbC1MYXllciIvPg0KICA8cGF0aCBmaWxsPSIjRTZFNkU2IiBkPSJNMi44MiAwbC0yLjI2IDBjLTAuMzEsMCAtMC41NiwwLjI1IC0wLjU2LDAuNTZsMCAyLjI2YzAsMC4zMSAwLjI1LDAuNTcgMC41NiwwLjU3bDAuOSAwYy0wLjMyLC0wLjYzIC0wLjU4LC0xLjIzIC0wLjc2LC0xLjcxIC0wLjA3LC0wLjEyIC0wLjExLC0wLjI0IC0wLjExLC0wLjM1IDAuNTUsMC44OCAxLDEuODMgMS42NywyLjYyIDAuMDUsMC4wNyAwLjE3LDAuMDUgMC4yNywwLjA2IC0wLjA3LDAuMTIgLTAuMSwwLjI1IC0wLjEsMC40IDAsMC42NSAwLjY2LDEuMDMgMS4xOSwwLjggMC4zMywwLjg0IC0wLjc0LDEuNTUgLTEuMzksMC45bC0wLjgyIC0wLjgyIDAgLTAuNzdjMCwtMC4xNiAtMC4xMywtMC4yOSAtMC4yOCwtMC4yOWwtMC44NSAwYy0wLjE1LDAgLTAuMjgsMC4xMyAtMC4yOCwwLjI5bDAgMC44NGMwLDAuMTYgMC4xMywwLjI5IDAuMjgsMC4yOWwwLjc4IDAgMC44MiAwLjgyYzAuMjYsMC4yNiAwLjYxLDAuMzkgMC45NSwwLjM5IDAuNzgsMCAxLjM0LC0wLjYyIDEuMzUsLTEuMzIgMC4wMywwLjAyIDAuMDYsMC4wNCAwLjA5LDAuMDUgMCwwLjAzIC0wLjAxLDAuMDYgMCwwLjA5IDAuMTQsMS4wOCAtMC4wMiwxLjg1IC0xLjEzLDEuNjkgLTAuMzMsLTAuMDQgLTAuNCwwLjQ1IC0wLjA3LDAuNSAwLjY3LDAuMDkgMS4xNSwtMC4wNiAxLjQ0LC0wLjQ4IDAuMDgsLTAuMTEgMC4xNCwtMC4yNCAwLjE5LC0wLjM4IDAuMTcsMC4zIDAuNDQsMC41OCAwLjgxLDAuODIgMC4yNywwLjE4IDAuNTUsLTAuMjMgMC4yNywtMC40MiAtMC41OSwtMC4zOSAtMC44NSwtMC44NCAtMC43OSwtMS40NCAwLjQzLDAuNzkgMS4xMiwxLjQyIDEuOTcsMS44OCAwLjI5LDAuMTYgMC41MywtMC4yOCAwLjI0LC0wLjQ0IC0wLjM2LC0wLjIgLTIuMTcsLTEuNjQgLTEuOCwtMi4wMSAwLjM3LC0wLjM3IDEuODEsMS40NCAyLjAxLDEuOCAwLjE2LDAuMjkgMC42LDAuMDUgMC40NCwtMC4yNCAtMC40NiwtMC44NSAtMS4wOSwtMS41NCAtMS44OCwtMS45NyAwLjYsLTAuMDYgMS4wNSwwLjIgMS40NCwwLjc5IDAuMTksMC4yOCAwLjYsMCAwLjQyLC0wLjI3IC0wLjI0LC0wLjM3IC0wLjUyLC0wLjY0IC0wLjgyLC0wLjgxIDAuMTQsLTAuMDUgMC4yNywtMC4xMSAwLjM4LC0wLjE5IDAuNDIsLTAuMjkgMC41NywtMC43NyAwLjQ4LC0xLjQ0IC0wLjA1LC0wLjMzIC0wLjU0LC0wLjI2IC0wLjUsMC4wNyAwLjE2LDEuMTEgLTAuNjEsMS4yNyAtMS42OSwxLjEzIC0wLjAzLC0wLjAxIC0wLjA2LDAgLTAuMDksMCAtMC4wMiwtMC4wMyAtMC4wMywtMC4wNiAtMC4wNSwtMC4wOSAwLjA3LDAgMC4xNSwtMC4wMSAwLjIyLC0wLjAyIDEuMDcsLTAuMiAxLjQ3LC0xLjUyIDAuNzEsLTIuMjhsLTAuODIgLTAuODIgMCAtMC43OGMwLC0wLjE1IC0wLjEzLC0wLjI4IC0wLjI5LC0wLjI4bC0wLjg0IDBjLTAuMTYsMCAtMC4yOSwwLjEzIC0wLjI5LDAuMjhsMCAwLjg1YzAsMC4xNSAwLjEzLDAuMjggMC4yOSwwLjI4bDAuNzcgMCAwLjgyIDAuODJjMC42NSwwLjY1IC0wLjA2LDEuNzMgLTAuOSwxLjM5IDAuMTMsLTAuMzEgMC4wNywtMC42OSAtMC4xOSwtMC45NCAtMC4yOSwtMC4zIC0wLjcsLTAuMzIgLTEuMDEsLTAuMTUgLTAuMDEsLTAuMSAwLjAxLC0wLjIyIC0wLjA2LC0wLjI3IC0wLjc4LC0wLjY1IC0xLjcsLTEuMSAtMi41NiwtMS42MyAwLjA5LDAgMC4xOSwwLjAyIDAuMjksMC4wNyAwLjQ3LDAuMjIgMS4wNywwLjQ4IDEuNzEsMC44bDAgLTAuOTRjMCwtMC4zMSAtMC4yNiwtMC41NiAtMC41NywtMC41NnptMS45OSAzLjY4Yy0wLjIyLDAuMjIgLTAuNTcsMC4yMiAtMC43OSwwIC0wLjIyLC0wLjIyIC0wLjIyLC0wLjU3IDAsLTAuNzkgMC4yMiwtMC4yMiAwLjU3LC0wLjIyIDAuNzksMCAwLjIyLDAuMjIgMC4yMiwwLjU3IDAsMC43OXptLTEuMTMgMS4xM2MtMC4yMiwwLjIyIC0wLjU3LDAuMjIgLTAuNzksMCAtMC4yMiwtMC4yMiAtMC4yMiwtMC41NyAwLC0wLjc5IDAuMjIsLTAuMjIgMC41NywtMC4yMiAwLjc5LDAgMC4yMiwwLjIyIDAuMjIsMC41NyAwLDAuNzl6Ii8+DQogPC9nPg0KPC9zdmc+DQo=',58);
        add_submenu_page(self::MENU,'Candidates','Candidates','manage_options',self::MENU.'-candidates',[$this,'page_candidates']);
        add_submenu_page(self::MENU,'Testers','Testers','manage_options',self::MENU.'-testers',[$this,'page_testers']);
        add_submenu_page(self::MENU,'Feedback','Feedback','manage_options',self::MENU.'-feedback',[$this,'page_feedback']);
        add_submenu_page(self::MENU,'Settings','Settings','manage_options',self::MENU.'-settings',[$this,'page_settings']);
    }

    private function admin_header($title) { echo '<div class="wrap"><h1>'.esc_html($title).'</h1>'; $this->show_code_notice(); }
    private function admin_footer() { echo '</div>'; }
    private function count($table,$where='1=1'){ global $wpdb; return intval($wpdb->get_var("SELECT COUNT(*) FROM {$this->tables[$table]} WHERE $where")); }

    public function page_dashboard() {
        echo '<div class="wrap">';
        $beta_icon_url = esc_url(plugins_url('assets/beta-manager.svg', __FILE__));
        echo '<style>.snbm-dashboard-logo{width:64px;height:64px;display:block;flex:0 0 64px;background-color:#9980fc;-webkit-mask:url("'.$beta_icon_url.'") center/contain no-repeat;mask:url("'.$beta_icon_url.'") center/contain no-repeat;}</style>';
        echo '<div style="display:flex;align-items:center;gap:14px;margin:14px 0 4px"><span class="snbm-dashboard-logo" role="img" aria-label="Beta Manager"></span><div><h1 style="margin:0 0 6px">Scriptronaut Beta Manager</h1><p style="margin:0">Manage beta applicants, approved testers, and feedback reports. Newsletter delivery is handled by Scriptronaut Relay.</p></div></div>';
        $this->show_code_notice();
        echo '<div style="margin-top:16px;display:flex;gap:16px;flex-wrap:wrap">';
        foreach ([['Candidates',$this->count('candidates',"status<>'approved'"),self::MENU.'-candidates'],['Active Testers',$this->count('testers','active=1'),self::MENU.'-testers'],['Feedback',$this->count('feedback'),self::MENU.'-feedback']] as $x) echo '<a href="'.esc_url(admin_url('admin.php?page='.$x[2])).'" style="min-width:180px;padding:18px;background:#fff;border:1px solid #ccd0d4;text-decoration:none"><strong style="font-size:28px">'.$x[1].'</strong><br>'.esc_html($x[0]).'</a>';
        echo '</div>';
        echo '<div style="margin-top:18px"><h2>Static page integration</h2><p>Beta signup action:</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_beta_signup')).'</code><p>Feedback action:</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_beta_feedback')).'</code><p>Newsletter-only action (Relay):</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_relay_subscribe')).'</code><p class="description">'.(function_exists('scriptronaut_relay_subscribe') ? 'Relay is active. Newsletter opt-ins from beta signup are sent directly to Relay.' : 'Relay is not active. Newsletter opt-ins are temporarily preserved in the legacy Beta Manager table for later import.').'</p></div>';
        $this->admin_footer();
    }

    public function page_candidates() {
        global $wpdb;

        $filter_use = isset($_GET['blender_use']) ? sanitize_text_field(wp_unslash($_GET['blender_use'])) : '';
        $filter_version = isset($_GET['blender_version']) ? sanitize_text_field(wp_unslash($_GET['blender_version'])) : '';
        $filter_status = isset($_GET['candidate_status']) ? sanitize_key(wp_unslash($_GET['candidate_status'])) : '';
        $filter_addon = isset($_GET['candidate_addon']) ? sanitize_key(wp_unslash($_GET['candidate_addon'])) : '';

        // Build filter choices from all candidate records so choices do not disappear while filtering.
        $addons = $wpdb->get_col("SELECT DISTINCT addon_id FROM {$this->tables['candidates']} WHERE addon_id <> '' ORDER BY addon_id ASC");
        $uses = $wpdb->get_col("SELECT DISTINCT blender_use FROM {$this->tables['candidates']} WHERE blender_use <> '' ORDER BY blender_use ASC");
        $versions = $wpdb->get_col("SELECT DISTINCT blender_version FROM {$this->tables['candidates']} WHERE blender_version <> '' ORDER BY blender_version ASC");
        $statuses = $wpdb->get_col("SELECT DISTINCT status FROM {$this->tables['candidates']} WHERE status <> '' AND status <> 'approved' ORDER BY status ASC");

        // The Candidates page is the active application inbox. Approved applicants
        // remain in the database for history, but are managed from Testers instead.
        $where=["status <> 'approved'"];
        $params=[];
        if($filter_addon!==''){ $where[]='addon_id=%s'; $params[]=$filter_addon; }
        if($filter_use!==''){ $where[]='blender_use=%s'; $params[]=$filter_use; }
        if($filter_version!==''){ $where[]='blender_version=%s'; $params[]=$filter_version; }
        if($filter_status!=='' && $filter_status!=='approved'){ $where[]='status=%s'; $params[]=$filter_status; }
        $sql="SELECT * FROM {$this->tables['candidates']}";
        if($where) $sql.=' WHERE '.implode(' AND ',$where);
        $sql.=' ORDER BY submitted_at DESC';
        if($params) $sql=$wpdb->prepare($sql,$params);
        $rows=$wpdb->get_results($sql,ARRAY_A);
        $total_candidates=intval($wpdb->get_var("SELECT COUNT(*) FROM {$this->tables['candidates']} WHERE status <> 'approved'"));

        $tester_rows=$wpdb->get_results("SELECT id,candidate_id,email,active FROM {$this->tables['testers']}",ARRAY_A);
        $testers_by_candidate=[];
        $testers_by_email=[];
        foreach($tester_rows as $tester){
            if(!empty($tester['candidate_id'])) $testers_by_candidate[intval($tester['candidate_id'])]=$tester;
            if(!empty($tester['email'])) $testers_by_email[strtolower($tester['email'])]=$tester;
        }

        $this->admin_header('Beta Candidates');
        if(!empty($_GET['deleted'])) echo '<div class="notice notice-success is-dismissible"><p>Candidate deleted. Newsletter subscriptions, tester accounts, and feedback were retained.</p></div>';
        echo '<p><a class="button" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_export_candidates'),'snbm_export_candidates')).'">Export CSV</a></p>';

        echo '<form method="get" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;margin:12px 0 16px;padding:12px;background:#fff;border:1px solid #c3c4c7;">';
        echo '<input type="hidden" name="page" value="'.esc_attr(self::MENU.'-candidates').'">';
        echo '<label><span style="display:block;font-weight:600;margin-bottom:4px">Add-on</span><select name="candidate_addon"><option value="">All</option>';
        foreach($addons as $value) echo '<option value="'.esc_attr($value).'" '.selected($filter_addon,$value,false).'>'.esc_html($this->addon_label($value)).'</option>';
        echo '</select></label>';
        echo '<label><span style="display:block;font-weight:600;margin-bottom:4px">Blender Use</span><select name="blender_use"><option value="">All</option>';
        foreach($uses as $value) echo '<option value="'.esc_attr($value).'" '.selected($filter_use,$value,false).'>'.esc_html($value).'</option>';
        echo '</select></label>';
        echo '<label><span style="display:block;font-weight:600;margin-bottom:4px">Version</span><select name="blender_version"><option value="">All</option>';
        foreach($versions as $value) echo '<option value="'.esc_attr($value).'" '.selected($filter_version,$value,false).'>'.esc_html($value).'</option>';
        echo '</select></label>';
        echo '<label><span style="display:block;font-weight:600;margin-bottom:4px">Status</span><select name="candidate_status"><option value="">All</option>';
        foreach($statuses as $value) echo '<option value="'.esc_attr($value).'" '.selected($filter_status,$value,false).'>'.esc_html(ucfirst($value)).'</option>';
        echo '</select></label>';
        echo '<button class="button button-primary" type="submit">Filter</button>';
        echo '<a class="button" href="'.esc_url(admin_url('admin.php?page='.self::MENU.'-candidates')).'">Reset</a>';
        echo '</form>';
        echo '<p><strong>Showing '.intval(count($rows)).' of '.$total_candidates.' candidates</strong></p>';

        echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Add-on</th><th>Blender Use</th><th>Version</th><th>Newsletter</th><th>Status</th><th>Submitted</th><th>Actions</th></tr></thead><tbody>';
        if(!$rows) echo '<tr><td colspan="9">No candidates match the selected filters.</td></tr>';
        foreach($rows as $r){
            echo '<tr><td>'.esc_html($r['name']).'</td><td><a href="mailto:'.esc_attr($r['email']).'">'.esc_html($r['email']).'</a></td><td>'.esc_html($this->addon_label($r['addon_id'] ?? 'qc_checker')).'</td><td>'.esc_html($r['blender_use']).'</td><td>'.esc_html($r['blender_version']).'</td><td>'.($r['newsletter_optin']?'Yes':'No').'</td><td>'.esc_html($r['status']).'</td><td>'.esc_html($this->local_datetime($r['submitted_at'])).'</td><td>';
            if($r['status']!=='approved'){
                echo '<a class="button button-primary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_approve&id='.$r['id']),'snbm_approve_'.$r['id'])).'">Approve</a> ';
            } else {
                $tester=$testers_by_candidate[intval($r['id'])] ?? $testers_by_email[strtolower($r['email'])] ?? null;
                if($tester){
                    $regen_url=admin_url('admin-post.php?action=scriptronaut_beta_regenerate_code&id='.intval($tester['id']).'&return=candidates&addon_id='.rawurlencode($r['addon_id'] ?? 'qc_checker'));
                    $regen_url=wp_nonce_url($regen_url,'snbm_regen_'.$tester['id']);
                    echo '<a class="button" href="'.esc_url($regen_url).'">Send New Access Code</a> ';
                } else {
                    echo '<span style="color:#646970">Tester record not found</span> ';
                }
            }
            $delete_url=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_delete_candidate&id='.intval($r['id'])),'snbm_delete_candidate_'.$r['id']);
            $confirm='Delete candidate '.($r['name'] ?: $r['email']).'? This permanently removes the candidate record. Newsletter subscriptions, tester accounts, and submitted feedback are not deleted.';
            echo '<a class="button button-link-delete" href="'.esc_url($delete_url).'" onclick="return confirm('.esc_attr(wp_json_encode($confirm)).');">Delete</a>';
            echo '</td></tr>';
        }
        echo '</tbody></table>'; $this->admin_footer();
    }

    private function unique_tester_id($email) { global $wpdb; $base=sanitize_key(strtok($email,'@')); if(!$base)$base='tester'; $id=$base;$n=2; while($wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tables['testers']} WHERE tester_id=%s",$id))){$id=$base.$n;$n++;} return $id; }
    private function generate_code(){ return strtoupper(wp_generate_password(12,false,false)); }

    public function approve_candidate() {
        if(!current_user_can('manage_options'))wp_die('Unauthorized'); $id=intval($_GET['id']??0); check_admin_referer('snbm_approve_'.$id);
        global $wpdb; $c=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['candidates']} WHERE id=%d",$id),ARRAY_A); if(!$c)wp_die('Candidate not found');
        $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['testers']} WHERE email=%s",$c['email']),ARRAY_A); $code=$this->generate_code(); $tid=$existing?$existing['tester_id']:$this->unique_tester_id($c['email']);
        $data=['candidate_id'=>$id,'tester_id'=>$tid,'name'=>$c['name'],'email'=>$c['email'],'access_hash'=>wp_hash_password($code),'active'=>1,'updated_at'=>current_time('mysql', true)];
        if($existing){
            $wpdb->update($this->tables['testers'],$data,['id'=>$existing['id']]);
            $tester_db_id=intval($existing['id']);
        } else {
            $data['created_at']=current_time('mysql', true);
            $wpdb->insert($this->tables['testers'],$data);
            $tester_db_id=intval($wpdb->insert_id);
        }
        $addon_id=$this->normalize_addon_id($c['addon_id'] ?? 'qc_checker');
        $program_id=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tables['programs']} WHERE tester_id=%d AND addon_id=%s",$tester_db_id,$addon_id));
        $program_data=['tester_id'=>$tester_db_id,'addon_id'=>$addon_id,'candidate_id'=>$id,'active'=>1,'updated_at'=>current_time('mysql', true)];
        if($program_id)$wpdb->update($this->tables['programs'],$program_data,['id'=>$program_id]);
        else{$program_data['created_at']=current_time('mysql', true);$wpdb->insert($this->tables['programs'],$program_data);}
        $wpdb->update($this->tables['candidates'],['status'=>'approved','updated_at'=>current_time('mysql', true)],['id'=>$id]);
        $mail_sent = $this->send_tester_credentials($c['email'], $c['name'], $tid, $code, $addon_id);
        set_transient('snbm_code_'.get_current_user_id(),['tester_id'=>$tid,'code'=>$code,'name'=>$c['name'],'email'=>$c['email'],'mail_sent'=>$mail_sent],120);
        wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-testers'));exit;
    }

    private function show_code_notice(){
        $k='snbm_code_'.get_current_user_id();
        $d=get_transient($k);
        if($d){
            delete_transient($k);
            $mail_sent = !empty($d['mail_sent']);
            $class = $mail_sent ? 'notice notice-success' : 'notice notice-warning';
            echo '<div class="'.esc_attr($class).'"><p><strong>Tester access created.</strong> Copy this now; the access code is stored only as a hash.</p><p>Tester ID: <code>'.esc_html($d['tester_id']).'</code> &nbsp; Access code: <code style="font-size:15px">'.esc_html($d['code']).'</code></p>';
            if($mail_sent){
                echo '<p><strong>Email sent</strong> to '.esc_html($d['email']).'.</p>';
            } else {
                echo '<p><strong>Email could not be sent automatically.</strong> Please copy the Tester ID and Access Code and send them manually.</p>';
            }
            echo '</div>';
        }
    }

    public function page_testers(){
        global $wpdb;

        $filter_addon = sanitize_key(wp_unslash($_GET['tester_addon'] ?? ''));
        $filter_status = sanitize_key(wp_unslash($_GET['tester_status'] ?? ''));

        $programs = $wpdb->get_col(
            "SELECT DISTINCT addon_id FROM {$this->tables['programs']} WHERE addon_id<>'' ORDER BY addon_id ASC"
        );

        $where = [];
        $params = [];
        if($filter_status === 'active') $where[] = 't.active=1';
        elseif($filter_status === 'disabled') $where[] = 't.active=0';

        $join = '';
        if($filter_addon !== ''){
            $join = " INNER JOIN {$this->tables['programs']} fp ON fp.tester_id=t.id AND fp.active=1 ";
            $where[] = 'fp.addon_id=%s';
            $params[] = $filter_addon;
        }

        $sql = "SELECT DISTINCT t.* FROM {$this->tables['testers']} t {$join}";
        if($where) $sql .= ' WHERE '.implode(' AND ', $where);
        $sql .= ' ORDER BY t.created_at DESC';
        $rows = $params ? $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);
        $total = intval($wpdb->get_var("SELECT COUNT(*) FROM {$this->tables['testers']}"));

        $this->admin_header('Beta Testers');
        if(!empty($_GET['deleted'])) echo '<div class="notice notice-success is-dismissible"><p>Tester deleted. Existing feedback was retained. A linked candidate, if any, was returned to pending status.</p></div>';

        echo '<form method="get" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin:12px 0 16px">';
        echo '<input type="hidden" name="page" value="'.esc_attr(self::MENU.'-testers').'">';

        echo '<label><span style="display:block;font-weight:600;margin-bottom:4px">Beta Program</span><select name="tester_addon"><option value="">All Beta Programs</option>';
        foreach($programs as $program_id){
            echo '<option value="'.esc_attr($program_id).'" '.selected($filter_addon,$program_id,false).'>'.esc_html($this->addon_label($program_id)).'</option>';
        }
        echo '</select></label>';

        echo '<label><span style="display:block;font-weight:600;margin-bottom:4px">Status</span><select name="tester_status">';
        echo '<option value="">All</option>';
        echo '<option value="active" '.selected($filter_status,'active',false).'>Active</option>';
        echo '<option value="disabled" '.selected($filter_status,'disabled',false).'>Disabled</option>';
        echo '</select></label>';

        echo '<button class="button button-primary" type="submit">Filter</button>';
        echo '<a class="button" href="'.esc_url(admin_url('admin.php?page='.self::MENU.'-testers')).'">Reset</a>';
        echo '</form>';

        echo '<p>Showing <strong>'.intval(count($rows)).'</strong> of <strong>'.$total.'</strong> testers.</p>';

        echo '<table class="widefat striped"><thead><tr><th>Tester ID</th><th>Name</th><th>Email</th><th>Beta Programs</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead><tbody>';
        if(!$rows) echo '<tr><td colspan="7">No testers match the selected filters.</td></tr>';

        foreach($rows as $r){
            $disable=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_disable_tester&id='.$r['id']),'snbm_disable_'.$r['id']);
            $enable=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_enable_tester&id='.$r['id']),'snbm_enable_'.$r['id']);
            $delete=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_delete_tester&id='.$r['id']),'snbm_delete_tester_'.$r['id']);
            $confirm='Delete tester '.$r['tester_id'].'? They will no longer be able to submit beta feedback. Existing feedback will be retained. This cannot be undone.';
            $program_ids=$wpdb->get_col($wpdb->prepare("SELECT addon_id FROM {$this->tables['programs']} WHERE tester_id=%d AND active=1 ORDER BY addon_id ASC",intval($r['id'])));
            $program_labels=array_map([$this,'addon_label'],$program_ids);

            echo '<tr><td><code>'.esc_html($r['tester_id']).'</code></td><td>'.esc_html($r['name']).'</td><td>'.esc_html($r['email']).'</td><td>'.esc_html(implode(', ',$program_labels)).'</td><td>'.($r['active']?'Active':'Disabled').'</td><td>'.esc_html($this->local_datetime($r['created_at'])).'</td><td>';

            foreach($program_ids as $program_addon_id){
                $regen_url=admin_url('admin-post.php?action=scriptronaut_beta_regenerate_code&id='.intval($r['id']).'&addon_id='.rawurlencode($program_addon_id));
                $regen_url=wp_nonce_url($regen_url,'snbm_regen_'.$r['id']);
                echo '<a class="button" href="'.esc_url($regen_url).'" title="Generate a new shared access code and email the '.esc_attr($this->addon_label($program_addon_id)).' feedback link">Send Access Email — '.esc_html($this->addon_label($program_addon_id)).'</a> ';
            }

            if($r['active']) echo '<a class="button" href="'.esc_url($disable).'">Disable</a> ';
            else echo '<a class="button" href="'.esc_url($enable).'">Enable</a> ';
            echo '<a class="button button-link-delete" href="'.esc_url($delete).'" onclick="return confirm('.esc_attr(wp_json_encode($confirm)).');">Delete</a>';
            echo '</td></tr>';
        }

        echo '</tbody></table>';
        $this->admin_footer();
    }

    public function regenerate_code(){
        if(!current_user_can('manage_options')) wp_die('Unauthorized');
        $id=intval($_GET['id']??0);
        check_admin_referer('snbm_regen_'.$id);
        global $wpdb;
        $t=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['testers']} WHERE id=%d",$id),ARRAY_A);
        if(!$t) wp_die('Tester not found');
        $code=$this->generate_code();
        $wpdb->update($this->tables['testers'],['access_hash'=>wp_hash_password($code),'active'=>1,'updated_at'=>current_time('mysql', true)],['id'=>$id]);
        $addon_id=$this->normalize_addon_id($_GET['addon_id'] ?? '');
        if(empty($_GET['addon_id'])){
            $stored_addon=$wpdb->get_var($wpdb->prepare("SELECT addon_id FROM {$this->tables['programs']} WHERE tester_id=%d AND active=1 ORDER BY id ASC LIMIT 1",$id));
            if($stored_addon)$addon_id=$stored_addon;
        }
        $enrolled=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tables['programs']} WHERE tester_id=%d AND addon_id=%s AND active=1",$id,$addon_id));
        if(!$enrolled) wp_die('This tester is not enrolled in that beta program.');
        $mail_sent=$this->send_tester_credentials($t['email'],$t['name'],$t['tester_id'],$code,$addon_id,true);
        set_transient('snbm_code_'.get_current_user_id(),['tester_id'=>$t['tester_id'],'code'=>$code,'name'=>$t['name'],'email'=>$t['email'],'mail_sent'=>$mail_sent],120);
        $return=sanitize_key($_GET['return']??'testers');
        $page=$return==='candidates' ? self::MENU.'-candidates' : self::MENU.'-testers';
        wp_safe_redirect(admin_url('admin.php?page='.$page));
        exit;
    }
    public function disable_tester(){if(!current_user_can('manage_options'))wp_die('Unauthorized');$id=intval($_GET['id']??0);check_admin_referer('snbm_disable_'.$id);global $wpdb;$wpdb->update($this->tables['testers'],['active'=>0,'updated_at'=>current_time('mysql', true)],['id'=>$id]);wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-testers'));exit;}

    public function enable_tester(){if(!current_user_can('manage_options'))wp_die('Unauthorized');$id=intval($_GET['id']??0);check_admin_referer('snbm_enable_'.$id);global $wpdb;$wpdb->update($this->tables['testers'],['active'=>1,'updated_at'=>current_time('mysql', true)],['id'=>$id]);wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-testers'));exit;}

    public function delete_candidate(){
        if(!current_user_can('manage_options')) wp_die('Unauthorized');
        $id=intval($_GET['id']??0);
        check_admin_referer('snbm_delete_candidate_'.$id);
        global $wpdb;
        // Preserve tester accounts and history; only break the optional candidate link.
        $wpdb->update($this->tables['testers'],['candidate_id'=>null],['candidate_id'=>$id],['%s'],['%d']);
        $wpdb->update($this->tables['programs'],['candidate_id'=>null],['candidate_id'=>$id],['%s'],['%d']);
        $wpdb->delete($this->tables['candidates'],['id'=>$id],['%d']);
        wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-candidates&deleted=1'));
        exit;
    }

    public function delete_tester(){
        if(!current_user_can('manage_options')) wp_die('Unauthorized');
        $id=intval($_GET['id']??0);
        check_admin_referer('snbm_delete_tester_'.$id);
        global $wpdb;
        $tester=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['testers']} WHERE id=%d",$id),ARRAY_A);
        if(!$tester) wp_die('Tester not found');
        $candidate_ids=$wpdb->get_col($wpdb->prepare("SELECT candidate_id FROM {$this->tables['programs']} WHERE tester_id=%d AND candidate_id IS NOT NULL",$id));
        $wpdb->delete($this->tables['programs'],['tester_id'=>$id],['%d']);
        $wpdb->delete($this->tables['testers'],['id'=>$id],['%d']);
        // Keep candidate records, but make each enrolled beta application approvable again.
        foreach((array)$candidate_ids as $candidate_id){
            $wpdb->update($this->tables['candidates'],['status'=>'pending','updated_at'=>current_time('mysql', true)],['id'=>intval($candidate_id)]);
        }
        wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-testers&deleted=1'));
        exit;
    }

    public function unsubscribe_newsletter(){
        if(!current_user_can('manage_options')) wp_die('Unauthorized');
        $id=intval($_GET['id']??0);
        check_admin_referer('snbm_unsubscribe_newsletter_'.$id);
        global $wpdb;
        $wpdb->update($this->tables['newsletter'],['subscribed'=>0],['id'=>$id],['%d'],['%d']);
        wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-newsletter&unsubscribed=1'));
        exit;
    }

    public function delete_newsletter(){
        if(!current_user_can('manage_options')) wp_die('Unauthorized');
        $id=intval($_GET['id']??0);
        check_admin_referer('snbm_delete_newsletter_'.$id);
        global $wpdb;
        $wpdb->delete($this->tables['newsletter'],['id'=>$id],['%d']);
        wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-newsletter&deleted=1'));
        exit;
    }

    // ------------------------------------------------------------------
    // Zoho Projects integration (server-side only)
    // ------------------------------------------------------------------

    private function zoho_auth_configured() {
        $s = $this->settings();
        return !empty($s['zoho_enabled']) && !empty($s['zoho_client_id']) && !empty($s['zoho_client_secret']) && !empty($s['zoho_refresh_token']) && !empty($s['zoho_portal_id']);
    }

    private function zoho_configured() {
        if (!$this->zoho_auth_configured()) return false;
        $s=$this->settings();
        return !empty($s['zoho_project_id']) || !empty($s['zoho_project_mappings']);
    }

    private function zoho_project_id_for_product($product) {
        $s=$this->settings();
        $product=trim((string)$product);
        foreach ((array)($s['zoho_project_mappings'] ?? []) as $mapped_product=>$project_id) {
            if (strcasecmp(trim((string)$mapped_product),$product)===0 && preg_match('/^\d+$/',(string)$project_id)) return (string)$project_id;
        }
        // Backward-compatible migration path: existing installs used one Project ID for Core.
        if (strcasecmp($product,'Core')===0 && !empty($s['zoho_project_id'])) return (string)$s['zoho_project_id'];
        throw new \RuntimeException('No Zoho project is mapped for product "'.$product.'". Configure it in Beta Manager Settings.');
    }

    private function zoho_access_token() {
        $cached = get_transient('snbm_zoho_access_token');
        if ($cached) return $cached;
        $s = $this->settings();
        $response = wp_remote_post('https://accounts.zohocloud.ca/oauth/v2/token', [
            'timeout' => 20,
            'body' => [
                'refresh_token' => $s['zoho_refresh_token'],
                'client_id' => $s['zoho_client_id'],
                'client_secret' => $s['zoho_client_secret'],
                'grant_type' => 'refresh_token',
            ],
        ]);
        if (is_wp_error($response)) throw new \RuntimeException($response->get_error_message());
        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if ($code !== 200 || empty($data['access_token'])) {
            throw new \RuntimeException('Zoho OAuth failed (HTTP '.$code.'): '.wp_remote_retrieve_body($response));
        }
        $ttl = max(60, intval($data['expires_in'] ?? 3600) - 120);
        set_transient('snbm_zoho_access_token', $data['access_token'], $ttl);
        return $data['access_token'];
    }

    private function zoho_request($path, $method='GET', $data=null) {
        if (!$this->zoho_auth_configured()) throw new \RuntimeException('Zoho integration is not configured in Beta Manager Settings.');
        $args = [
            'method' => $method, 'timeout' => 25,
            'headers' => ['Authorization'=>'Bearer '.$this->zoho_access_token(), 'Content-Type'=>'application/json'],
        ];
        if ($data !== null) $args['body'] = wp_json_encode($data);
        $response = wp_remote_request('https://projects.zohocloud.ca/api/v3/'.$path, $args);
        if (is_wp_error($response)) throw new \RuntimeException($response->get_error_message());
        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $decoded = $body !== '' ? json_decode($body, true) : null;
        if ($code < 200 || $code >= 300) throw new \RuntimeException('Zoho API failed (HTTP '.$code.'): '.$body);
        return [$code, $decoded];
    }

    private function zoho_project_path($project_id) {
        $s=$this->settings();
        $project_id=preg_replace('/\D+/','',(string)$project_id);
        if ($project_id==='') throw new \RuntimeException('Zoho Project ID is missing.');
        return 'portal/'.$s['zoho_portal_id'].'/projects/'.$project_id;
    }

    private function zoho_projects() {
        $cache=get_transient('snbm_zoho_projects');
        if (is_array($cache) && !empty($cache)) return $cache;

        $s=$this->settings();
        $out=[];
        $page=1;

        do {
            list($_,$data)=$this->zoho_request('portal/'.$s['zoho_portal_id'].'/projects?page='.$page.'&per_page=100');

            // V3 normally returns {"projects":[...]}. Be tolerant of an
            // unwrapped list and of older/alternate project-name keys too.
            $rows=[];
            if (is_array($data) && isset($data['projects']) && is_array($data['projects'])) {
                $rows=$data['projects'];
            } elseif (is_array($data) && array_is_list($data)) {
                $rows=$data;
            }

            foreach ($rows as $project) {
                if (!is_array($project) || empty($project['id'])) continue;
                $project_name=(string)($project['name'] ?? $project['project_name'] ?? $project['projectName'] ?? '');
                if ($project_name==='') continue;
                $out[]=['id'=>(string)$project['id'],'name'=>$project_name];
            }

            $pi=is_array($data) ? ($data['page_info'] ?? []) : [];
            if (isset($pi[0]) && is_array($pi[0])) $pi=$pi[0];
            $next=is_array($pi) && !empty($pi['has_next_page']);
            $page++;
        } while ($next && $page <= 50);

        // Do not cache an empty discovery result. A transient API/schema issue
        // should recover immediately on the next Settings-page load.
        if ($out) set_transient('snbm_zoho_projects',$out,5*MINUTE_IN_SECONDS);
        return $out;
    }

    private function zoho_form_request($path, $method='POST', $fields=[]) {
        if (!$this->zoho_auth_configured()) throw new \RuntimeException('Zoho integration is not configured in Beta Manager Settings.');
        $args = [
            'method'=>$method,
            'timeout'=>25,
            'headers'=>['Authorization'=>'Bearer '.$this->zoho_access_token()],
        ];
        if ($fields) $args['body']=$fields;
        $response=wp_remote_request('https://projects.zohocloud.ca/api/v3/'.$path,$args);
        if (is_wp_error($response)) throw new \RuntimeException($response->get_error_message());
        $code=wp_remote_retrieve_response_code($response);
        $body=wp_remote_retrieve_body($response);
        $decoded=$body !== '' ? json_decode($body,true) : null;
        if ($code < 200 || $code >= 300) throw new \RuntimeException('Zoho API failed (HTTP '.$code.'): '.$body);
        return [$code,$decoded];
    }

    private function zoho_beta_feedback_tag_id($project_id) {
        // Find the project tag first so we never create duplicate beta-feedback tags.
        list($_,$data)=$this->zoho_request($this->zoho_project_path($project_id).'/tags?per_page=100');
        foreach (($data['tags'] ?? []) as $tag) {
            if (strcasecmp((string)($tag['name'] ?? ''),'beta-feedback')===0 && !empty($tag['id'])) return (string)$tag['id'];
        }

        // Zoho's Create New Tags endpoint expects the tags JSON array as a form field.
        $s=$this->settings();
        list($code,$created)=$this->zoho_form_request('portal/'.$s['zoho_portal_id'].'/tags','POST',[
            'tags'=>wp_json_encode([['name'=>'beta-feedback','color_class'=>'#7dcf7b']]),
        ]);
        $tag=$created['tags'][0] ?? null;
        if ($code !== 201 || !is_array($tag) || empty($tag['id'])) throw new \RuntimeException('Zoho did not return the beta-feedback tag ID.');
        return (string)$tag['id'];
    }

    private function zoho_associate_beta_feedback_tag($task_id, $project_id) {
        $tag_id=$this->zoho_beta_feedback_tag_id($project_id);
        $path=$this->zoho_project_path($project_id).'/tags/associate?'.http_build_query([
            'tag_id'=>$tag_id,
            'entity_id'=>$task_id,
            'entityType'=>'5', // Zoho entity type 5 = Task.
        ]);
        list($code,$_data)=$this->zoho_form_request($path,'POST');
        if ($code !== 204) throw new \RuntimeException('Zoho tag association returned HTTP '.$code.' instead of 204.');
        return $tag_id;
    }


    private function feedback_attachment_path($url) {
        if (!$url) return '';
        $uploads = wp_upload_dir();
        $base_url = trailingslashit($uploads['baseurl']);
        $base_dir = trailingslashit(wp_normalize_path($uploads['basedir']));
        if (strpos($url, $base_url) !== 0) return '';
        $relative = rawurldecode(substr($url, strlen($base_url)));
        $path = wp_normalize_path($base_dir.ltrim($relative, '/'));
        if (strpos($path, $base_dir) !== 0 || !is_file($path)) return '';
        return $path;
    }

    private function zoho_upload_task_attachment($task_id, $file_path, $display_name='') {
        if (!$this->zoho_auth_configured()) throw new \RuntimeException('Zoho integration is not configured in Beta Manager Settings.');
        if (!is_file($file_path) || !is_readable($file_path)) throw new \RuntimeException('Attachment file is missing or unreadable.');
        $s=$this->settings();
        $boundary='----ScriptronautBoundary'.wp_generate_password(24, false, false);
        $filename=$display_name ?: basename($file_path);
        $filename=sanitize_file_name($filename);
        $mime=wp_check_filetype($filename);
        $content_type=!empty($mime['type']) ? $mime['type'] : 'application/octet-stream';
        $file_data=file_get_contents($file_path);
        if ($file_data === false) throw new \RuntimeException('Could not read attachment file.');
        $eol="\r\n";
        $body='';
        $body.='--'.$boundary.$eol.'Content-Disposition: form-data; name="entity_type"'.$eol.$eol.'task'.$eol;
        $body.='--'.$boundary.$eol.'Content-Disposition: form-data; name="entity_id"'.$eol.$eol.$task_id.$eol;
        $body.='--'.$boundary.$eol.'Content-Disposition: form-data; name="upload_file"; filename="'.str_replace(['"',"\r","\n"], '', $filename).'"'.$eol;
        $body.='Content-Type: '.$content_type.$eol.$eol.$file_data.$eol;
        $body.='--'.$boundary.'--'.$eol;
        $url='https://projects.zohocloud.ca/api/v3/portal/'.$s['zoho_portal_id'].'/associate-attachments';
        $response=wp_remote_post($url,[
            'timeout'=>60,
            'headers'=>[
                'Authorization'=>'Bearer '.$this->zoho_access_token(),
                'Content-Type'=>'multipart/form-data; boundary='.$boundary,
            ],
            'body'=>$body,
        ]);
        if (is_wp_error($response)) throw new \RuntimeException($response->get_error_message());
        $code=wp_remote_retrieve_response_code($response);
        $raw=wp_remote_retrieve_body($response);
        $data=$raw !== '' ? json_decode($raw,true) : null;
        if ($code < 200 || $code >= 300) throw new \RuntimeException('Zoho attachment upload failed (HTTP '.$code.'): '.$raw);
        $attachment=$data['attachment'][0] ?? null;
        if (!is_array($attachment) || empty($attachment['id'])) throw new \RuntimeException('Zoho did not return the uploaded attachment ID.');
        return $attachment;
    }

    private function upload_feedback_attachments_to_zoho($feedback_id, $task_id) {
        global $wpdb;
        $row=$wpdb->get_row($wpdb->prepare("SELECT attachments FROM {$this->tables['feedback']} WHERE id=%d",$feedback_id),ARRAY_A);
        $attachments=json_decode($row['attachments'] ?? '',true);
        if (!is_array($attachments) || !$attachments) return ['total'=>0,'uploaded'=>0,'failed'=>0];
        $uploaded=0; $failed=0;
        foreach ($attachments as &$attachment) {
            if (!empty($attachment['zoho_attachment_id'])) { $uploaded++; continue; }
            $path=$this->feedback_attachment_path($attachment['url'] ?? '');
            if (!$path) {
                $attachment['zoho_error']='Local attachment file not found.';
                $failed++;
                continue;
            }
            try {
                $z=$this->zoho_upload_task_attachment($task_id,$path,$attachment['name'] ?? basename($path));
                $attachment['zoho_attachment_id']=(string)$z['id'];
                $attachment['zoho_uploaded_at']=current_time('mysql',true);
                unset($attachment['zoho_error']);
                $uploaded++;
            } catch (\Exception $e) {
                $attachment['zoho_error']=$e->getMessage();
                $failed++;
            }
        }
        unset($attachment);
        $wpdb->update($this->tables['feedback'],['attachments'=>wp_json_encode($attachments)],['id'=>$feedback_id]);
        return ['total'=>count($attachments),'uploaded'=>$uploaded,'failed'=>$failed];
    }

    private function zoho_users($project_id) {
        $cache=get_transient('snbm_zoho_users_'.md5((string)$project_id)); if (is_array($cache)) return $cache;
        list($_,$data)=$this->zoho_request($this->zoho_project_path($project_id).'/users');
        $out=[]; foreach (($data['users'] ?? []) as $u) if (!empty($u['zuid'])) $out[]=['name'=>($u['full_name'] ?? $u['display_name'] ?? $u['email'] ?? $u['zuid']),'zuid'=>(string)$u['zuid']];
        set_transient('snbm_zoho_users_'.md5((string)$project_id),$out,5*MINUTE_IN_SECONDS); return $out;
    }

    private function zoho_statuses() {
        $cache=get_transient('snbm_zoho_statuses'); if (is_array($cache)) return $cache;
        $s=$this->settings();
        list($_,$data)=$this->zoho_request('portal/'.$s['zoho_portal_id'].'/settings/global-statuses?module=tasks');
        $out=[]; foreach ((array)$data as $st) if (!empty($st['id']) && !empty($st['name'])) $out[]=['id'=>(string)$st['id'],'name'=>$st['name']];
        set_transient('snbm_zoho_statuses',$out,5*MINUTE_IN_SECONDS); return $out;
    }

    private function zoho_tasklists($project_id) {
        // Return the project's task-list names for the Beta Manager selector.
        // Names are de-duplicated because Bugs can contain a second task list
        // with the same name as a normal development list.
        $cache=get_transient('snbm_zoho_tasklists_'.md5((string)$project_id)); if (is_array($cache)) return $cache;
        $s=$this->settings();
        $project_id=(string)$project_id;
        $by_name=[]; $page=1;
        do {
            list($_,$data)=$this->zoho_request('portal/'.$s['zoho_portal_id'].'/all-tasklists?page='.$page.'&per_page=200');
            foreach (($data['tasklists'] ?? []) as $tl) {
                if (empty($tl['id']) || empty($tl['name'])) continue;
                $tl_project_id=(string)($tl['project']['id'] ?? '');
                if ($project_id !== '' && $tl_project_id !== $project_id) continue;
                $name=(string)$tl['name']; $key=strtolower($name);
                if (!isset($by_name[$key])) $by_name[$key]=['id'=>(string)$tl['id'],'name'=>$name];
            }
            $pi=$data['page_info'] ?? [];
            if (isset($pi[0]) && is_array($pi[0])) $pi=$pi[0];
            $next=!empty($pi['has_next_page']); $page++;
        } while ($next && $page <= 50);

        $out=array_values($by_name);
        usort($out,function($a,$b){return strcasecmp($a['name'],$b['name']);});
        set_transient('snbm_zoho_tasklists_'.md5((string)$project_id),$out,5*MINUTE_IN_SECONDS); return $out;
    }

    private function zoho_bug_phase_id($project_id) {
        $cache_key='snbm_zoho_bug_phase_'.md5((string)$project_id);
        $cached=get_transient($cache_key);
        if ($cached) return (string)$cached;
        $page=1;
        do {
            list($_,$data)=$this->zoho_request($this->zoho_project_path($project_id).'/milestones?page='.$page.'&per_page=100');
            foreach (($data['milestones'] ?? []) as $phase) {
                if (!empty($phase['id']) && isset($phase['name']) && strcasecmp((string)$phase['name'],'Bugs')===0) {
                    $id=(string)$phase['id'];
                    set_transient($cache_key,$id,5*MINUTE_IN_SECONDS);
                    return $id;
                }
            }
            $pi=$data['page_info'] ?? [];
            if (isset($pi[0]) && is_array($pi[0])) $pi=$pi[0];
            $next=!empty($pi['has_next_page']); $page++;
        } while ($next && $page <= 50);
        throw new \RuntimeException('Zoho phase "Bugs" was not found in the configured project.');
    }

    private function zoho_bug_tasklist_id($name, $project_id) {
        $name=trim((string)$name);
        if ($name==='') throw new \RuntimeException('Task List is required.');
        $bugs_phase_id=$this->zoho_bug_phase_id($project_id);
        $s=$this->settings(); $project_id=(string)$project_id;
        $page=1;
        do {
            list($_,$data)=$this->zoho_request('portal/'.$s['zoho_portal_id'].'/all-tasklists?page='.$page.'&per_page=200');
            foreach (($data['tasklists'] ?? []) as $tl) {
                if (empty($tl['id']) || !isset($tl['name'])) continue;
                if ((string)($tl['project']['id'] ?? '') !== $project_id) continue;
                $phase_id=(string)($tl['milestone']['id'] ?? '');
                if ($phase_id===$bugs_phase_id && strcasecmp((string)$tl['name'],$name)===0) return (string)$tl['id'];
            }
            $pi=$data['page_info'] ?? [];
            if (isset($pi[0]) && is_array($pi[0])) $pi=$pi[0];
            $next=!empty($pi['has_next_page']); $page++;
        } while ($next && $page <= 50);

        list($code,$created)=$this->zoho_request($this->zoho_project_path($project_id).'/tasklists','POST',[
            'name'=>$name,
            'milestone'=>['id'=>$bugs_phase_id],
        ]);
        if ($code!==201 || empty($created['id'])) throw new \RuntimeException('Zoho did not return the created Bugs task-list ID.');
        return (string)$created['id'];
    }

    public function create_zoho_task_from_feedback() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $feedback_id=intval($_POST['feedback_id'] ?? 0); check_admin_referer('snbm_create_zoho_task_'.$feedback_id);
        global $wpdb; $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['feedback']} WHERE id=%d",$feedback_id),ARRAY_A);
        if (!$r) wp_die('Feedback report not found');
        if (!empty($r['zoho_task_id'])) wp_die('This feedback report already has a Zoho task.');
        $tasklist_name=sanitize_text_field($_POST['zoho_tasklist_name'] ?? '');
        $owner_zuid=preg_replace('/\D+/','',(string)($_POST['zoho_owner_zuid'] ?? ''));
        $status_id=preg_replace('/\D+/','',(string)($_POST['zoho_status_id'] ?? ''));
        $priority=sanitize_key($_POST['zoho_priority'] ?? 'none');
        $name=sanitize_text_field($_POST['zoho_task_name'] ?? $r['summary']);
        if (!$tasklist_name || !$name) wp_die('Task name and Task List are required.');
        $description="Beta Manager Feedback #{$feedback_id}\n\nType: {$r['report_type']}\nAdd-on: ".$this->addon_label($r['addon_id'] ?? 'qc_checker')."\nCategory: {$r['category']}\nCheck: {$r['check_name']}\nTester: {$r['tester_id']} ({$r['tester_email']})\nBlender: {$r['blender_version']}\nQC Checker: {$r['qc_version']}\nOS: {$r['operating_system']}\n\nSummary:\n{$r['summary']}\n\nDetails:\n{$r['details']}";
        if (!empty($r['traceback'])) $description.="\n\nTraceback:\n{$r['traceback']}";
        try {
            $project_id=$this->zoho_project_id_for_product($r['tier'] ?? '');
            // Beta feedback always goes into a same-named task list under the Bugs phase.
            // Create that Bugs task list on demand if it does not exist yet.
            $tasklist_id=$this->zoho_bug_tasklist_id($tasklist_name,$project_id);
            list($code,$task)=$this->zoho_request($this->zoho_project_path($project_id).'/tasks','POST',['name'=>$name,'description'=>$description,'tasklist'=>['id'=>$tasklist_id]]);
            if ($code !== 201 || empty($task['id'])) throw new \RuntimeException('Zoho did not return the created task ID.');
            $task_id=(string)$task['id']; $update=[];
            if ($priority) $update['priority']=$priority;
            if ($status_id) $update['status']=['id'=>$status_id];
            if ($owner_zuid) $update['owners_and_work']=['owners'=>[['zuid'=>$owner_zuid]]];
            if ($update) list($_,$updated)=$this->zoho_request($this->zoho_project_path($project_id).'/tasks/'.$task_id,'PATCH',$update);
            $prefix=(string)($task['prefix'] ?? ($updated['prefix'] ?? ''));
            // Link the task before tag/attachment work so a secondary API failure can never create a duplicate Zoho task.
            $wpdb->update($this->tables['feedback'],['zoho_task_id'=>$task_id,'zoho_task_prefix'=>$prefix,'zoho_task_created_at'=>current_time('mysql',true),'status'=>'reviewing','status_updated_at'=>current_time('mysql',true)],['id'=>$feedback_id]);

            $tagged=false; $tag_error='';
            try {
                $this->zoho_associate_beta_feedback_tag($task_id,$project_id);
                $tagged=true;
            } catch (\Exception $e) {
                // Tagging is helpful metadata, but it must not undo an otherwise successful task creation.
                $tag_error=$e->getMessage();
            }

            $attachment_result=$this->upload_feedback_attachments_to_zoho($feedback_id,$task_id);
            $redirect=admin_url('admin.php?page='.self::MENU.'-feedback&feedback_id='.$feedback_id.'&zoho_created=1');
            if ($tagged) $redirect=add_query_arg('zoho_tagged','1',$redirect);
            elseif ($tag_error !== '') $redirect=add_query_arg('zoho_tag_error',$tag_error,$redirect);
            if ($attachment_result['total'] > 0) {
                $redirect=add_query_arg([
                    'zoho_attached'=>$attachment_result['uploaded'],
                    'zoho_attachment_total'=>$attachment_result['total'],
                    'zoho_attachment_failed'=>$attachment_result['failed'],
                ],$redirect);
            }
            wp_safe_redirect($redirect); exit;
        } catch (\Exception $e) {
            wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-feedback&feedback_id='.$feedback_id.'&zoho_error='.rawurlencode($e->getMessage()))); exit;
        }
    }

    public function retry_zoho_attachments() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $feedback_id=intval($_GET['feedback_id'] ?? 0);
        check_admin_referer('snbm_retry_zoho_attachments_'.$feedback_id);
        global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare("SELECT zoho_task_id FROM {$this->tables['feedback']} WHERE id=%d",$feedback_id),ARRAY_A);
        if (!$r || empty($r['zoho_task_id'])) wp_die('Linked Zoho task not found.');
        try {
            $result=$this->upload_feedback_attachments_to_zoho($feedback_id,(string)$r['zoho_task_id']);
            $url=admin_url('admin.php?page='.self::MENU.'-feedback&feedback_id='.$feedback_id);
            $url=add_query_arg(['zoho_attached'=>$result['uploaded'],'zoho_attachment_total'=>$result['total'],'zoho_attachment_failed'=>$result['failed']],$url);
            wp_safe_redirect($url); exit;
        } catch (\Exception $e) {
            wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-feedback&feedback_id='.$feedback_id.'&zoho_error='.rawurlencode($e->getMessage()))); exit;
        }
    }

    public function sync_zoho_task_status() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $feedback_id=intval($_GET['feedback_id'] ?? 0);
        check_admin_referer('snbm_sync_zoho_task_'.$feedback_id);
        global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['feedback']} WHERE id=%d",$feedback_id),ARRAY_A);
        if (!$r || empty($r['zoho_task_id'])) wp_die('Linked Zoho task not found.');
        try {
            $project_id=$this->zoho_project_id_for_product($r['tier'] ?? '');
            list($_,$task)=$this->zoho_request($this->zoho_project_path($project_id).'/tasks/'.rawurlencode((string)$r['zoho_task_id']));
            $zoho_status=(string)($task['status']['name'] ?? '');
            if ($zoho_status === '') throw new \RuntimeException('Zoho did not return the task status.');
            // Closed Zoho tasks resolve the feedback. All other active states remain Reviewing.
            $feedback_status=(strcasecmp($zoho_status,'Closed')===0) ? 'resolved' : 'reviewing';
            $wpdb->update($this->tables['feedback'],[
                'status'=>$feedback_status,
                'status_updated_at'=>current_time('mysql',true),
            ],['id'=>$feedback_id]);
            wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-feedback&feedback_id='.$feedback_id.'&zoho_synced='.rawurlencode($zoho_status)));
            exit;
        } catch (\Exception $e) {
            wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-feedback&feedback_id='.$feedback_id.'&zoho_error='.rawurlencode($e->getMessage())));
            exit;
        }
    }

    public function sync_all_zoho_task_statuses() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('snbm_sync_all_zoho_tasks');
        global $wpdb;

        // Only linked, non-resolved feedback needs routine synchronization. This
        // keeps the manual bulk action light and avoids repeatedly polling history.
        $rows=$wpdb->get_results(
            "SELECT id, status, tier, zoho_task_id FROM {$this->tables['feedback']} WHERE zoho_task_id <> '' AND status <> 'resolved' ORDER BY id ASC",
            ARRAY_A
        );

        $checked=0; $updated=0; $failed=0;
        foreach ($rows as $r) {
            try {
                $project_id=$this->zoho_project_id_for_product($r['tier'] ?? '');
                list($_,$task)=$this->zoho_request($this->zoho_project_path($project_id).'/tasks/'.rawurlencode((string)$r['zoho_task_id']));
                $zoho_status=(string)($task['status']['name'] ?? '');
                if ($zoho_status === '') throw new \RuntimeException('Zoho did not return the task status.');
                $feedback_status=(strcasecmp($zoho_status,'Closed')===0) ? 'resolved' : 'reviewing';
                $checked++;
                if (($r['status'] ?: 'new') !== $feedback_status) {
                    $wpdb->update($this->tables['feedback'],[
                        'status'=>$feedback_status,
                        'status_updated_at'=>current_time('mysql',true),
                    ],['id'=>intval($r['id'])]);
                    $updated++;
                }
            } catch (\Exception $e) {
                $failed++;
            }
        }

        $url=admin_url('admin.php?page='.self::MENU.'-feedback');
        $url=add_query_arg([
            'zoho_bulk_synced'=>1,
            'zoho_checked'=>$checked,
            'zoho_updated'=>$updated,
            'zoho_failed'=>$failed,
        ],$url);
        wp_safe_redirect($url); exit;
    }

    public function open_zoho_task() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $feedback_id=intval($_GET['feedback_id'] ?? 0);
        check_admin_referer('snbm_open_zoho_task_'.$feedback_id);
        global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['feedback']} WHERE id=%d",$feedback_id),ARRAY_A);
        if (!$r || empty($r['zoho_task_id'])) wp_die('Linked Zoho task not found.');
        try {
            $s=$this->settings();
            $portal_name=sanitize_title((string)($s['zoho_portal_name'] ?? ''));
            if ($portal_name === '') throw new \RuntimeException('Zoho Portal Name is not configured in Beta Manager Settings.');
            $task_id=preg_replace('/\D+/', '', (string)$r['zoho_task_id']);
            if ($task_id === '') throw new \RuntimeException('Linked Zoho task ID is invalid.');
            $link='https://projects.zohocloud.ca/portal/'.rawurlencode($portal_name).'#zp/task-detail/'.$task_id;
            wp_redirect($link);
            exit;
        } catch (\Exception $e) {
            wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-feedback&feedback_id='.$feedback_id.'&zoho_error='.rawurlencode($e->getMessage())));
            exit;
        }
    }

    private function feedback_status_label($status) {
        $labels = ['new'=>'New','reviewing'=>'Reviewing','resolved'=>'Resolved'];
        return $labels[$status] ?? 'New';
    }

    private function feedback_status_badge($status) {
        $styles = [
            'new' => 'background:#d63638;color:#fff;',
            'reviewing' => 'background:#dba617;color:#1d2327;',
            'resolved' => 'background:#00a32a;color:#fff;',
        ];
        $style = $styles[$status] ?? $styles['new'];
        return '<span style="display:inline-block;padding:3px 8px;border-radius:999px;font-weight:600;'.$style.'">'.esc_html($this->feedback_status_label($status)).'</span>';
    }

    public function update_feedback_status() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $id = intval($_GET['id'] ?? 0);
        $status = sanitize_key($_GET['status'] ?? '');
        check_admin_referer('snbm_feedback_status_'.$id.'_'.$status);
        if (!in_array($status, ['new','reviewing','resolved'], true)) wp_die('Invalid feedback status');
        global $wpdb;
        $feedback = $wpdb->get_row($wpdb->prepare("SELECT zoho_task_id FROM {$this->tables['feedback']} WHERE id=%d", $id), ARRAY_A);
        if (!$feedback) wp_die('Feedback report not found');
        if (!empty($feedback['zoho_task_id'])) wp_die('This feedback status is managed by its linked Zoho task. Use Sync Status instead.');
        $wpdb->update($this->tables['feedback'], ['status'=>$status,'status_updated_at'=>current_time('mysql', true)], ['id'=>$id]);
        wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-feedback&feedback_id='.$id.'&status_updated=1'));
        exit;
    }

    public function delete_feedback() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        $id = intval($_GET['id'] ?? 0);
        if (!$id) wp_die('Invalid feedback ID');
        check_admin_referer('snbm_delete_feedback_'.$id);

        global $wpdb;
        $report = $wpdb->get_row(
            $wpdb->prepare("SELECT attachments FROM {$this->tables['feedback']} WHERE id=%d", $id),
            ARRAY_A
        );
        if (!$report) wp_die('Feedback report not found');

        // Remove uploaded attachment files belonging to this feedback report.
        $attachments = json_decode($report['attachments'] ?? '', true);
        if (is_array($attachments)) {
            $uploads = wp_upload_dir();
            $base_dir = wp_normalize_path($uploads['basedir']);
            $base_url = trailingslashit($uploads['baseurl']);
            foreach ($attachments as $attachment) {
                $url = $attachment['url'] ?? '';
                if (!$url || strpos($url, $base_url) !== 0) continue;
                $relative = rawurldecode(substr($url, strlen($base_url)));
                $path = wp_normalize_path(trailingslashit($base_dir).ltrim($relative, '/'));
                // Safety: only delete a file that resolves inside WordPress uploads.
                if (strpos($path, trailingslashit($base_dir)) === 0 && is_file($path)) {
                    wp_delete_file($path);
                }
            }
        }

        $wpdb->delete($this->tables['feedback'], ['id'=>$id], ['%d']);
        wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-feedback&deleted=1'));
        exit;
    }

    private function page_feedback_detail($id) {
        global $wpdb;
        $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['feedback']} WHERE id=%d", $id), ARRAY_A);
        if (!$r) { wp_die('Feedback report not found'); }
        $atts = json_decode($r['attachments'], true);
        $status = $r['status'] ?: 'new';
        $this->admin_header('Feedback #'.intval($r['id']));
        if (!empty($_GET['status_updated'])) echo '<div class="notice notice-success is-dismissible"><p>Feedback status updated.</p></div>';
        if (!empty($_GET['zoho_created'])) echo '<div class="notice notice-success is-dismissible"><p>Zoho task created and linked to this feedback report.</p></div>';
        if (!empty($_GET['zoho_tagged'])) echo '<div class="notice notice-success is-dismissible"><p>Zoho tag <strong>beta-feedback</strong> associated with the task.</p></div>';
        if (!empty($_GET['zoho_tag_error'])) echo '<div class="notice notice-warning is-dismissible"><p>Zoho task was created, but the <strong>beta-feedback</strong> tag could not be associated: '.esc_html(wp_unslash($_GET['zoho_tag_error'])).'</p></div>';
        if (isset($_GET['zoho_attachment_total'])) {
            $attached=max(0,intval($_GET['zoho_attached'] ?? 0)); $total=max(0,intval($_GET['zoho_attachment_total'] ?? 0)); $failed=max(0,intval($_GET['zoho_attachment_failed'] ?? 0));
            $class=$failed ? 'notice-warning' : 'notice-success';
            echo '<div class="notice '.esc_attr($class).' is-dismissible"><p>Zoho attachments: <strong>'.intval($attached).' of '.intval($total).'</strong> uploaded'.($failed ? '; '.intval($failed).' failed and can be retried.' : '.').'</p></div>';
        }
        if (isset($_GET['zoho_synced']) && $_GET['zoho_synced'] !== '') echo '<div class="notice notice-success is-dismissible"><p>Zoho status synced: <strong>'.esc_html(wp_unslash($_GET['zoho_synced'])).'</strong>.</p></div>';
        if (!empty($_GET['zoho_error'])) echo '<div class="notice notice-error is-dismissible"><p><strong>Zoho:</strong> '.esc_html(wp_unslash($_GET['zoho_error'])).'</p></div>';
        echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page='.self::MENU.'-feedback')).'">&larr; Back to Feedback</a></p>';
        echo '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:14px 0 20px"><strong>Status:</strong> '.$this->feedback_status_badge($status);
        if (!empty($r['zoho_task_id'])) {
            echo '<span style="color:#646970;font-style:italic">Status managed by Zoho</span>';
        } else {
            foreach (['new'=>'New','reviewing'=>'Reviewing','resolved'=>'Resolved'] as $key=>$label) {
                if ($key === $status) continue;
                $url = wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_feedback_status&id='.intval($r['id']).'&status='.$key), 'snbm_feedback_status_'.intval($r['id']).'_'.$key);
                echo '<a class="button'.($key==='resolved'?' button-primary':'').'" href="'.esc_url($url).'">Mark '.$label.'</a>';
            }
        }
        $delete_url = wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_delete_feedback&id='.intval($r['id'])), 'snbm_delete_feedback_'.intval($r['id']));
        echo '<a class="button button-link-delete" style="margin-left:auto;color:#b32d2e;border-color:#b32d2e" href="'.esc_url($delete_url).'" onclick="return confirm(\'Permanently delete this feedback report and its uploaded attachments? This cannot be undone.\');">Delete Feedback</a>';
        echo '</div>';

        if (!empty($r['zoho_task_id'])) {
            $open_url=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_open_zoho_task&feedback_id='.intval($r['id'])),'snbm_open_zoho_task_'.intval($r['id']));
            $sync_url=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_sync_zoho_task&feedback_id='.intval($r['id'])),'snbm_sync_zoho_task_'.intval($r['id']));
            echo '<div style="background:#fff;border:1px solid #dcdcde;padding:16px 20px;margin:0 0 20px">';
            echo '<h2 style="margin-top:0">Zoho Task</h2>';
            echo '<p style="font-size:16px;margin:0 0 4px"><strong>'.esc_html($r['zoho_task_prefix'] ?: 'Task').'</strong></p>';
            echo '<p style="margin:0 0 16px">'.esc_html($r['summary']).'</p>';
            echo '<p style="margin:0;display:flex;gap:8px;flex-wrap:wrap">';
            echo '<a class="button button-primary" href="'.esc_url($open_url).'" target="_blank" rel="noopener">Open in Zoho</a>';
            echo '<a class="button" href="'.esc_url($sync_url).'">Sync Status</a>';
            $zoho_att_total=is_array($atts) ? count($atts) : 0; $zoho_att_uploaded=0; $zoho_att_failed=0;
            if (is_array($atts)) foreach ($atts as $a) { if (!empty($a['zoho_attachment_id'])) $zoho_att_uploaded++; elseif (!empty($a['zoho_error'])) $zoho_att_failed++; }
            if ($zoho_att_total > 0 && $zoho_att_uploaded < $zoho_att_total) {
                $retry_url=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_retry_zoho_attachments&feedback_id='.intval($r['id'])),'snbm_retry_zoho_attachments_'.intval($r['id']));
                echo '<a class="button" href="'.esc_url($retry_url).'">Retry Attachments</a>';
            }
            echo '</p>';
            if ($zoho_att_total > 0) echo '<p style="margin:12px 0 0;color:#646970">Zoho attachments: '.intval($zoho_att_uploaded).' / '.intval($zoho_att_total).' uploaded'.($zoho_att_failed ? ' ('.intval($zoho_att_failed).' failed)' : '').'.</p>';
            echo '</div>';
        } elseif ($this->zoho_configured()) {
            try {
                $project_id=$this->zoho_project_id_for_product($r['tier'] ?? '');
                $tasklists=$this->zoho_tasklists($project_id); $users=$this->zoho_users($project_id); $statuses=$this->zoho_statuses();
                $suggested=$r['category'] ?: (($r['report_type'] ?? '')==='crash' ? 'General' : '');
                echo '<div style="background:#fff;border:1px solid #dcdcde;padding:16px 20px;margin:0 0 20px"><h2 style="margin-top:0">Create Zoho Task</h2>';
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('snbm_create_zoho_task_'.intval($r['id']));
                echo '<input type="hidden" name="action" value="scriptronaut_beta_create_zoho_task"><input type="hidden" name="feedback_id" value="'.intval($r['id']).'">';
                echo '<table class="form-table"><tr><th>Task Name</th><td><input class="regular-text" name="zoho_task_name" value="'.esc_attr($r['summary']).'" required></td></tr>';
                echo '<tr><th>Task List</th><td><select name="zoho_tasklist_name" required><option value="">Select...</option>';
                foreach ($tasklists as $tl) echo '<option value="'.esc_attr($tl['name']).'" '.selected(strcasecmp($tl['name'],$suggested)===0,true,false).'>'.esc_html($tl['name']).'</option>'; echo '</select></td></tr>';
                echo '<tr><th>Owner</th><td><select name="zoho_owner_zuid"><option value="">Unassigned</option>'; foreach ($users as $u) echo '<option value="'.esc_attr($u['zuid']).'">'.esc_html($u['name']).'</option>'; echo '</select></td></tr>';
                echo '<tr><th>Status</th><td><select name="zoho_status_id">'; foreach ($statuses as $st) echo '<option value="'.esc_attr($st['id']).'" '.selected(strcasecmp($st['name'],'Open')===0,true,false).'>'.esc_html($st['name']).'</option>'; echo '</select></td></tr>';
                echo '<tr><th>Priority</th><td><select name="zoho_priority"><option value="none">None</option><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></td></tr></table>';
                submit_button('Create Zoho Task','primary','submit',false); echo '</form></div>';
            } catch (\Exception $e) { echo '<div class="notice notice-error inline"><p><strong>Zoho:</strong> '.esc_html($e->getMessage()).'</p></div>'; }
        }

        echo '<div style="background:#fff;border:1px solid #dcdcde;padding:16px 20px;margin:0 0 20px"><table class="form-table" style="margin:0"><tbody>';
        $items = [
            'Submitted'=>$this->local_datetime($r['submitted_at']), 'Add-on'=>$this->addon_label($r['addon_id'] ?? 'qc_checker'), 'Tester ID'=>$r['tester_id'], 'Tester Email'=>$r['tester_email'],
            'Type'=>$r['report_type'], 'Product'=>$r['tier'], 'Category'=>$r['category'], 'Check'=>$r['check_name'], 'Check ID'=>$r['check_id'],
            'Summary'=>$r['summary'], 'Details'=>$r['details'], 'Steps'=>$r['steps'], 'Expected Result'=>$r['expected_result'], 'Actual Result'=>$r['actual_result'],
            'QC Checker Version'=>$r['qc_version'], 'Blender Version'=>$r['blender_version'], 'Operating System'=>$r['operating_system'],
            'Blend Filename'=>$r['blend_filename'], 'Source'=>$r['source'], 'Traceback Time'=>$r['traceback_time'], 'IP Address'=>$r['ip_address']
        ];
        foreach ($items as $label=>$value) {
            if ($value === '' || $value === null) continue;
            echo '<tr><th style="width:190px">'.esc_html($label).'</th><td>';
            if (in_array($label, ['Details','Steps','Expected Result','Actual Result'], true)) echo nl2br(esc_html($value));
            elseif ($label === 'Tester Email') echo '<a href="mailto:'.esc_attr($value).'">'.esc_html($value).'</a>';
            else echo esc_html($value);
            echo '</td></tr>';
        }
        if (!empty($r['traceback'])) echo '<tr><th>Traceback</th><td><pre style="white-space:pre-wrap;max-width:1100px;background:#f6f7f7;padding:12px;border:1px solid #dcdcde">'.esc_html($r['traceback']).'</pre></td></tr>';
        echo '<tr><th>Attachments</th><td>';
        if (is_array($atts) && $atts) {
            foreach ($atts as $a) echo '<a class="button" style="margin:0 6px 6px 0" href="'.esc_url($a['url']).'" target="_blank" rel="noopener">'.esc_html($a['name']).'</a>';
        } else echo 'None';
        echo '</td></tr></tbody></table></div>';
        $this->admin_footer();
    }

    public function page_feedback() {
        $feedback_id = intval($_GET['feedback_id'] ?? 0);
        if ($feedback_id) { $this->page_feedback_detail($feedback_id); return; }
        global $wpdb;
        if (!empty($_GET['deleted'])) echo '<div class="notice notice-success is-dismissible"><p>Feedback report and its uploaded attachments permanently deleted.</p></div>';
        if (!empty($_GET['zoho_bulk_synced'])) {
            $checked=max(0,intval($_GET['zoho_checked'] ?? 0));
            $updated=max(0,intval($_GET['zoho_updated'] ?? 0));
            $failed=max(0,intval($_GET['zoho_failed'] ?? 0));
            $class=$failed ? 'notice-warning' : 'notice-success';
            echo '<div class="notice '.esc_attr($class).' is-dismissible"><p>Zoho sync complete: <strong>'.intval($checked).'</strong> task'.($checked===1?'':'s').' checked; <strong>'.intval($updated).'</strong> feedback status'.($updated===1?'':'es').' updated'.($failed ? '; <strong>'.intval($failed).'</strong> failed.' : '.').'</p></div>';
        }

        $filters = [
            'addon' => sanitize_key(wp_unslash($_GET['fb_addon'] ?? '')),
            'status' => sanitize_text_field(wp_unslash($_GET['fb_status'] ?? '')),
            'tester' => sanitize_text_field(wp_unslash($_GET['fb_tester'] ?? '')),
            'type' => sanitize_text_field(wp_unslash($_GET['fb_type'] ?? '')),
            'tier' => sanitize_text_field(wp_unslash($_GET['fb_tier'] ?? '')),
            'category' => sanitize_text_field(wp_unslash($_GET['fb_category'] ?? '')),
            'check_id' => sanitize_text_field(wp_unslash($_GET['fb_check_id'] ?? '')),
            'search' => sanitize_text_field(wp_unslash($_GET['fb_search'] ?? '')),
        ];

        $where = [];
        $params = [];
        $exact = [
            'addon' => 'addon_id', 'status' => 'status', 'tester' => 'tester_id', 'type' => 'report_type',
            'tier' => 'tier', 'category' => 'category', 'check_id' => 'check_id'
        ];
        foreach ($exact as $key => $column) {
            if ($filters[$key] !== '') {
                $where[] = "$column = %s";
                $params[] = $filters[$key];
            }
        }
        if ($filters['search'] !== '') {
            $like = '%' . $wpdb->esc_like($filters['search']) . '%';
            $where[] = '(summary LIKE %s OR details LIKE %s OR check_name LIKE %s OR check_id LIKE %s OR tester_id LIKE %s OR tester_email LIKE %s OR category LIKE %s)';
            for ($i=0; $i<7; $i++) $params[] = $like;
        }
        $where_sql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

        $count_sql = "SELECT COUNT(*) FROM {$this->tables['feedback']}{$where_sql}";
        $total_filtered = intval($params ? $wpdb->get_var($wpdb->prepare($count_sql, $params)) : $wpdb->get_var($count_sql));
        $total_all = intval($wpdb->get_var("SELECT COUNT(*) FROM {$this->tables['feedback']}"));

        $rows_sql = "SELECT * FROM {$this->tables['feedback']}{$where_sql} ORDER BY submitted_at DESC LIMIT 500";
        $rows = $params ? $wpdb->get_results($wpdb->prepare($rows_sql, $params), ARRAY_A) : $wpdb->get_results($rows_sql, ARRAY_A);

        $distinct = function($column) use ($wpdb) {
            $allowed = ['addon_id','tester_id','report_type','tier','category','check_id'];
            if (!in_array($column, $allowed, true)) return [];
            return $wpdb->get_col("SELECT DISTINCT {$column} FROM {$this->tables['feedback']} WHERE {$column} <> '' ORDER BY {$column} ASC");
        };
        $addons = $distinct('addon_id');
        $testers = $distinct('tester_id');
        $types = $distinct('report_type');
        $tiers = $distinct('tier');
        $categories = $distinct('category');
        $check_ids = $distinct('check_id');

        $this->admin_header('Beta Feedback');
        echo '<p>Filter the feedback list, then click any row to open the complete report and change its status.</p>';

        echo '<form method="get" action="'.esc_url(admin_url('admin.php')).'" style="background:#fff;border:1px solid #dcdcde;padding:14px 16px;margin:14px 0 16px">';
        echo '<input type="hidden" name="page" value="'.esc_attr(self::MENU.'-feedback').'">';
        echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;align-items:end">';

        $select = function($name, $label, $value, $options, $labels=[]) {
            echo '<label style="display:block"><span style="display:block;font-weight:600;margin-bottom:4px">'.esc_html($label).'</span>';
            echo '<select name="'.esc_attr($name).'" style="width:100%"><option value="">All</option>';
            foreach ($options as $opt) {
                $text = $labels[$opt] ?? $opt;
                echo '<option value="'.esc_attr($opt).'" '.selected($value, $opt, false).'>'.esc_html($text).'</option>';
            }
            echo '</select></label>';
        };
        $addon_labels=[]; foreach($addons as $addon) $addon_labels[$addon]=$this->addon_label($addon);
        $select('fb_addon','Add-on',$filters['addon'],$addons,$addon_labels);
        $select('fb_status','Status',$filters['status'],['new','reviewing','resolved'],['new'=>'New','reviewing'=>'Reviewing','resolved'=>'Resolved']);
        $select('fb_tester','Tester',$filters['tester'],$testers);
        $select('fb_type','Type',$filters['type'],$types);
        $select('fb_tier','Product',$filters['tier'],$tiers);
        $select('fb_category','Category',$filters['category'],$categories);
        $select('fb_check_id','Check ID',$filters['check_id'],$check_ids);

        echo '<label style="display:block;grid-column:span 2"><span style="display:block;font-weight:600;margin-bottom:4px">Search</span><input type="search" name="fb_search" value="'.esc_attr($filters['search']).'" placeholder="Summary, details, check, tester…" style="width:100%"></label>';
        echo '<div style="display:flex;gap:8px;align-items:center"><button class="button button-primary" type="submit">Filter</button><a class="button" href="'.esc_url(admin_url('admin.php?page='.self::MENU.'-feedback')).'">Reset</a></div>';
        echo '</div></form>';

        if ($this->zoho_configured()) {
            $sync_all_url=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_sync_all_zoho_tasks'),'snbm_sync_all_zoho_tasks');
            echo '<p style="margin:-6px 0 12px"><a class="button" href="'.esc_url($sync_all_url).'">Sync Zoho Status</a></p>';
        }

        if ($total_filtered === $total_all) echo '<p><strong>'.number_format_i18n($total_all).'</strong> feedback entr'.($total_all===1?'y':'ies').'.</p>';
        else echo '<p>Showing <strong>'.number_format_i18n(count($rows)).'</strong> of <strong>'.number_format_i18n($total_filtered).'</strong> matching entr'.($total_filtered===1?'y':'ies').' (<strong>'.number_format_i18n($total_all).'</strong> total).</p>';
        if ($total_filtered > 500) echo '<div class="notice notice-warning inline"><p>More than 500 reports match these filters. Refine the filters to narrow the results.</p></div>';

        echo '<table class="widefat striped" id="snbm-feedback-table"><thead><tr><th>Date</th><th>Status</th><th>Add-on</th><th>Tester</th><th>Type</th><th>Product</th><th>Summary</th><th>Environment</th><th>Attachments</th></tr></thead><tbody>';
        if (!$rows) echo '<tr><td colspan="9">No feedback matches the selected filters.</td></tr>';
        foreach($rows as $r){
            $atts=json_decode($r['attachments'],true);
            $detail=admin_url('admin.php?page='.self::MENU.'-feedback&feedback_id='.intval($r['id']));
            $status=$r['status'] ?: 'new';
            echo '<tr class="snbm-feedback-row" data-href="'.esc_url($detail).'" style="cursor:pointer">';
            echo '<td>'.esc_html($this->local_datetime($r['submitted_at'])).'</td><td>'.$this->feedback_status_badge($status).'</td>';
            echo '<td>'.esc_html($this->addon_label($r['addon_id'] ?? 'qc_checker')).'</td>';
            echo '<td><code>'.esc_html($r['tester_id']).'</code><br>'.esc_html($r['tester_email']).'</td><td>'.esc_html($r['report_type']).'</td>';
            echo '<td>'.esc_html($r['tier']).'<br>'.esc_html($r['category']).'<br>'.esc_html($r['check_name']).($r['check_id'] ? '<br><code>'.esc_html($r['check_id']).'</code>' : '').'</td>';
            echo '<td><a href="'.esc_url($detail).'" style="font-weight:600">'.esc_html($r['summary']).'</a><br><span style="color:#646970">'.esc_html(wp_trim_words($r['details'],18,'…')).'</span></td>';
            echo '<td>QC '.esc_html($r['qc_version']).'<br>Blender '.esc_html($r['blender_version']).'<br>'.esc_html($r['operating_system']).'</td><td>';
            if(is_array($atts)) foreach($atts as $a) echo '<a class="snbm-no-row-click" href="'.esc_url($a['url']).'" target="_blank" rel="noopener">'.esc_html($a['name']).'</a><br>';
            echo '</td></tr>';
        }
        echo '</tbody></table>';
        echo '<script>document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll(".snbm-feedback-row").forEach(function(row){row.addEventListener("click",function(e){if(e.target.closest("a,button,input,select,textarea"))return;window.location=row.dataset.href;});});});</script>';
        $this->admin_footer();
    }

    public function page_newsletter(){
        global $wpdb;
        $rows=$wpdb->get_results("SELECT * FROM {$this->tables['newsletter']} ORDER BY consent_at DESC",ARRAY_A);
        $this->admin_header('Newsletter Signups');
        if(!empty($_GET['unsubscribed'])) echo '<div class="notice notice-success is-dismissible"><p>Newsletter subscriber marked as unsubscribed.</p></div>';
        if(!empty($_GET['deleted'])) echo '<div class="notice notice-success is-dismissible"><p>Newsletter record permanently deleted.</p></div>';
        $export=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_export_newsletter'),'snbm_export_newsletter');
        echo '<p><a class="button" href="'.esc_url($export).'">Export CSV</a></p>';
        echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Source</th><th>Subscribed</th><th>Consent Date</th><th>IP</th><th>Actions</th></tr></thead><tbody>';
        foreach($rows as $r){
            $unsubscribe=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_unsubscribe_newsletter&id='.$r['id']),'snbm_unsubscribe_newsletter_'.$r['id']);
            $delete=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_delete_newsletter&id='.$r['id']),'snbm_delete_newsletter_'.$r['id']);
            $confirm='Delete newsletter record for '.$r['email'].'? This permanently removes the stored subscription record and consent history. This cannot be undone.';
            echo '<tr><td>'.esc_html($r['name']).'</td><td>'.esc_html($r['email']).'</td><td>'.esc_html($r['source']).'</td><td>'.($r['subscribed']?'Yes':'No').'</td><td>'.esc_html($r['consent_at']).'</td><td>'.esc_html($r['ip_address']).'</td><td>';
            if($r['subscribed']) echo '<a class="button" href="'.esc_url($unsubscribe).'">Unsubscribe</a> ';
            echo '<a class="button button-link-delete" href="'.esc_url($delete).'" onclick="return confirm('.esc_attr(wp_json_encode($confirm)).');">Delete</a>';
            echo '</td></tr>';
        }
        echo '</tbody></table>';
        $this->admin_footer();
    }


    public function page_settings(){
        $s=$this->settings();
        $this->admin_header('Beta Manager Settings');
        echo '<form method="post" action="options.php">';
        settings_fields('scriptronaut_beta_manager');
        $name=self::OPT;
        echo '<table class="form-table">';
        $fields=['recipient'=>['Notification recipient','email'],'from_email'=>['From email','email'],'from_name'=>['From name','text'],'subject_prefix'=>['Base email subject prefix','text'],'max_file_mb'=>['Max attachment size (MB)','number'],'max_total_mb'=>['Max total upload (MB)','number'],'rate_limit_count'=>['Submissions per rate window','number'],'rate_limit_window'=>['Rate window (seconds)','number'],'static_beta_url'=>['Static beta page URL','url'],'static_feedback_url'=>['Static feedback page URL','url']];
        foreach($fields as $k=>$f) {
            echo '<tr><th><label for="'.$k.'">'.esc_html($f[0]).'</label></th><td><input class="regular-text" id="'.$k.'" type="'.$f[1].'" name="'.$name.'['.$k.']" value="'.esc_attr($s[$k]).'">';
            if($k==='subject_prefix') echo '<p class="description">The beta program tag is added automatically, for example [Scriptronaut Beta] [QC Checker].</p>';
            echo '</td></tr>';
        }
        echo '<tr><th>Feedback notifications</th><td><label><input type="checkbox" name="'.$name.'[email_feedback_notifications]" value="1" '.checked(!empty($s['email_feedback_notifications']),true,false).'> Email the notification recipient whenever new beta feedback is submitted</label><p class="description">The email includes the report summary, environment, attachments, and a direct link to the report in Beta Manager.</p></td></tr>';
        echo '<tr><th colspan="2"><h2 style="margin-top:24px">Zoho Projects</h2></th></tr>';
        echo '<tr><th>Enable Zoho</th><td><label><input type="checkbox" name="'.$name.'[zoho_enabled]" value="1" '.checked(!empty($s['zoho_enabled']),true,false).'> Enable server-side Zoho task creation from feedback reports</label></td></tr>';
        $zfields=['zoho_client_id'=>'Client ID','zoho_client_secret'=>'Client Secret','zoho_refresh_token'=>'Refresh Token','zoho_portal_id'=>'Portal ID','zoho_portal_name'=>'Portal Name'];
        foreach($zfields as $k=>$label){$type=in_array($k,['zoho_client_secret','zoho_refresh_token'],true)?'password':'text';echo '<tr><th><label for="'.$k.'">'.esc_html($label).'</label></th><td><input class="regular-text" autocomplete="off" id="'.$k.'" type="'.$type.'" name="'.$name.'['.$k.']" value="'.esc_attr($s[$k] ?? '').'"></td></tr>';}

        echo '<tr><th>Product → Zoho Project</th><td>';
        try {
            global $wpdb;
            $products=$wpdb->get_col("SELECT DISTINCT tier FROM {$this->tables['feedback']} WHERE tier <> '' ORDER BY tier ASC");
            if (!in_array('Core',$products,true)) array_unshift($products,'Core');
            $projects=$this->zoho_auth_configured() ? $this->zoho_projects() : [];
            if (!$projects) {
                echo '<p class="description">Save valid Zoho credentials and Portal ID first. Available Zoho projects will then appear here.</p>';
            } else {
                echo '<table class="widefat striped" style="max-width:650px"><thead><tr><th>Beta Product</th><th>Zoho Project</th></tr></thead><tbody>';
                foreach ($products as $product) {
                    $mapped=(string)(($s['zoho_project_mappings'][$product] ?? ''));
                    if ($mapped==='' && strcasecmp($product,'Core')===0) $mapped=(string)($s['zoho_project_id'] ?? '');
                    echo '<tr><td><strong>'.esc_html($product).'</strong></td><td><select name="'.$name.'[zoho_project_mappings]['.esc_attr($product).']"><option value="">Select project...</option>';
                    foreach ($projects as $project) echo '<option value="'.esc_attr($project['id']).'" '.selected($mapped,$project['id'],false).'>'.esc_html($project['name']).'</option>';
                    echo '</select></td></tr>';
                }
                echo '</tbody></table>';
            }
        } catch (\Exception $e) {
            echo '<p style="color:#b32d2e">Could not load Zoho projects: '.esc_html($e->getMessage()).'</p>';
        }
        echo '<p class="description">Each feedback Product is routed to its mapped Zoho project. New products appear here automatically after feedback for that product exists.</p></td></tr>';
        echo '<tr><th></th><td><p class="description">Credentials remain on the WordPress server and are never sent to Blender beta clients. Projects, users, statuses, phases, and task lists are discovered dynamically and cached for 5 minutes.</p></td></tr>';
        echo '</table>';
        submit_button();
        echo '</form><h2>Form actions</h2><p>Set the signup form action to:</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_beta_signup')).'</code><p>Set the feedback form action to:</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_beta_feedback')).'</code><p>Newsletter-only form action (Relay):</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_relay_subscribe')).'</code>';
        $this->admin_footer();
    }

    private function csv_download($filename,$headers,$rows){nocache_headers();header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="'.$filename.'"');$o=fopen('php://output','w');fputcsv($o,$headers);foreach($rows as $r)fputcsv($o,$r);fclose($o);exit;}
    public function export_newsletter(){if(!current_user_can('manage_options'))wp_die('Unauthorized');check_admin_referer('snbm_export_newsletter');global $wpdb;$rows=$wpdb->get_results("SELECT name,email,source,consent_at FROM {$this->tables['newsletter']} WHERE subscribed=1 ORDER BY consent_at DESC",ARRAY_N);$this->csv_download('scriptronaut-newsletter.csv',['Name','Email','Source','Consent Date'],$rows);}
    public function export_candidates(){if(!current_user_can('manage_options'))wp_die('Unauthorized');check_admin_referer('snbm_export_candidates');global $wpdb;$rows=$wpdb->get_results("SELECT name,email,addon_id,blender_use,blender_version,newsletter_optin,status,submitted_at FROM {$this->tables['candidates']} ORDER BY submitted_at DESC",ARRAY_N);$this->csv_download('scriptronaut-beta-candidates.csv',['Name','Email','Add-on','Blender Use','Blender Version','Newsletter','Status','Submitted'],$rows);}
}

register_activation_hook(__FILE__, ['Scriptronaut_Beta_Manager','activate']);
Scriptronaut_Beta_Manager::instance();
