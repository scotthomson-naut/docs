=== Scriptronaut Flux ===
Contributors: scriptronaut
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 0.1.2

Download analytics for Scriptronaut free add-ons and items.

== Installation ==
1. Upload/install the scriptronaut-flux folder as a WordPress plugin.
2. Activate Scriptronaut Flux.
3. Open Flux > Settings and confirm the Free items URL.
4. Upload the updated Scriptronaut documentation/free page files.

== Privacy ==
Flux stores each download event, item metadata, timestamp, referrer, and a one-way salted visitor hash.
It does not store raw visitor IP addresses.
