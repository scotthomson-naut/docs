<?php
/**
 * Plugin Name: Scriptronaut Flux
 * Description: Download analytics for Scriptronaut free add-ons and items.
 * Version: 0.1.2
 * Author: Scriptronaut
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

final class Scriptronaut_Flux {
    const VERSION = '0.1.2';
    const DB_VERSION = '0.1.0';
    const OPT = 'scriptronaut_flux_settings';
    const MENU = 'scriptronaut-flux';

    private static $instance = null;
    private $table;

    public static function instance() {
        return self::$instance ?: (self::$instance = new self());
    }

    private function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'scriptronaut_flux_downloads';

        add_action('init', array($this, 'maybe_upgrade'), 1);
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_head', array($this, 'admin_menu_icon_css'));

        add_action('admin_post_nopriv_scriptronaut_flux_download', array($this, 'download'));
        add_action('admin_post_scriptronaut_flux_download', array($this, 'download'));
        add_action('admin_post_scriptronaut_flux_export', array($this, 'export_csv'));
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = $wpdb->prefix . 'scriptronaut_flux_downloads';
        $charset = $wpdb->get_charset_collate();

        dbDelta("CREATE TABLE {$table} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            item_key varchar(120) NOT NULL,
            item_name varchar(180) NOT NULL DEFAULT '',
            item_group varchar(80) NOT NULL DEFAULT '',
            downloaded_at datetime NOT NULL,
            visitor_hash char(64) NOT NULL DEFAULT '',
            referrer varchar(500) NOT NULL DEFAULT '',
            PRIMARY KEY (id),
            KEY item_key (item_key),
            KEY downloaded_at (downloaded_at),
            KEY item_date (item_key, downloaded_at)
        ) {$charset};");

        if (!get_option(self::OPT)) {
            $root = preg_replace('#/wp/?$#i', '', site_url());
            add_option(self::OPT, array(
                'free_items_url' => trailingslashit($root) . 'free_items/',
            ));
        }

        update_option('scriptronaut_flux_db_version', self::DB_VERSION);
    }

    public function maybe_upgrade() {
        if ((string) get_option('scriptronaut_flux_db_version') !== self::DB_VERSION) {
            self::activate();
        }
    }

    public function register_settings() {
        register_setting('scriptronaut_flux', self::OPT, array($this, 'sanitize_settings'));
    }

    public function sanitize_settings($value) {
        $url = esc_url_raw($value['free_items_url'] ?? '');
        return array('free_items_url' => trailingslashit($url));
    }

    private function settings() {
        $root = preg_replace('#/wp/?$#i', '', site_url());
        return wp_parse_args(
            (array) get_option(self::OPT, array()),
            array('free_items_url' => trailingslashit($root) . 'free_items/')
        );
    }

    public function menu() {
        $icon = 'data:image/svg+xml;base64,Cgo8IS0tIENyZWF0b3I6IENvcmVsRFJBVyAyMDIxICg2NC1CaXQpIC0tPgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSIgd2lkdGg9IjI4cHgiIGhlaWdodD0iMzJweCIgdmVyc2lvbj0iMS4xIiBzaGFwZS1yZW5kZXJpbmc9Imdlb21ldHJpY1ByZWNpc2lvbiIgdGV4dC1yZW5kZXJpbmc9Imdlb21ldHJpY1ByZWNpc2lvbiIgaW1hZ2UtcmVuZGVyaW5nPSJvcHRpbWl6ZVF1YWxpdHkiIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIgp2aWV3Qm94PSIwIDAgMjcuNDEgMzEuNyIKIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIgogeG1sbnM6eG9kbT0iaHR0cDovL3d3dy5jb3JlbC5jb20vY29yZWxkcmF3L29kbS8yMDAzIj4KIDxnIGlkPSJMYXllcl94MDAyMF8xIj4KICAKICA8cGF0aCBmaWxsPSIjMDhBQ0EwIiBmaWxsLXJ1bGU9Im5vbnplcm8iIGQ9Ik0xMC42MSA5LjQyYzAsLTAuNTIgMC40MywtMC45NSAwLjk1LC0wLjk1IDAuNTMsMCAwLjk2LDAuNDMgMC45NiwwLjk1bDAgMy4yMmMwLDAuNTIgLTAuNDMsMC45NSAtMC45NiwwLjk1IC0wLjUyLDAgLTAuOTUsLTAuNDMgLTAuOTUsLTAuOTVsMCAtMy4yMnptLTcuNjEgLTIuMTRsMjEuNDEgMCAwIC0xLjI4YzEuNjUsMCAzLC0xLjM2IDMsLTNsMCAtMi4xNGMwLC0wLjQ4IC0wLjM4LC0wLjg2IC0wLjg1LC0wLjg2bC0yNS43IDBjLTAuNDgsMCAtMC44NiwwLjM4IC0wLjg2LDAuODZsMCAyLjE0YzAsMS42NSAxLjM1LDMgMywzbDAgMS4yOHptOC41NiAtMy4yMWwwIC0yLjM2IDQuMjkgMCAwIDIuMzYgLTQuMjkgMHptMTIuODUgMjAuMzRsLTIxLjQxIDAgMCAxLjI5Yy0xLjY1LDAgLTMsMS4zNSAtMywzbDAgMi4xNGMwLDAuNDcgMC4zOCwwLjg2IDAuODYsMC44NmwyNS43IDBjMC40NywwIDAuODUsLTAuMzkgMC44NSwtMC44NmwwIC0yLjE0YzAsLTEuNjUgLTEuMzUsLTMgLTMsLTNsMCAtMS4yOXptLTguNTYgNS41N2wwIC0yLjM1IDIuMTQgMCAwIDIuMzUgLTIuMTQgMHptNC4yOCAwbDAgLTIuMzUgMi4xNCAwIDAgMi4zNSAtMi4xNCAwem0tNC4yOCAtNi44MWMwLjQ5LDAgMC44OSwtMC40IDAuODksLTAuOSAwLC0wLjQ5IC0wLjQsLTAuODkgLTAuODksLTAuODkgLTAuNSwwIC0wLjksMC40IC0wLjksMC44OSAwLDAuNSAwLjQsMC45IDAuOSwwLjl6bS01LjI0IC04LjM5YzAsLTAuNTMgMC40MywtMC45NiAwLjk1LC0wLjk2IDAuNTMsMCAwLjk2LDAuNDMgMC45NiwwLjk2bDAgNy40OWMwLDAuNTMgLTAuNDMsMC45NSAtMC45NiwwLjk1IC0wLjUyLDAgLTAuOTUsLTAuNDIgLTAuOTUsLTAuOTVsMCAtNy40OXptLTQuMjggNS4zNWMwLC0wLjUzIDAuNDMsLTAuOTUgMC45NSwtMC45NSAwLjUzLDAgMC45NSwwLjQyIDAuOTUsMC45NWwwIDIuMTRjMCwwLjUzIC0wLjQyLDAuOTUgLTAuOTUsMC45NSAtMC41MiwwIC0wLjk1LC0wLjQyIC0wLjk1LC0wLjk1bDAgLTIuMTR6bTAgLTEwLjcxYzAsLTAuNTIgMC40MywtMC45NSAwLjk1LC0wLjk1IDAuNTMsMCAwLjk1LDAuNDMgMC45NSwwLjk1bDAgOC41N2MwLDAuNTIgLTAuNDIsMC45NSAtMC45NSwwLjk1IC0wLjUyLDAgLTAuOTUsLTAuNDMgLTAuOTUsLTAuOTVsMCAtOC41N3ptOS41MiA1LjM3bDAuNzggMi4zNSAyLjQxIDAuODUgLTIuMzUgMC43OCAtMC44NCAyLjQyIC0wLjc4IC0yLjM1IC0yLjQyIC0wLjg1IDIuMzUgLTAuNzggMC44NSAtMi40MnptNC4yOCAtNi40MmwwLjc4IDIuMzUgMi40MiAwLjg0IC0yLjM1IDAuNzkgLTAuODUgMi40MSAtMC43OCAtMi4zNSAtMi40MiAtMC44NSAyLjM1IC0wLjc4IDAuODUgLTIuNDF6bS0wLjk1IDcuNDhjMCwtMC41MyAwLjQyLC0wLjk1IDAuOTUsLTAuOTUgMC41MywwIDAuOTUsMC40MiAwLjk1LDAuOTVsMCA2LjQyYzAsMC41MyAtMC40MiwwLjk1IC0wLjk1LDAuOTUgLTAuNTMsMCAtMC45NSwtMC40MiAtMC45NSwtMC45NWwwIC02LjQyem0tNC4yOCAtNi40M2MwLC0wLjUyIDAuNDIsLTAuOTUgMC45NSwtMC45NSAwLjUyLDAgMC45NSwwLjQzIDAuOTUsMC45NWwwIDQuMjljMCwwLjUyIC0wLjQzLDAuOTUgLTAuOTUsMC45NSAtMC41MywwIC0wLjk1LC0wLjQzIC0wLjk1LC0wLjk1bDAgLTQuMjl6Ii8+CiA8L2c+Cjwvc3ZnPgo=';
        add_menu_page(
            'Scriptronaut Flux',
            'Flux',
            'manage_options',
            self::MENU,
            array($this, 'dashboard'),
            $icon,
            58.5
        );
        add_submenu_page(self::MENU, 'Flux Dashboard', 'Dashboard', 'manage_options', self::MENU, array($this, 'dashboard'));
        add_submenu_page(self::MENU, 'Flux Downloads', 'Downloads', 'manage_options', self::MENU . '-downloads', array($this, 'downloads_page'));
        add_submenu_page(self::MENU, 'Flux Settings', 'Settings', 'manage_options', self::MENU . '-settings', array($this, 'settings_page'));
    }

    public function admin_menu_icon_css() {
        echo '<style>
            #adminmenu .toplevel_page_scriptronaut-flux .wp-menu-image img {
                opacity: 1 !important;
                width: 20px;
                height: 20px;
                padding-top: 7px;
            }
        </style>';
    }

    private function visitor_hash() {
        $ip = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? ''));
        $ua = sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? ''));
        return hash_hmac('sha256', $ip . '|' . $ua, wp_salt('auth'));
    }

    private function clean_item_key($value) {
        $value = strtolower(sanitize_text_field(wp_unslash($value)));
        return preg_match('/^[a-z0-9_-]+$/', $value) ? $value : '';
    }

    public function download() {
        global $wpdb;

        $item = $this->clean_item_key($_GET['item'] ?? '');
        if (!$item) {
            wp_die('Invalid Flux download item.', 'Flux', array('response' => 400));
        }

        $name = sanitize_text_field(wp_unslash($_GET['name'] ?? ''));
        $group = sanitize_key(wp_unslash($_GET['group'] ?? ''));
        if ($name === '') {
            $name = ucwords(str_replace(array('_', '-'), ' ', $item));
        }

        $settings = $this->settings();
        $target = trailingslashit($settings['free_items_url']) . rawurlencode($item) . '.zip';

        $wpdb->insert(
            $this->table,
            array(
                'item_key' => $item,
                'item_name' => $name,
                'item_group' => $group,
                'downloaded_at' => current_time('mysql', true),
                'visitor_hash' => $this->visitor_hash(),
                'referrer' => esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'] ?? '')),
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );

        nocache_headers();
        wp_redirect($target, 302, 'Scriptronaut Flux');
        exit;
    }

    private function utc_now() {
        return current_time('timestamp', true);
    }

    private function since_mysql($seconds) {
        return gmdate('Y-m-d H:i:s', $this->utc_now() - $seconds);
    }

    private function count_where($where = '1=1') {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table} WHERE {$where}");
    }

    private function format_local_datetime($utc_mysql) {
        if (!$utc_mysql) return '—';

        try {
            $dt = new DateTime($utc_mysql, new DateTimeZone('UTC'));
            $dt->setTimezone(wp_timezone());
            return wp_date('Y-m-d H:i:s', $dt->getTimestamp(), wp_timezone());
        } catch (Exception $e) {
            return $utc_mysql;
        }
    }

    private function header($title, $show_icon = false, $description = '') {
        $icon = plugins_url('assets/flux.svg', __FILE__);
        echo '<div class="wrap flux-wrap">';
        echo '<style>
            .flux-wrap{--flux:#08ACA0;max-width:1280px}
            .flux-title{display:flex;align-items:center;gap:16px;margin:12px 0 8px}
            .flux-title img{width:64px;height:64px}
            .flux-title h1{margin:0 0 5px;font-size:26px}
            .flux-stats{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:14px;margin:0 0 24px}
            .flux-stat{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:18px}
            .flux-stat strong{display:block;color:var(--flux);font-size:30px;line-height:1.1;margin-bottom:5px}
            .flux-stat span{color:#50575e;font-weight:600}
            .flux-card{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:20px;margin:0 0 22px}
            .flux-card h2{margin-top:0}
            .flux-accent{color:var(--flux)}
            .flux-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:0 0 18px}
            .flux-bar{height:8px;background:#e8eeee;border-radius:999px;overflow:hidden;min-width:100px}
            .flux-bar span{display:block;height:100%;background:var(--flux)}
            .flux-empty{padding:28px;text-align:center;color:#646970}
            @media(max-width:900px){.flux-stats{grid-template-columns:repeat(2,1fr)}}
        </style>';
        echo '<div class="flux-title">';
        if ($show_icon) {
            echo '<img src="' . esc_url($icon) . '" alt="">';
        }
        echo '<div><h1>' . esc_html($title) . '</h1>';
        if ($description !== '') {
            echo '<p style="margin:0;color:#50575e;">' . esc_html($description) . '</p>';
        }
        echo '</div></div>';
    }

    private function footer() {
        echo '</div>';
    }

    public function dashboard() {
        if (!current_user_can('manage_options')) return;
        global $wpdb;

        $today = gmdate('Y-m-d 00:00:00', $this->utc_now());
        $month = gmdate('Y-m-01 00:00:00', $this->utc_now());
        $week = $this->since_mysql(7 * DAY_IN_SECONDS);

        $selected_item = $this->clean_item_key($_GET['flux_item'] ?? '');
        $selected_group = sanitize_key(wp_unslash($_GET['flux_group'] ?? ''));

        $items = $wpdb->get_results(
            "SELECT item_key, MAX(item_name) item_name
             FROM {$this->table}
             GROUP BY item_key
             ORDER BY item_name ASC, item_key ASC",
            ARRAY_A
        );

        $groups = $wpdb->get_col(
            "SELECT DISTINCT item_group
             FROM {$this->table}
             WHERE item_group <> ''
             ORDER BY item_group ASC"
        );

        $where = array();
        $params = array();

        if ($selected_item !== '') {
            $where[] = 'item_key = %s';
            $params[] = $selected_item;
        }

        if ($selected_group !== '') {
            $where[] = 'item_group = %s';
            $params[] = $selected_group;
        }

        $where_sql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

        $query =
            "SELECT item_key,
                    MAX(item_name) item_name,
                    MAX(item_group) item_group,
                    COUNT(*) total,
                    SUM(downloaded_at >= %s) today_count,
                    SUM(downloaded_at >= %s) week_count,
                    SUM(downloaded_at >= %s) month_count,
                    MAX(downloaded_at) last_download
             FROM {$this->table}" . $where_sql . "
             GROUP BY item_key
             ORDER BY total DESC, item_key ASC";

        $query_params = array_merge(array($today, $week, $month), $params);
        $rows = $wpdb->get_results($wpdb->prepare($query, $query_params), ARRAY_A);

        $group_counts = $wpdb->get_results(
            "SELECT item_group, COUNT(*) downloads
             FROM {$this->table}
             GROUP BY item_group",
            OBJECT_K
        );

        $total = $this->count_where();
        $max = 1;
        foreach ($rows as $r) $max = max($max, (int) $r['total']);

        $this->header(
            'Scriptronaut Flux',
            true,
            'Track and review download activity for Scriptronaut free add-ons and items.'
        );

        echo '<div class="flux-stats" style="grid-template-columns:repeat(5,minmax(130px,1fr));">';
        $summary = array(
            'All' => $total,
            'Assets' => isset($group_counts['assets']) ? (int) $group_counts['assets']->downloads : 0,
            'Geo Nodes' => isset($group_counts['geo_nodes']) ? (int) $group_counts['geo_nodes']->downloads : 0,
            'Settings' => isset($group_counts['settings']) ? (int) $group_counts['settings']->downloads : 0,
            'Tools' => isset($group_counts['tools']) ? (int) $group_counts['tools']->downloads : 0,
        );
        foreach ($summary as $label => $value) {
            echo '<div class="flux-stat"><strong>' . number_format_i18n($value) . '</strong><span>' . esc_html($label) . '</span></div>';
        }
        echo '</div>';

        echo '<div class="flux-card" style="padding:10px 14px 8px;">';
        echo '<form method="get" action="' . esc_url(admin_url('admin.php')) . '">';
        echo '<input type="hidden" name="page" value="' . esc_attr(self::MENU) . '">';
        echo '<div style="display:flex;gap:16px;align-items:flex-end;flex-wrap:wrap;">';

        echo '<div><label for="flux-item"><strong>Item name</strong></label><br>';
        echo '<select id="flux-item" name="flux_item" style="min-width:190px;margin-top:6px;">';
        echo '<option value="">All</option>';
        foreach ($items as $item) {
            $label = $item['item_name'] ?: $item['item_key'];
            echo '<option value="' . esc_attr($item['item_key']) . '"' . selected($selected_item, $item['item_key'], false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></div>';

        echo '<div><label for="flux-group"><strong>Group</strong></label><br>';
        echo '<select id="flux-group" name="flux_group" style="min-width:190px;margin-top:6px;">';
        echo '<option value="">All</option>';
        foreach ($groups as $group) {
            echo '<option value="' . esc_attr($group) . '"' . selected($selected_group, $group, false) . '>' . esc_html(ucwords(str_replace('_', ' ', $group))) . '</option>';
        }
        echo '</select></div>';

        echo '<div style="padding-bottom:1px;"><button class="button button-primary" type="submit">Filter</button> ';
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=' . self::MENU)) . '">Reset</a></div>';
        echo '</div></form></div>';

        echo '<div class="flux-card"><h2>Free Item Downloads</h2>';
        if (!$rows) {
            echo '<div class="flux-empty">No downloads match the current filters.</div>';
        } else {
            echo '<table class="widefat striped"><thead><tr><th>Item</th><th>Group</th><th>Total</th><th>Today</th><th>7 Days</th><th>This Month</th><th>Activity</th><th>Last Download</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                $pct = max(3, round(((int) $r['total'] / $max) * 100));
                echo '<tr>';
                echo '<td><strong>' . esc_html($r['item_name'] ?: $r['item_key']) . '</strong><br><code>' . esc_html($r['item_key']) . '</code></td>';
                echo '<td>' . esc_html($r['item_group'] ?: '—') . '</td>';
                echo '<td><strong class="flux-accent">' . number_format_i18n((int) $r['total']) . '</strong></td>';
                echo '<td>' . number_format_i18n((int) $r['today_count']) . '</td>';
                echo '<td>' . number_format_i18n((int) $r['week_count']) . '</td>';
                echo '<td>' . number_format_i18n((int) $r['month_count']) . '</td>';
                echo '<td><div class="flux-bar"><span style="width:' . esc_attr($pct) . '%"></span></div></td>';
                echo '<td>' . esc_html($this->format_local_datetime($r['last_download'])) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';

        $this->footer();
    }

    public function downloads_page() {
        if (!current_user_can('manage_options')) return;
        global $wpdb;

        $rows = $wpdb->get_results(
            "SELECT id,item_key,item_name,item_group,downloaded_at,referrer
             FROM {$this->table}
             ORDER BY id DESC
             LIMIT 1000",
            ARRAY_A
        );

        $this->header('Flux Downloads');
        echo '<p>Showing the latest 1,000 recorded download events. Flux does not store visitors\' raw IP addresses.</p>';
        echo '<div class="flux-actions"><a class="button" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_flux_export'), 'flux_export')) . '">Export CSV</a></div>';
        echo '<div class="flux-card">';
        if (!$rows) {
            echo '<div class="flux-empty">No downloads have been recorded yet.</div>';
        } else {
            echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Item</th><th>Group</th><th>Referrer</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                echo '<tr><td>' . esc_html($this->format_local_datetime($r['downloaded_at'])) . '</td><td><strong>' . esc_html($r['item_name']) . '</strong><br><code>' . esc_html($r['item_key']) . '</code></td><td>' . esc_html($r['item_group'] ?: '—') . '</td><td>';
                if ($r['referrer']) {
                    echo '<a href="' . esc_url($r['referrer']) . '" target="_blank" rel="noopener">' . esc_html($r['referrer']) . '</a>';
                } else {
                    echo '—';
                }
                echo '</td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';
        $this->footer();
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) return;
        $s = $this->settings();

        $this->header('Flux Settings');
        echo '<div class="flux-card">';
        echo '<form method="post" action="options.php">';
        settings_fields('scriptronaut_flux');
        echo '<table class="form-table">';
        echo '<tr><th scope="row"><label for="flux-free-items-url">Free items URL</label></th><td>';
        echo '<input id="flux-free-items-url" class="regular-text code" type="url" name="' . esc_attr(self::OPT) . '[free_items_url]" value="' . esc_attr($s['free_items_url']) . '">';
        echo '<p class="description">Public URL of the folder containing the downloadable ZIP files. Example: <code>https://scriptronaut.com/free_items/</code></p>';
        echo '</td></tr>';
        echo '</table>';
        submit_button();
        echo '</form>';
        echo '</div>';

        $endpoint = admin_url('admin-post.php?action=scriptronaut_flux_download&item=example_item&name=Example%20Item&group=tools');
        echo '<div class="flux-card"><h2>Tracking Endpoint</h2><p>Your free page sends downloads through Flux, which records the event and redirects to the ZIP.</p><code>' . esc_html($endpoint) . '</code></div>';
        $this->footer();
    }

    public function export_csv() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('flux_export');
        global $wpdb;

        $rows = $wpdb->get_results(
            "SELECT downloaded_at,item_key,item_name,item_group,referrer
             FROM {$this->table}
             ORDER BY id DESC",
            ARRAY_N
        );

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="scriptronaut-flux-downloads.csv"');

        $out = fopen('php://output', 'w');
        fputcsv($out, array('Downloaded At UTC', 'Item Key', 'Item Name', 'Group', 'Referrer'));
        foreach ($rows as $row) fputcsv($out, $row);
        fclose($out);
        exit;
    }
}

register_activation_hook(__FILE__, array('Scriptronaut_Flux', 'activate'));
Scriptronaut_Flux::instance();
