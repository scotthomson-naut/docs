Scriptronaut Relay 0.1.14

Newsletter manager for Scriptronaut.

Features
- Subscriber database and CSV export
- Upload locally designed HTML newsletters
- Campaign IDs from filenames such as relay_2026-09.html
- Preview and download stored HTML
- Test sends
- Queued/batched newsletter sending through WordPress wp_mail()
- Delivery log
- Signed unsubscribe links
- HTML placeholders: {{unsubscribe_url}} and {{unsubscribe_link}}

Recommended workflow
1. Install and activate Relay.
2. Open Relay > Settings and verify From Email and Test Email.
3. Beta Manager newsletter opt-ins are sent directly to Relay.
4. Change the newsletter-only website form action to:
   /wp/wp-admin/admin-post.php?action=scriptronaut_relay_subscribe
   (Use the exact URL shown on the Relay Dashboard.)
5. Design newsletters locally and save them as relay_YYYY-MM.html.
6. Upload in Relay > Newsletters, Send Test, then Send Newsletter.

Note: Confirm Send now starts Relay delivery immediately. Relay processes the queue in the configured batch size and automatically triggers the next batch until the queue is empty. A one-time WP-Cron event is retained only as a fallback while deliveries remain queued. For larger lists, use an SMTP/transactional mail provider through WordPress so wp_mail() is delivered by that provider.

0.1.1
- Added a dedicated send confirmation screen showing the number of active subscribers.
- Added duplicate-send protection so a campaign cannot be queued twice.

== 0.1.2 ==
* Added Edit / Replace workflow for draft campaigns.
* Edit subject and title without re-uploading HTML.
* Replace campaign HTML while keeping the campaign ID unchanged.
* Sent/queued campaigns are locked against editing.

0.1.3
- Sent campaigns now show only Preview, Download HTML, and Delete actions.
- Upload form filename, subject, and title suggestions now automatically use the next calendar month.


0.1.12
- Removed the legacy Import / Update from Beta Manager action now that Beta Manager sends newsletter opt-ins directly to Relay.
- Added Delete All Unsubscribed on the Subscribers page, shown only when unsubscribed records exist.
- Bulk deletion targets only records whose status is unsubscribed and requires confirmation.



== 0.1.14 ==
* Added a Recipients column to Recent Campaigns on the Relay Dashboard.
* Recipient totals show successful deliveries for each sent campaign, preserving the historical sent count.

== 0.1.13 ==
* Confirm Send now starts queue processing immediately instead of waiting for normal WP-Cron traffic.
* Each completed batch automatically triggers the next batch until the queue is empty.
* Messages per batch continues to control the maximum messages processed per worker request.
* A one-time WP-Cron event is kept only as a fallback while queued deliveries remain.
