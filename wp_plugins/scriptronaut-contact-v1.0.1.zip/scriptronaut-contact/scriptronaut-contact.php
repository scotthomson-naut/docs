<?php
/**
 * Plugin Name: Scriptronaut Contact
 * Description: Handles the Scriptronaut website contact modal through WordPress.
 * Version: 1.0.1
 * Author: Scriptronaut
 */
if (!defined('ABSPATH')) exit;

final class Scriptronaut_Contact {
    private const DESTINATION = 'contact@scriptronaut.com';
    private const RETURN_URL = 'https://scriptronaut.com/';

    public static function init(): void {
        add_action('admin_post_nopriv_scriptronaut_contact', [__CLASS__, 'submit']);
        add_action('admin_post_scriptronaut_contact', [__CLASS__, 'submit']);
    }

    private static function redirect(string $result): void {
        wp_safe_redirect(add_query_arg('contact', $result, self::RETURN_URL));
        exit;
    }

    public static function submit(): void {
        if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') self::redirect('error');
        if (!empty($_POST['website'])) self::redirect('sent');

        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        $rate_key = 'scriptronaut_contact_' . hash('sha256', wp_salt('auth') . '|' . $ip);
        if (get_transient($rate_key)) self::redirect('error');
        set_transient($rate_key, 1, MINUTE_IN_SECONDS);

        $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
        $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
        $subject = sanitize_text_field(wp_unslash($_POST['subject'] ?? ''));
        $message = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));
        $allowed = ['General question','QC Checker','Free tools','Website','Business / other'];

        if ($name === '' || !is_email($email) || !in_array($subject, $allowed, true) || $message === '') {
            self::redirect('error');
        }

        $mail_subject = '[Scriptronaut Contact] ' . $subject;
        $body = "Name: {$name}\nEmail: {$email}\nSubject: {$subject}\n\nMessage:\n{$message}\n";
        $headers = ['Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $name . ' <' . $email . '>'];
        self::redirect(wp_mail(self::DESTINATION, $mail_subject, $body, $headers) ? 'sent' : 'error');
    }
}
Scriptronaut_Contact::init();
