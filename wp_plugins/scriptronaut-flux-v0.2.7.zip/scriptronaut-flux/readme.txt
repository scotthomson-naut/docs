=== Scriptronaut Flux ===
Contributors: scriptronaut
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 0.2.7

Download analytics for Scriptronaut free add-ons and items.

== Installation ==
1. Upload/install the scriptronaut-flux folder as a WordPress plugin.
2. Activate Scriptronaut Flux.
3. Open Flux > Settings and confirm the Free items URL.
4. Upload the updated Scriptronaut documentation/free page files.

== Privacy ==
Flux stores each download event, item metadata, timestamp, referrer, and a one-way salted visitor hash.
It does not store raw visitor IP addresses.


== 0.2.0 ==
* Added item, group, and date-range filters to Downloads.
* Added single and bulk deletion of download events.
* Item names open an item history view.
* Added approximate unique download statistics.
* Added per-item 30-day download trend visualization.
* Removed Referrer from the Downloads table and reordered columns.


== 0.2.1 ==
* Restored the original neutral Flux SVG asset for the WordPress admin menu.
* Flux dashboard logo is recolored to #08ACA0 at render time, matching Relay's icon handling.


== 0.2.2 ==
* Fixed the Flux dashboard logo by using a dedicated teal SVG asset URL.
* Kept the original neutral flux.svg exclusively for the WordPress admin menu.


== 0.2.3 ==
* Dashboard and menu now use the same original neutral flux.svg asset, matching Relay.
* Dashboard recolors that SVG to #08ACA0 at render time.
* Fixed the dashboard data-URI image by using esc_attr(), as Relay does, instead of esc_url().


== 0.2.4 ==
* Added clickable sorting to Total, Today, 7 Days, This Month, and Last Download on the dashboard.
* Sort direction toggles ascending/descending and preserves active Item and Group filters.
* Added an arrow indicator to the active sort column.


== 0.2.5 ==
* Matched Flux sorting indicators to Beta Manager: ↕ unsorted, ↑ ascending, ↓ descending.


== 0.2.6 ==
* Sortable dashboard column headings now use WordPress link blue, matching Beta Manager.


== 0.2.7 ==
* Dashboard group summary cards are now generated dynamically from recorded download groups.
* New groups automatically appear without a plugin code update.
* Summary cards use a responsive auto-fit grid and wrap as groups are added.
* Group labels are automatically formatted from keys such as geo_nodes to Geo Nodes.
