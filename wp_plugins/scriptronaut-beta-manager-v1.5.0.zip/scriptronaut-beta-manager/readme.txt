=== Scriptronaut Beta Manager ===
Contributors: scriptronaut
Tags: beta, feedback, newsletter, blender
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.5.0

Manage QC Checker beta candidates, approved testers, tester access codes, feedback, file attachments, and newsletter opt-ins.

== Installation ==
1. Upload scriptronaut-beta-manager.zip in WordPress: Plugins > Add New > Upload Plugin.
2. Activate Scriptronaut Beta Manager.
3. Open Beta Manager > Settings and confirm notification/from email addresses and static page URLs.
4. Update the static forms to post to the WordPress action URLs shown on the Beta Manager dashboard.
5. Approve a candidate from Beta Manager > Candidates. The plugin emails the generated Tester ID and Access Code to the tester, and also shows them once in the admin screen. The access code is stored only as a hash.

== Static form actions ==
For WordPress installed at /wp:
Signup: /wp/wp-admin/admin-post.php?action=scriptronaut_beta_signup
Feedback: /wp/wp-admin/admin-post.php?action=scriptronaut_beta_feedback

The signup form supports an optional newsletter checkbox:
<input type="checkbox" name="newsletter_optin" value="yes">

== Security ==
Public forms use a honeypot plus IP rate limiting. Tester access codes are hashed. Admin actions use WordPress capabilities and nonces. Uploaded feedback files are handled by WordPress and subject to plugin limits plus server/PHP limits.

Newsletter-only action: /wp/wp-admin/admin-post.php?action=scriptronaut_beta_newsletter
Expected fields: name, email, and optional honeypot field website.


== Changelog ==

= 1.4.2 =
* Added an Enable action for disabled beta testers.
* Enabling restores tester access without generating a new access code or sending an email.


= 1.4.1 =
* Updated replacement access-code emails to clearly identify them as new beta credentials.
* Replacement emails now state that the previous access code is no longer valid.
* Initial candidate approval emails retain the original approval/welcome wording.

= 1.3.5 =
* Updated the WordPress admin Beta Manager menu icon to the new beta-manager.svg artwork.

== 1.3.1 ==
* Added a manual Sync Zoho Status button to the main Feedback page.
* Bulk sync checks only Zoho-linked feedback that is not already Resolved.
* Reports how many linked tasks were checked, how many Beta Manager statuses changed, and how many requests failed.
* No automatic/background polling is performed.


= 1.2.9 =
* Clear cached Zoho access token and Zoho lookup caches whenever Beta Manager settings are saved, so newly-authorized OAuth scopes take effect immediately.

= 1.2.8 =
* Uses the Zoho Projects V3 all-tasklists endpoint instead of discovering task lists from existing tasks.
* Empty task lists such as General are now returned directly by Zoho.
* Filters portal task lists to the configured Zoho project and keeps the General Task List ID setting only as a last-resort fallback.
* Requires the ZohoProjects.tasklists.READ OAuth scope.

= 1.2.7 =
* Fixed General task-list selection for qc_core feedback when the General list is empty.
* Uses the verified General task-list ID 186620000000081029 unless a Settings override is supplied.
* Removes stale dynamically discovered General entries from the Zoho task-list selector.

= 1.2.6 =
* Zoho tasks created from Beta Manager feedback are automatically tagged beta-feedback.
* Reuses the existing beta-feedback tag when present and creates it only when missing.
* Tagging failures do not undo task creation or attachment transfer.

= 1.2.5 =
* Feedback attachments are copied to the linked Zoho task when Create Zoho Task succeeds.
* Original Beta Manager uploads are retained.
* Attachment upload results are shown in the feedback detail screen.
* Failed attachment uploads can be retried without creating a duplicate Zoho task.

= 1.2.4 =
* Once a feedback report is linked to a Zoho task, Zoho becomes the authority for its status.
* Manual New, Reviewing, and Resolved status buttons are hidden for Zoho-linked feedback.
* Added a Status managed by Zoho indicator beside linked feedback status.
* Server-side protection prevents manual status changes on Zoho-linked feedback; use Sync Status instead.

= 1.2.3 =
* Fixed Open in Zoho for Zoho Projects Canada by constructing the verified task-detail URL from the stored task API ID.
* Added a configurable Zoho Portal Name setting, defaulting to scriptronaut.
* Open in Zoho no longer depends on the V3 task response returning a browser link.

= 1.2.1 =
* Added consistent inner spacing to the feedback details panel.
= 1.0.5 =
* Added server-side feedback filters for status, tester, type, product, category, and Check ID.
* Added free-text search across summary, details, check, tester, email, and category.
* Added matching/total result counts plus a one-click Reset button.

= 1.0.4 =
* Added Delete Candidate with confirmation. Tester accounts, newsletter records, and feedback are retained.
* Added Delete Tester with confirmation. Existing feedback is retained; a linked candidate is returned to pending status so they can be approved again later.
* Added Newsletter Unsubscribe action that keeps the consent record but marks the subscriber as unsubscribed.
* Added permanent Delete action for newsletter records with confirmation.

= 1.0.3 =
* Feedback rows are clickable and open a full report view.
* Added New, Reviewing, and Resolved feedback statuses.
* Added status action buttons on the feedback detail screen.
* Added an optional Settings toggle for email notifications on new feedback.
* Feedback notification emails now include a direct link to the WordPress report.
* Added automatic database upgrade handling for the new feedback status fields.


= 1.1.1 =
* Tester actions now show one Send Access Email button per enrolled beta program.
* The tester keeps one shared access code; the selected beta program controls the email tag and feedback-form link.


= 1.1.2 =
* Added Beta Program and Active/Disabled filters to the Beta Testers screen.
* Added filtered tester counts and Reset action.


= 1.1.3 =
* Added PNG, JPG and JPEG to the feedback attachment server-side whitelist.
* Added explicit WordPress MIME support for Blender .blend feedback attachments.
* Supported feedback attachments are now .blend, .txt, .log, .png, .jpg, .jpeg and .zip.


= 1.1.4 =
* Removed direct .blend feedback uploads. Blender files must be placed inside a ZIP archive before submission.


= 1.1.5 =
* Beta Manager timestamps are stored in UTC and displayed in Montreal local time (America/Toronto).
* Daylight-saving time changes are handled automatically.
* Existing UTC feedback timestamps are converted for display without altering the stored database value.


= 1.1.6 =
* Added the custom Scriptronaut Beta Manager SVG icon to the WordPress admin menu.


= 1.1.7 =
* Replaced the Beta Manager WordPress admin menu icon with the corrected SVG artwork.


= 1.1.8 =
* Added permanent deletion of individual feedback reports from the Feedback detail screen.
* Deleting feedback also removes attachment files uploaded with that report.
* Added nonce, administrator permission, path-safety, and confirmation safeguards.


= 1.2.0 =
* Added optional server-side Zoho Projects integration for beta feedback triage.
* Added Zoho OAuth access-token caching so refresh tokens are not exchanged on every API request.
* Added dynamic Zoho project user, task status, and populated task-list lookups with five-minute caches.
* Added a Create Zoho Task panel to feedback details with Task List, Owner, Status, and Priority controls.
* Feedback details and tracebacks are copied into the created Zoho task description.
* Stores the Zoho API task ID and visible task prefix on the feedback record and marks linked feedback Reviewing.
* Added an optional General Task List ID fallback for empty General lists that cannot be discovered through the task feed.


= 1.2.2 =
* Reworked the linked Zoho Task panel to emphasize the visible task prefix and feedback summary instead of the internal API ID.
* Added Open in Zoho, which resolves the current task browser link through the Zoho API before opening it.
* Added manual Sync Status for linked Zoho tasks. Closed Zoho tasks mark Beta Manager feedback Resolved; all other Zoho task statuses mark it Reviewing.


1.3.3
- Fixed Zoho project discovery on the Product to Zoho Project Settings mapping.
- Project discovery now accepts V3 wrapped project responses and compatible project-name keys, and does not cache empty discovery results.
- Removed an invalid project-scoped cache clear that referenced an undefined variable while saving Settings.

1.3.2
- Added dynamic Product to Zoho Project mapping in Settings.
- Zoho projects are discovered from the configured portal and selected by name; long project IDs remain internal.
- Task creation, Bugs phase lookup, task-list creation/reuse, user lookup, tagging, and status sync now use the project mapped to each feedback Product.
- Existing Core installations automatically fall back to the previous single Project ID until Core mapping is saved.
- Removed the obsolete General Task List fallback from the Settings UI and routing logic.


1.3.9
- Newsletter opt-ins from beta signup are handed directly to Scriptronaut Relay when Relay is active.
- Newsletter-only form action now points to Relay.
- Removed Newsletter administration from the Beta Manager menu/dashboard.
- Retained the legacy newsletter table only as a safe fallback/migration source if Relay is temporarily inactive.


== Changelog ==
= 1.5.0 =
* Added tester search by Tester ID, name, or email.
* Added feedback count and most reported type to Testers.
* Added clickable tester profile with application, Blender environment, activity, and feedback history.
