=== Scriptronaut Beta Manager ===
Contributors: scriptronaut
Tags: beta, feedback, newsletter, blender
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.1.8

Manage QC Checker beta candidates, approved testers, tester access codes, feedback, file attachments, and newsletter opt-ins.

== Installation ==
1. Upload scriptronaut-beta-manager.zip in WordPress: Plugins > Add New > Upload Plugin.
2. Activate Scriptronaut Beta Manager.
3. Open Beta Manager > Settings and confirm notification/from email addresses and static page URLs.
4. Update the static forms to post to the WordPress action URLs shown on the Beta Manager dashboard.
5. Approve a candidate from Beta Manager > Candidates. The plugin emails the generated Tester ID and Access Code to the tester, and also shows them once in the admin screen. The access code is stored only as a hash.

== Static form actions ==
For WordPress installed at /wp:
Signup: /wp/wp-admin/admin-post.php?action=scriptronaut_beta_signup
Feedback: /wp/wp-admin/admin-post.php?action=scriptronaut_beta_feedback

The signup form supports an optional newsletter checkbox:
<input type="checkbox" name="newsletter_optin" value="yes">

== Security ==
Public forms use a honeypot plus IP rate limiting. Tester access codes are hashed. Admin actions use WordPress capabilities and nonces. Uploaded feedback files are handled by WordPress and subject to plugin limits plus server/PHP limits.

Newsletter-only action: /wp/wp-admin/admin-post.php?action=scriptronaut_beta_newsletter
Expected fields: name, email, and optional honeypot field website.


== Changelog ==
= 1.0.5 =
* Added server-side feedback filters for status, tester, type, product, category, and Check ID.
* Added free-text search across summary, details, check, tester, email, and category.
* Added matching/total result counts plus a one-click Reset button.

= 1.0.4 =
* Added Delete Candidate with confirmation. Tester accounts, newsletter records, and feedback are retained.
* Added Delete Tester with confirmation. Existing feedback is retained; a linked candidate is returned to pending status so they can be approved again later.
* Added Newsletter Unsubscribe action that keeps the consent record but marks the subscriber as unsubscribed.
* Added permanent Delete action for newsletter records with confirmation.

= 1.0.3 =
* Feedback rows are clickable and open a full report view.
* Added New, Reviewing, and Resolved feedback statuses.
* Added status action buttons on the feedback detail screen.
* Added an optional Settings toggle for email notifications on new feedback.
* Feedback notification emails now include a direct link to the WordPress report.
* Added automatic database upgrade handling for the new feedback status fields.


= 1.1.1 =
* Tester actions now show one Send Access Email button per enrolled beta program.
* The tester keeps one shared access code; the selected beta program controls the email tag and feedback-form link.


= 1.1.2 =
* Added Beta Program and Active/Disabled filters to the Beta Testers screen.
* Added filtered tester counts and Reset action.


= 1.1.3 =
* Added PNG, JPG and JPEG to the feedback attachment server-side whitelist.
* Added explicit WordPress MIME support for Blender .blend feedback attachments.
* Supported feedback attachments are now .blend, .txt, .log, .png, .jpg, .jpeg and .zip.


= 1.1.4 =
* Removed direct .blend feedback uploads. Blender files must be placed inside a ZIP archive before submission.


= 1.1.5 =
* Beta Manager timestamps are stored in UTC and displayed in Montreal local time (America/Toronto).
* Daylight-saving time changes are handled automatically.
* Existing UTC feedback timestamps are converted for display without altering the stored database value.


= 1.1.6 =
* Added the custom Scriptronaut Beta Manager SVG icon to the WordPress admin menu.


= 1.1.7 =
* Replaced the Beta Manager WordPress admin menu icon with the corrected SVG artwork.


= 1.1.8 =
* Added permanent deletion of individual feedback reports from the Feedback detail screen.
* Deleting feedback also removes attachment files uploaded with that report.
* Added nonce, administrator permission, path-safety, and confirmation safeguards.
