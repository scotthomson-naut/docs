=== Scriptronaut Beta Manager ===
Contributors: scriptronaut
Tags: beta, feedback, newsletter, blender
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.3

Manage QC Checker beta candidates, approved testers, tester access codes, feedback, file attachments, and newsletter opt-ins.

== Installation ==
1. Upload scriptronaut-beta-manager.zip in WordPress: Plugins > Add New > Upload Plugin.
2. Activate Scriptronaut Beta Manager.
3. Open Beta Manager > Settings and confirm notification/from email addresses and static page URLs.
4. Update the static forms to post to the WordPress action URLs shown on the Beta Manager dashboard.
5. Approve a candidate from Beta Manager > Candidates. The plugin emails the generated Tester ID and Access Code to the tester, and also shows them once in the admin screen. The access code is stored only as a hash.

== Static form actions ==
For WordPress installed at /wp:
Signup: /wp/wp-admin/admin-post.php?action=scriptronaut_beta_signup
Feedback: /wp/wp-admin/admin-post.php?action=scriptronaut_beta_feedback

The signup form supports an optional newsletter checkbox:
<input type="checkbox" name="newsletter_optin" value="yes">

== Security ==
Public forms use a honeypot plus IP rate limiting. Tester access codes are hashed. Admin actions use WordPress capabilities and nonces. Uploaded feedback files are handled by WordPress and subject to plugin limits plus server/PHP limits.

Newsletter-only action: /wp/wp-admin/admin-post.php?action=scriptronaut_beta_newsletter
Expected fields: name, email, and optional honeypot field website.


== Changelog ==
= 1.0.3 =
* Feedback rows are clickable and open a full report view.
* Added New, Reviewing, and Resolved feedback statuses.
* Added status action buttons on the feedback detail screen.
* Added an optional Settings toggle for email notifications on new feedback.
* Feedback notification emails now include a direct link to the WordPress report.
* Added automatic database upgrade handling for the new feedback status fields.
