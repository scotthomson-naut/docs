<?php
/**
 * Plugin Name: Scriptronaut Beta Manager
 * Description: Manages Scriptronaut beta signups, testers, feedback, attachments, and newsletter opt-ins from static pages hosted on the same domain.
 * Version: 1.0.0
 * Author: Scriptronaut
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) { exit; }

final class Scriptronaut_Beta_Manager {
    const VERSION = '1.0.0';
    const OPT = 'scriptronaut_beta_manager_settings';
    const MENU = 'scriptronaut-beta-manager';

    private static $instance = null;
    private $tables = [];

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->tables = [
            'candidates' => $wpdb->prefix . 'scriptronaut_beta_candidates',
            'testers' => $wpdb->prefix . 'scriptronaut_beta_testers',
            'feedback' => $wpdb->prefix . 'scriptronaut_beta_feedback',
            'newsletter' => $wpdb->prefix . 'scriptronaut_beta_newsletter',
        ];

        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_post_nopriv_scriptronaut_beta_signup', [$this, 'handle_signup']);
        add_action('admin_post_scriptronaut_beta_signup', [$this, 'handle_signup']);
        add_action('admin_post_nopriv_scriptronaut_beta_newsletter', [$this, 'handle_newsletter']);
        add_action('admin_post_scriptronaut_beta_newsletter', [$this, 'handle_newsletter']);
        add_action('admin_post_nopriv_scriptronaut_beta_feedback', [$this, 'handle_feedback']);
        add_action('admin_post_scriptronaut_beta_feedback', [$this, 'handle_feedback']);
        add_action('admin_post_scriptronaut_beta_approve', [$this, 'approve_candidate']);
        add_action('admin_post_scriptronaut_beta_disable_tester', [$this, 'disable_tester']);
        add_action('admin_post_scriptronaut_beta_regenerate_code', [$this, 'regenerate_code']);
        add_action('admin_post_scriptronaut_beta_export_newsletter', [$this, 'export_newsletter']);
        add_action('admin_post_scriptronaut_beta_export_candidates', [$this, 'export_candidates']);
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix;

        dbDelta("CREATE TABLE {$p}scriptronaut_beta_candidates (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(120) NOT NULL,
            email varchar(254) NOT NULL,
            blender_use varchar(80) NOT NULL,
            blender_version varchar(20) NOT NULL,
            newsletter_optin tinyint(1) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'pending',
            ip_address varchar(64) NOT NULL DEFAULT '',
            submitted_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            KEY status (status)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}scriptronaut_beta_testers (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            candidate_id bigint(20) unsigned NULL,
            tester_id varchar(80) NOT NULL,
            name varchar(120) NOT NULL,
            email varchar(254) NOT NULL,
            access_hash varchar(255) NOT NULL,
            active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY tester_id (tester_id),
            UNIQUE KEY email (email),
            KEY active (active)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}scriptronaut_beta_feedback (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            tester_id varchar(80) NOT NULL,
            tester_email varchar(254) NOT NULL DEFAULT '',
            report_type varchar(40) NOT NULL,
            tier varchar(40) NOT NULL,
            category varchar(80) NOT NULL DEFAULT '',
            check_name varchar(180) NOT NULL DEFAULT '',
            check_id varchar(180) NOT NULL DEFAULT '',
            summary varchar(180) NOT NULL,
            details longtext NOT NULL,
            steps longtext NULL,
            expected_result text NULL,
            actual_result text NULL,
            qc_version varchar(40) NOT NULL DEFAULT '',
            blender_version varchar(80) NOT NULL DEFAULT '',
            operating_system varchar(240) NOT NULL DEFAULT '',
            blend_filename varchar(255) NOT NULL DEFAULT '',
            traceback longtext NULL,
            traceback_time varchar(80) NOT NULL DEFAULT '',
            source varchar(80) NOT NULL DEFAULT '',
            attachments longtext NULL,
            ip_address varchar(64) NOT NULL DEFAULT '',
            submitted_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY tester_id (tester_id),
            KEY report_type (report_type)
        ) $charset;");

        dbDelta("CREATE TABLE {$p}scriptronaut_beta_newsletter (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(120) NOT NULL,
            email varchar(254) NOT NULL,
            source varchar(80) NOT NULL DEFAULT 'beta_signup',
            subscribed tinyint(1) NOT NULL DEFAULT 1,
            consent_at datetime NOT NULL,
            ip_address varchar(64) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            UNIQUE KEY email (email),
            KEY subscribed (subscribed)
        ) $charset;");

        $defaults = [
            'recipient' => get_option('admin_email'),
            'from_email' => get_option('admin_email'),
            'from_name' => 'Scriptronaut',
            'subject_prefix' => '[QC Checker Beta]',
            'max_file_mb' => 8,
            'max_total_mb' => 20,
            'rate_limit_count' => 12,
            'rate_limit_window' => 3600,
            'static_beta_url' => preg_replace('#/wp/?$#', '', site_url()) . '/scriptronaut/betas.html',
            'static_feedback_url' => preg_replace('#/wp/?$#', '', site_url()) . '/scriptronaut/beta-feedback.html',
        ];
        if (!get_option(self::OPT)) add_option(self::OPT, $defaults);
    }

    private function settings() {
        return wp_parse_args((array)get_option(self::OPT, []), [
            'recipient' => get_option('admin_email'), 'from_email' => get_option('admin_email'),
            'from_name' => 'Scriptronaut', 'subject_prefix' => '[QC Checker Beta]',
            'max_file_mb' => 8, 'max_total_mb' => 20, 'rate_limit_count' => 12,
            'rate_limit_window' => 3600, 'static_beta_url' => preg_replace('#/wp/?$#', '', site_url()) . '/scriptronaut/betas.html',
            'static_feedback_url' => preg_replace('#/wp/?$#', '', site_url()) . '/scriptronaut/beta-feedback.html',
        ]);
    }

    public function register_settings() {
        register_setting('scriptronaut_beta_manager', self::OPT, [$this, 'sanitize_settings']);
    }

    public function sanitize_settings($v) {
        return [
            'recipient' => sanitize_email($v['recipient'] ?? ''),
            'from_email' => sanitize_email($v['from_email'] ?? ''),
            'from_name' => sanitize_text_field($v['from_name'] ?? 'Scriptronaut'),
            'subject_prefix' => sanitize_text_field($v['subject_prefix'] ?? '[QC Checker Beta]'),
            'max_file_mb' => max(1, min(50, intval($v['max_file_mb'] ?? 8))),
            'max_total_mb' => max(1, min(100, intval($v['max_total_mb'] ?? 20))),
            'rate_limit_count' => max(1, min(100, intval($v['rate_limit_count'] ?? 12))),
            'rate_limit_window' => max(60, min(DAY_IN_SECONDS, intval($v['rate_limit_window'] ?? 3600))),
            'static_beta_url' => esc_url_raw($v['static_beta_url'] ?? ''),
            'static_feedback_url' => esc_url_raw($v['static_feedback_url'] ?? ''),
        ];
    }

    private function client_ip() { return sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? 'unknown'); }

    private function rate_limit($kind) {
        $s = $this->settings();
        $key = 'snbm_rl_' . md5($kind . '|' . $this->client_ip());
        $data = get_transient($key);
        if (!is_array($data)) $data = ['count' => 0];
        if ($data['count'] >= $s['rate_limit_count']) $this->response(false, 'Too many attempts', 'Please wait before submitting again.', $kind === 'signup' ? 'beta' : 'feedback');
        $data['count']++;
        set_transient($key, $data, $s['rate_limit_window']);
    }

    private function post($key, $limit = 1000) {
        $value = isset($_POST[$key]) && is_string($_POST[$key]) ? trim(wp_unslash($_POST[$key])) : '';
        if (strlen($value) > $limit) $this->response(false, 'Could not submit', 'One of the submitted fields is too long.', 'beta');
        return $value;
    }

    private function response($ok, $title, $message, $return = 'beta') {
        $s = $this->settings();
        $url = $return === 'feedback' ? $s['static_feedback_url'] : $s['static_beta_url'];
        status_header($ok ? 200 : 400);
        nocache_headers();
        ?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?php echo esc_html($title); ?> — Scriptronaut</title>
        <style>body{margin:0;background:#100f28;color:#eee;font-family:Inter,Arial,sans-serif;min-height:100vh;display:grid;place-items:center}.card{max-width:680px;margin:30px;padding:36px;border-radius:18px;background:#242044;border:1px solid #514a78;box-shadow:0 18px 50px #0006}.ok{border-color:#64d889}.bad{border-color:#ff6f6f}h1{margin-top:0;color:#fc842c}.button{display:inline-block;margin-top:18px;padding:12px 18px;border-radius:9px;background:#9478ec;color:#fff;text-decoration:none;font-weight:700}</style></head><body><main class="card <?php echo $ok ? 'ok' : 'bad'; ?>"><h1><?php echo esc_html($title); ?></h1><p><?php echo esc_html($message); ?></p><a class="button" href="<?php echo esc_url($url); ?>">Return to Scriptronaut</a></main></body></html><?php
        exit;
    }

    private function send_mail($subject, $plain, $reply_to = '', $attachments = []) {
        $s = $this->settings();
        $headers = ['From: ' . $s['from_name'] . ' <' . $s['from_email'] . '>', 'Content-Type: text/plain; charset=UTF-8'];
        if ($reply_to && is_email($reply_to)) $headers[] = 'Reply-To: ' . $reply_to;
        return wp_mail($s['recipient'], $subject, $plain, $headers, $attachments);
    }

    public function handle_signup() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') $this->response(false, 'Invalid request', 'Please use the signup form on the beta page.', 'beta');
        $this->rate_limit('signup');
        if ($this->post('website', 200) !== '') $this->response(true, 'Signup received', 'Thank you for your interest in testing QC Checker.', 'beta');

        $name = sanitize_text_field($this->post('name', 120));
        $email = sanitize_email($this->post('email', 254));
        $use = sanitize_text_field($this->post('blender_use', 80));
        $version = sanitize_text_field($this->post('blender_version', 20));
        $newsletter = isset($_POST['newsletter_optin']) && wp_unslash($_POST['newsletter_optin']) === 'yes' ? 1 : 0;
        $allowed = ['VFX/Animation','ArchViz','Games','Freelance 3D','Technical Artist','Other'];
        if (!$name || !is_email($email) || !in_array($use, $allowed, true) || !preg_match('/^[0-9]+(?:\.[0-9]+){1,2}$/', $version)) {
            $this->response(false, 'Invalid information', 'Check the required fields and try again.', 'beta');
        }

        global $wpdb; $now = current_time('mysql');
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tables['candidates']} WHERE email=%s", strtolower($email)));
        $data = ['name'=>$name,'email'=>strtolower($email),'blender_use'=>$use,'blender_version'=>$version,'newsletter_optin'=>$newsletter,'ip_address'=>$this->client_ip(),'updated_at'=>$now];
        if ($existing) $wpdb->update($this->tables['candidates'], $data, ['id'=>$existing]);
        else { $data['status']='pending'; $data['submitted_at']=$now; $wpdb->insert($this->tables['candidates'], $data); }

        if ($newsletter) {
            $nid = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tables['newsletter']} WHERE email=%s", strtolower($email)));
            $nd = ['name'=>$name,'email'=>strtolower($email),'source'=>'beta_signup','subscribed'=>1,'consent_at'=>$now,'ip_address'=>$this->client_ip()];
            if ($nid) $wpdb->update($this->tables['newsletter'], $nd, ['id'=>$nid]); else $wpdb->insert($this->tables['newsletter'], $nd);
        }

        $s = $this->settings();
        $subject = $s['subject_prefix'] . ' Signup: ' . $name;
        $plain = "QC Checker beta signup\n\nName: $name\nEmail: $email\nMain Blender use: $use\nBlender version: $version\nNewsletter: " . ($newsletter ? 'Yes' : 'No') . "\nIP: " . $this->client_ip();
        $this->send_mail($subject, $plain, $email);
        $this->response(true, 'Signup received', 'Thank you. We will contact you at the email address you provided.', 'beta');
    }


    public function handle_newsletter() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') $this->response(false, 'Invalid request', 'Please use the newsletter signup form.', 'beta');
        $this->rate_limit('newsletter');
        if ($this->post('website', 200) !== '') $this->response(true, 'Subscription received', 'Thank you for subscribing.', 'beta');
        $name = sanitize_text_field($this->post('name', 120));
        $email = sanitize_email($this->post('email', 254));
        if (!$name || !is_email($email)) $this->response(false, 'Invalid information', 'Enter your name and a valid email address.', 'beta');
        global $wpdb; $now=current_time('mysql'); $email=strtolower($email);
        $id=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tables['newsletter']} WHERE email=%s",$email));
        $data=['name'=>$name,'email'=>$email,'source'=>'newsletter_form','subscribed'=>1,'consent_at'=>$now,'ip_address'=>$this->client_ip()];
        if($id)$wpdb->update($this->tables['newsletter'],$data,['id'=>$id]); else $wpdb->insert($this->tables['newsletter'],$data);
        $s=$this->settings();
        $this->send_mail($s['subject_prefix'].' Newsletter signup: '.$name,"Scriptronaut newsletter signup\n\nName: $name\nEmail: $email\nIP: ".$this->client_ip(),$email);
        $this->response(true,'Subscription received','Thank you. You are subscribed to Scriptronaut news and beta updates.','beta');
    }

    private function tester_by_credentials($tester_id, $access_code) {
        global $wpdb;
        $tester = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['testers']} WHERE tester_id=%s AND active=1", strtolower($tester_id)), ARRAY_A);
        if (!$tester || !wp_check_password($access_code, $tester['access_hash'])) return false;
        return $tester;
    }

    public function handle_feedback() {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') $this->response(false, 'Invalid request', 'Please use the beta feedback form.', 'feedback');
        $this->rate_limit('feedback');
        if ($this->post('website', 200) !== '') $this->response(true, 'Feedback received', 'Thank you for helping test QC Checker.', 'feedback');

        $tester_id = strtolower(sanitize_key($this->post('tester_id', 80)));
        $access_code = isset($_POST['access_code']) && is_string($_POST['access_code']) ? wp_unslash($_POST['access_code']) : '';
        $tester = $this->tester_by_credentials($tester_id, $access_code);
        if (!$tester) $this->response(false, 'Access not recognized', 'Check your tester ID and access code, then try again.', 'feedback');

        $fields = [
            'report_type'=>[40,'text'], 'tier'=>[40,'text'], 'category'=>[80,'text'], 'check_name'=>[180,'text'], 'check_id'=>[180,'text'],
            'summary'=>[180,'text'], 'details'=>[12000,'area'], 'steps'=>[8000,'area'], 'expected_result'=>[4000,'area'], 'actual_result'=>[4000,'area'],
            'qc_version'=>[40,'text'], 'blender_version'=>[80,'text'], 'operating_system'=>[240,'text'], 'blend_filename'=>[255,'text'],
            'traceback'=>[30000,'area'], 'traceback_time'=>[80,'text'], 'source'=>[80,'text']
        ];
        $v=[]; foreach ($fields as $k=>$spec) { $raw=$this->post($k,$spec[0]); $v[$k]=$spec[1]==='area'?sanitize_textarea_field($raw):sanitize_text_field($raw); }
        if (!$v['report_type'] || !$v['tier'] || !$v['summary'] || !$v['details']) $this->response(false, 'Missing information', 'Complete the required feedback fields.', 'feedback');
        if ($v['report_type']==='check_issue' && (!$v['category'] || !$v['check_name'])) $this->response(false, 'Missing check', 'Choose the category and check that had the issue.', 'feedback');

        $attachments = $this->handle_uploads();
        global $wpdb;
        $wpdb->insert($this->tables['feedback'], [
            'tester_id'=>$tester_id,'tester_email'=>$tester['email'],'report_type'=>$v['report_type'],'tier'=>$v['tier'],'category'=>$v['category'],
            'check_name'=>$v['check_name'],'check_id'=>$v['check_id'],'summary'=>$v['summary'],'details'=>$v['details'],'steps'=>$v['steps'],
            'expected_result'=>$v['expected_result'],'actual_result'=>$v['actual_result'],'qc_version'=>$v['qc_version'],'blender_version'=>$v['blender_version'],
            'operating_system'=>$v['operating_system'],'blend_filename'=>$v['blend_filename'],'traceback'=>$v['traceback'],'traceback_time'=>$v['traceback_time'],
            'source'=>$v['source'],'attachments'=>wp_json_encode(array_map(function($a){return ['name'=>$a['name'],'url'=>$a['url']];},$attachments)),
            'ip_address'=>$this->client_ip(),'submitted_at'=>current_time('mysql')
        ]);

        $s=$this->settings(); $subject=$s['subject_prefix'].' Feedback: '.$v['summary'];
        $plain="QC Checker beta feedback\n\nTester: {$tester['name']} ({$tester_id})\nEmail: {$tester['email']}\nType: {$v['report_type']}\nProduct: {$v['tier']}\nCategory: {$v['category']}\nCheck: {$v['check_name']}\nSummary: {$v['summary']}\n\nDetails:\n{$v['details']}\n\nBlender: {$v['blender_version']}\nQC Checker: {$v['qc_version']}\nOS: {$v['operating_system']}";
        $this->send_mail($subject,$plain,$tester['email'],array_column($attachments,'path'));
        $this->response(true, 'Feedback received', 'Thank you. Your report has been saved and sent to the Scriptronaut team.', 'feedback');
    }

    private function handle_uploads() {
        if (empty($_FILES['attachments']) || !is_array($_FILES['attachments']['name'])) return [];
        if (empty($_POST['upload_confirmation'])) return [];
        $s=$this->settings(); $max=intval($s['max_file_mb'])*MB_IN_BYTES; $maxTotal=intval($s['max_total_mb'])*MB_IN_BYTES; $total=0; $out=[];
        require_once ABSPATH.'wp-admin/includes/file.php';
        $names=$_FILES['attachments']['name'];
        foreach ($names as $i=>$name) {
            if (!$name || ($_FILES['attachments']['error'][$i] ?? UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) continue;
            $size=intval($_FILES['attachments']['size'][$i] ?? 0); $total += $size;
            if ($size>$max || $total>$maxTotal) $this->response(false,'Attachment too large','One or more attachments exceed the configured upload limit.','feedback');
            $file=['name'=>sanitize_file_name($name),'type'=>$_FILES['attachments']['type'][$i] ?? '','tmp_name'=>$_FILES['attachments']['tmp_name'][$i] ?? '','error'=>$_FILES['attachments']['error'][$i] ?? UPLOAD_ERR_NO_FILE,'size'=>$size];
            $allowed=['blend'=>'application/octet-stream','txt'=>'text/plain','log'=>'text/plain','zip'=>'application/zip'];
            $upload=wp_handle_upload($file,['test_form'=>false,'mimes'=>$allowed]);
            if (!empty($upload['error'])) $this->response(false,'Upload failed',$upload['error'],'feedback');
            $out[]=['name'=>basename($upload['file']),'path'=>$upload['file'],'url'=>$upload['url']];
        }
        return $out;
    }

    public function admin_menu() {
        add_menu_page('Scriptronaut Beta Manager','Beta Manager','manage_options',self::MENU,[$this,'page_dashboard'],'dashicons-groups',58);
        add_submenu_page(self::MENU,'Candidates','Candidates','manage_options',self::MENU.'-candidates',[$this,'page_candidates']);
        add_submenu_page(self::MENU,'Testers','Testers','manage_options',self::MENU.'-testers',[$this,'page_testers']);
        add_submenu_page(self::MENU,'Feedback','Feedback','manage_options',self::MENU.'-feedback',[$this,'page_feedback']);
        add_submenu_page(self::MENU,'Newsletter','Newsletter','manage_options',self::MENU.'-newsletter',[$this,'page_newsletter']);
        add_submenu_page(self::MENU,'Settings','Settings','manage_options',self::MENU.'-settings',[$this,'page_settings']);
    }

    private function admin_header($title) { echo '<div class="wrap"><h1>'.esc_html($title).'</h1>'; $this->show_code_notice(); }
    private function admin_footer() { echo '</div>'; }
    private function count($table,$where='1=1'){ global $wpdb; return intval($wpdb->get_var("SELECT COUNT(*) FROM {$this->tables[$table]} WHERE $where")); }

    public function page_dashboard() {
        $this->admin_header('Scriptronaut Beta Manager');
        echo '<p>Manage beta applicants, approved testers, feedback reports, and newsletter opt-ins.</p><div style="display:flex;gap:16px;flex-wrap:wrap">';
        foreach ([['Candidates',$this->count('candidates'),self::MENU.'-candidates'],['Active Testers',$this->count('testers','active=1'),self::MENU.'-testers'],['Feedback',$this->count('feedback'),self::MENU.'-feedback'],['Newsletter',$this->count('newsletter','subscribed=1'),self::MENU.'-newsletter']] as $x) echo '<a href="'.esc_url(admin_url('admin.php?page='.$x[2])).'" style="min-width:180px;padding:18px;background:#fff;border:1px solid #ccd0d4;text-decoration:none"><strong style="font-size:28px">'.$x[1].'</strong><br>'.esc_html($x[0]).'</a>';
        echo '</div><h2>Static page integration</h2><p>Beta signup action:</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_beta_signup')).'</code><p>Feedback action:</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_beta_feedback')).'</code><p>Newsletter-only action:</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_beta_newsletter')).'</code>';
        $this->admin_footer();
    }

    public function page_candidates() {
        global $wpdb; $rows=$wpdb->get_results("SELECT * FROM {$this->tables['candidates']} ORDER BY submitted_at DESC",ARRAY_A);
        $this->admin_header('Beta Candidates');
        echo '<p><a class="button" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_export_candidates'),'snbm_export_candidates')).'">Export CSV</a></p>';
        echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Blender Use</th><th>Version</th><th>Newsletter</th><th>Status</th><th>Submitted</th><th></th></tr></thead><tbody>';
        foreach($rows as $r){ echo '<tr><td>'.esc_html($r['name']).'</td><td><a href="mailto:'.esc_attr($r['email']).'">'.esc_html($r['email']).'</a></td><td>'.esc_html($r['blender_use']).'</td><td>'.esc_html($r['blender_version']).'</td><td>'.($r['newsletter_optin']?'Yes':'No').'</td><td>'.esc_html($r['status']).'</td><td>'.esc_html($r['submitted_at']).'</td><td>'; if($r['status']!=='approved') echo '<a class="button button-primary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_approve&id='.$r['id']),'snbm_approve_'.$r['id'])).'">Approve</a>'; echo '</td></tr>'; }
        echo '</tbody></table>'; $this->admin_footer();
    }

    private function unique_tester_id($email) { global $wpdb; $base=sanitize_key(strtok($email,'@')); if(!$base)$base='tester'; $id=$base;$n=2; while($wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->tables['testers']} WHERE tester_id=%s",$id))){$id=$base.$n;$n++;} return $id; }
    private function generate_code(){ return strtoupper(wp_generate_password(12,false,false)); }

    public function approve_candidate() {
        if(!current_user_can('manage_options'))wp_die('Unauthorized'); $id=intval($_GET['id']??0); check_admin_referer('snbm_approve_'.$id);
        global $wpdb; $c=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['candidates']} WHERE id=%d",$id),ARRAY_A); if(!$c)wp_die('Candidate not found');
        $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['testers']} WHERE email=%s",$c['email']),ARRAY_A); $code=$this->generate_code(); $tid=$existing?$existing['tester_id']:$this->unique_tester_id($c['email']);
        $data=['candidate_id'=>$id,'tester_id'=>$tid,'name'=>$c['name'],'email'=>$c['email'],'access_hash'=>wp_hash_password($code),'active'=>1,'updated_at'=>current_time('mysql')];
        if($existing)$wpdb->update($this->tables['testers'],$data,['id'=>$existing['id']]); else{$data['created_at']=current_time('mysql');$wpdb->insert($this->tables['testers'],$data);}
        $wpdb->update($this->tables['candidates'],['status'=>'approved','updated_at'=>current_time('mysql')],['id'=>$id]);
        set_transient('snbm_code_'.get_current_user_id(),['tester_id'=>$tid,'code'=>$code,'name'=>$c['name']],120);
        wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-testers'));exit;
    }

    private function show_code_notice(){ $k='snbm_code_'.get_current_user_id();$d=get_transient($k);if($d){delete_transient($k);echo '<div class="notice notice-success"><p><strong>Tester access created.</strong> Copy this now; the access code is stored only as a hash.</p><p>Tester ID: <code>'.esc_html($d['tester_id']).'</code> &nbsp; Access code: <code style="font-size:15px">'.esc_html($d['code']).'</code></p></div>';}}

    public function page_testers(){ global $wpdb;$rows=$wpdb->get_results("SELECT * FROM {$this->tables['testers']} ORDER BY created_at DESC",ARRAY_A);$this->admin_header('Beta Testers');echo '<table class="widefat striped"><thead><tr><th>Tester ID</th><th>Name</th><th>Email</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead><tbody>';foreach($rows as $r){$regen=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_regenerate_code&id='.$r['id']),'snbm_regen_'.$r['id']);$disable=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_disable_tester&id='.$r['id']),'snbm_disable_'.$r['id']);echo '<tr><td><code>'.esc_html($r['tester_id']).'</code></td><td>'.esc_html($r['name']).'</td><td>'.esc_html($r['email']).'</td><td>'.($r['active']?'Active':'Disabled').'</td><td>'.esc_html($r['created_at']).'</td><td><a class="button" href="'.esc_url($regen).'">New Access Code</a> ';if($r['active'])echo '<a class="button" href="'.esc_url($disable).'">Disable</a>';echo '</td></tr>';}echo '</tbody></table>';$this->admin_footer();}

    public function regenerate_code(){if(!current_user_can('manage_options'))wp_die('Unauthorized');$id=intval($_GET['id']??0);check_admin_referer('snbm_regen_'.$id);global $wpdb;$t=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tables['testers']} WHERE id=%d",$id),ARRAY_A);if(!$t)wp_die('Tester not found');$code=$this->generate_code();$wpdb->update($this->tables['testers'],['access_hash'=>wp_hash_password($code),'active'=>1,'updated_at'=>current_time('mysql')],['id'=>$id]);set_transient('snbm_code_'.get_current_user_id(),['tester_id'=>$t['tester_id'],'code'=>$code,'name'=>$t['name']],120);wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-testers'));exit;}
    public function disable_tester(){if(!current_user_can('manage_options'))wp_die('Unauthorized');$id=intval($_GET['id']??0);check_admin_referer('snbm_disable_'.$id);global $wpdb;$wpdb->update($this->tables['testers'],['active'=>0,'updated_at'=>current_time('mysql')],['id'=>$id]);wp_safe_redirect(admin_url('admin.php?page='.self::MENU.'-testers'));exit;}

    public function page_feedback(){global $wpdb;$rows=$wpdb->get_results("SELECT * FROM {$this->tables['feedback']} ORDER BY submitted_at DESC LIMIT 500",ARRAY_A);$this->admin_header('Beta Feedback');echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Tester</th><th>Type</th><th>Product</th><th>Summary / Details</th><th>Environment</th><th>Attachments</th></tr></thead><tbody>';foreach($rows as $r){$atts=json_decode($r['attachments'],true);echo '<tr><td>'.esc_html($r['submitted_at']).'</td><td><code>'.esc_html($r['tester_id']).'</code><br>'.esc_html($r['tester_email']).'</td><td>'.esc_html($r['report_type']).'</td><td>'.esc_html($r['tier']).'<br>'.esc_html($r['category']).'<br>'.esc_html($r['check_name']).'</td><td><strong>'.esc_html($r['summary']).'</strong><br>'.nl2br(esc_html($r['details']));if($r['traceback'])echo '<details><summary>Traceback</summary><pre style="white-space:pre-wrap">'.esc_html($r['traceback']).'</pre></details>';echo '</td><td>QC '.esc_html($r['qc_version']).'<br>Blender '.esc_html($r['blender_version']).'<br>'.esc_html($r['operating_system']).'</td><td>';if(is_array($atts))foreach($atts as $a)echo '<a href="'.esc_url($a['url']).'" target="_blank">'.esc_html($a['name']).'</a><br>';echo '</td></tr>';}echo '</tbody></table>';$this->admin_footer();}

    public function page_newsletter(){global $wpdb;$rows=$wpdb->get_results("SELECT * FROM {$this->tables['newsletter']} ORDER BY consent_at DESC",ARRAY_A);$this->admin_header('Newsletter Signups');$export=wp_nonce_url(admin_url('admin-post.php?action=scriptronaut_beta_export_newsletter'),'snbm_export_newsletter');echo '<p><a class="button" href="'.esc_url($export).'">Export CSV</a></p><table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Source</th><th>Subscribed</th><th>Consent Date</th><th>IP</th></tr></thead><tbody>';foreach($rows as $r)echo '<tr><td>'.esc_html($r['name']).'</td><td>'.esc_html($r['email']).'</td><td>'.esc_html($r['source']).'</td><td>'.($r['subscribed']?'Yes':'No').'</td><td>'.esc_html($r['consent_at']).'</td><td>'.esc_html($r['ip_address']).'</td></tr>';echo '</tbody></table>';$this->admin_footer();}

    public function page_settings(){ $s=$this->settings();$this->admin_header('Beta Manager Settings');echo '<form method="post" action="options.php">';settings_fields('scriptronaut_beta_manager');$name=self::OPT;echo '<table class="form-table">';$fields=['recipient'=>['Notification recipient','email'],'from_email'=>['From email','email'],'from_name'=>['From name','text'],'subject_prefix'=>['Email subject prefix','text'],'max_file_mb'=>['Max attachment size (MB)','number'],'max_total_mb'=>['Max total upload (MB)','number'],'rate_limit_count'=>['Submissions per rate window','number'],'rate_limit_window'=>['Rate window (seconds)','number'],'static_beta_url'=>['Static beta page URL','url'],'static_feedback_url'=>['Static feedback page URL','url']];foreach($fields as $k=>$f)echo '<tr><th><label for="'.$k.'">'.esc_html($f[0]).'</label></th><td><input class="regular-text" id="'.$k.'" type="'.$f[1].'" name="'.$name.'['.$k.']" value="'.esc_attr($s[$k]).'"></td></tr>';echo '</table>';submit_button();echo '</form><h2>Form actions</h2><p>Set the signup form action to:</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_beta_signup')).'</code><p>Set the feedback form action to:</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_beta_feedback')).'</code><p>Newsletter-only form action:</p><code>'.esc_html(admin_url('admin-post.php?action=scriptronaut_beta_newsletter')).'</code>';$this->admin_footer();}

    private function csv_download($filename,$headers,$rows){nocache_headers();header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="'.$filename.'"');$o=fopen('php://output','w');fputcsv($o,$headers);foreach($rows as $r)fputcsv($o,$r);fclose($o);exit;}
    public function export_newsletter(){if(!current_user_can('manage_options'))wp_die('Unauthorized');check_admin_referer('snbm_export_newsletter');global $wpdb;$rows=$wpdb->get_results("SELECT name,email,source,consent_at FROM {$this->tables['newsletter']} WHERE subscribed=1 ORDER BY consent_at DESC",ARRAY_N);$this->csv_download('scriptronaut-newsletter.csv',['Name','Email','Source','Consent Date'],$rows);}
    public function export_candidates(){if(!current_user_can('manage_options'))wp_die('Unauthorized');check_admin_referer('snbm_export_candidates');global $wpdb;$rows=$wpdb->get_results("SELECT name,email,blender_use,blender_version,newsletter_optin,status,submitted_at FROM {$this->tables['candidates']} ORDER BY submitted_at DESC",ARRAY_N);$this->csv_download('scriptronaut-beta-candidates.csv',['Name','Email','Blender Use','Blender Version','Newsletter','Status','Submitted'],$rows);}
}

register_activation_hook(__FILE__, ['Scriptronaut_Beta_Manager','activate']);
Scriptronaut_Beta_Manager::instance();
