Scriptronaut Relay 0.1.3

Newsletter manager for Scriptronaut.

Features
- Subscriber database and CSV export
- Import/update subscribers from Scriptronaut Beta Manager
- Upload locally designed HTML newsletters
- Campaign IDs from filenames such as relay_2026-09.html
- Preview and download stored HTML
- Test sends
- Queued/batched newsletter sending through WordPress wp_mail()
- Delivery log
- Signed unsubscribe links
- HTML placeholders: {{unsubscribe_url}} and {{unsubscribe_link}}

Recommended workflow
1. Install and activate Relay.
2. Open Relay > Settings and verify From Email and Test Email.
3. Open Relay > Subscribers and click Import / Update from Beta Manager.
4. Change the newsletter-only website form action to:
   /wp/wp-admin/admin-post.php?action=scriptronaut_relay_subscribe
   (Use the exact URL shown on the Relay Dashboard.)
5. Design newsletters locally and save them as relay_YYYY-MM.html.
6. Upload in Relay > Newsletters, Send Test, then Send Newsletter.

Note: queued sending uses WP-Cron and wp_mail(). For larger lists, use an SMTP/transactional mail provider through WordPress so wp_mail() is delivered by that provider.

0.1.1
- Added a dedicated send confirmation screen showing the number of active subscribers.
- Added duplicate-send protection so a campaign cannot be queued twice.

== 0.1.2 ==
* Added Edit / Replace workflow for draft campaigns.
* Edit subject and title without re-uploading HTML.
* Replace campaign HTML while keeping the campaign ID unchanged.
* Sent/queued campaigns are locked against editing.

0.1.3
- Sent campaigns now show only Preview, Download HTML, and Delete actions.
- Upload form filename, subject, and title suggestions now automatically use the next calendar month.
